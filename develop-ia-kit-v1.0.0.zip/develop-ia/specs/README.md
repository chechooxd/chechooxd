# Specs

Cada funcionalidad o capacidad tiene su carpeta `NNN-nombre-en-kebab/`, creada y mantenida por los agentes del flujo SDD.

| Archivo | Etapa | Dueño | Contenido |
|---|---|---|---|
| `research.md` | 1 · Exploración | sdd-explorer | Áreas afectadas, patrones, dependencias, riesgos |
| `spec.md` | 2-3 · Especificación | sdd-spec-writer | QUÉ y POR QUÉ, RF en EARS |
| `plan.md` | 4 · Diseño | sdd-architect | CÓMO: archivos, decisiones, estrategia de tests |
| `contracts/` | 4 · Diseño | sdd-architect | Contratos de API o integración (opcional) |
| `tasks.md` | 5-6 · Tareas y TDD | sdd-task-planner + tdd-* | Tareas y evidencia RED y GREEN |
| `review.md` | 9 · Cierre | sdd-archivist | Informe de revisión de código |
| `verification.md` | 9 · Cierre | sdd-archivist | Matriz RF → evidencia y veredicto |

- Numeración: siguiente número libre de tres dígitos; nunca se reutiliza.
- Estados de la spec: `Borrador` → `Aprobada` → `Implementada` (→ `Obsoleta` o `Reemplazada por NNN`).
- Plantillas: `.github/skills/*/assets/`. Ejemplo de spec: `.github/skills/ears-requirements/references/example-spec.md`.
- Para ver el estado: `/sdd-status` (todas) o `/sdd-status NNN-nombre`.
