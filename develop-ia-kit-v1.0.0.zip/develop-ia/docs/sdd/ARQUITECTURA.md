# Arquitectura del sistema multiagente SDD + TDD

## 1. Visión

Un **orquestador** dirige el flujo y habla con el desarrollador; **diez subagentes especialistas** ejecutan cada uno una etapa con las herramientas mínimas imprescindibles; las **skills** aportan el conocimiento de cada etapa; las **instrucciones** fijan las reglas del repositorio y del stack; y un **hook** hace cumplir los permisos que Copilot no permite declarar en el agente.

```mermaid
flowchart LR
    U([Desarrollador]) <--> O[sdd-orchestrator<br/>sin edición]
    O --> E[sdd-explorer<br/>1 · Exploración]
    O --> SW[sdd-spec-writer<br/>2 · Especificación]
    O --> SR[sdd-spec-reviewer<br/>3/5 · QA de specs]
    O --> A[sdd-architect<br/>0/4 · Constitución y diseño]
    O --> TP[sdd-task-planner<br/>5 · Tareas]
    O --> TA[tdd-test-author<br/>6a · RED]
    O --> TI[tdd-implementer<br/>6b · GREEN + REFACTOR]
    O --> CR[code-reviewer<br/>7 · Revisión]
    O --> V[sdd-verifier<br/>8 · Verificación]
    O --> AR[sdd-archivist<br/>9 · Cierre]
```

### Secuencia de una funcionalidad

```mermaid
sequenceDiagram
    actor Dev as Desarrollador
    participant O as Orquestador
    participant S as Subagentes
    Dev->>O: /sdd-feature «idea»
    O->>S: explorer → research.md
    O->>S: spec-writer (entrevista)
    S-->>O: PREGUNTAS
    O->>Dev: preguntas de una en una
    Dev-->>O: respuestas
    O->>S: spec-writer (redactar) → spec-reviewer (QA)
    O->>Dev: 🔒 Gate 1 · ¿apruebas la spec?
    Dev-->>O: sí
    O->>S: architect → task-planner → spec-reviewer (consistencia)
    O->>Dev: 🔒 Gate 2 · ¿apruebas plan y tareas?
    Dev-->>O: sí
    loop Por cada tarea
        O->>S: test-author → evidencia RED
        O->>S: implementer → evidencia GREEN
    end
    O->>S: code-reviewer → verifier
    O->>S: archivist → informes, MEMORY, PR
    O->>Dev: 🔒 Gate 3 · aceptación final
```

## 2. Matriz de agentes

| Agente | Etapa | Herramientas | Puede escribir | Skills principales |
|---|---|---|---|---|
| `sdd-orchestrator` | Todas (coordina) | agent, read, search, todo, preguntas | — | sdd-workflow |
| `sdd-explorer` | 1 Exploración | read, search, execute (solo lectura), edit, web | `specs/*/research.md` | codebase-exploration |
| `sdd-spec-writer` | 2-3 Especificación | read, search, edit | `specs/*/spec.md` | ears-requirements, change-management |
| `sdd-spec-reviewer` | 3 y 5 QA | read, search | — | spec-quality-review |
| `sdd-architect` | 0 y 4 Diseño | read, search, edit, web | `plan.md`, `contracts/`, `docs/adr/`, `docs/constitution.md` | technical-design, project-constitution |
| `sdd-task-planner` | 5 Tareas | read, search, edit | `specs/*/tasks.md` | task-breakdown |
| `tdd-test-author` | 6a RED | read, search, edit, execute | Archivos de test + evidencia en `tasks.md` | tdd-cycle |
| `tdd-implementer` | 6b GREEN + REFACTOR | read, search, edit, execute | Código de producción (**nunca tests**) + evidencia | tdd-cycle, systematic-debugging |
| `code-reviewer` | 7 Revisión | read, search, execute (solo lectura) | — | code-review |
| `sdd-verifier` | 8 Verificación | read, search, execute, Chrome DevTools | — | strict-verification |
| `sdd-archivist` | 9 Cierre + commits | read, search, edit, execute | `specs/**`, `MEMORY.md`, `CHANGELOG.md`, `docs/**` | sdd-closure, project-memory, conventional-commits |

Todos los subagentes tienen `user-invocable: false`: no aparecen en el selector y solo los invoca el orquestador (lista `agents:`).

## 3. Guardarraíles: defensa en profundidad

| Capa | Mecanismo | Qué garantiza |
|---|---|---|
| 1. Herramientas | `tools:` de cada agente | Quien no tiene `edit` no puede editar (revisores, verificador, orquestador). |
| 2. Instrucciones | Secciones «Límites» y reglas de las skills | Comportamiento esperado dentro de lo permitido. |
| 3. Hook de política | `.github/hooks/sdd-guardrails.json` + `sdd-policy.json` | Permisos por ruta y comandos prohibidos (Copilot no los admite en el agente). |
| 4. Gates humanos | Gates 1, 2 y 3 del orquestador | Nada avanza sin la aprobación del desarrollador. |
| 5. Verificación independiente | `code-reviewer` + `sdd-verifier` sin edición | Quien comprueba no es quien construye; solo cuenta la evidencia ejecutada. |

### Política del hook

- **Global** (cualquier agente, también el modo por defecto): no escribir en `.env*`, claves ni `.git/`; prohibidos `rm -rf` sobre la raíz, el home o el directorio actual, `push --force`, `reset --hard`, `clean -f`, `--no-verify` y `DROP DATABASE`.
- **Subagentes SDD**: no tocan los archivos del kit ni `AGENTS.md`; no hacen push, no reescriben historia, no instalan paquetes; solo `sdd-archivist` puede hacer commit.
- **Por agente**: rutas permitidas (por ejemplo, `tdd-implementer` no puede modificar tests y `tdd-test-author` no puede modificar código de producción).
- **Fail-open**: si Node no está instalado o la política tiene errores, el hook no bloquea nada. Es una red de seguridad, no un punto único de fallo.
- La identificación del subagente depende de que el harness informe del agente (`agentType`). Si no lo hace, se aplican solo las reglas globales y las capas 1, 2, 4 y 5 siguen activas.

## 4. Contrato entre agentes

**Encargo** (orquestador → subagente): etapa y modo, spec y rama, objetivo, petición literal del usuario, decisiones tomadas, archivos a leer, resultado de la etapa anterior y restricciones. Los subagentes no ven la conversación: el encargo debe ser autosuficiente.

**Respuesta** (subagente → orquestador): empieza siempre por `ESTADO: COMPLETADO | PREGUNTAS | BLOQUEADO`; los revisores añaden `VEREDICTO: ...`; las etapas que ejecutan algo incluyen evidencia (comando, código de salida y salida resumida).

## 5. Mapa de archivos

```text
.github/
├── copilot-instructions.md      Reglas globales de Copilot (cortas)
├── agents/                      1 orquestador + 10 subagentes (.agent.md)
├── skills/                      15 skills (SKILL.md + assets/ + references/)
├── instructions/                Reglas por patrón de archivo (.instructions.md)
├── prompts/                     Comandos /sdd-* (.prompt.md)
└── hooks/                       Guardarraíles (preToolUse) + política
AGENTS.md                        Contexto del proyecto (stack, comandos, límites)
MEMORY.md                        Memoria entre sesiones
docs/constitution.md             Principios innegociables
docs/adr/                        Decisiones de arquitectura
docs/sdd/                        Guía, arquitectura e instalación
docs/sdd/perfiles/               AGENTS.md listos para el frontend Angular y el backend .NET
specs/NNN-nombre/                Artefactos de cada spec
.vscode/settings.json            Ajustes recomendados
.vscode/mcp.json                 MCP opcionales (Chrome DevTools, Context7)
```

### Skills por etapa

| Etapa | Skills |
|---|---|
| Transversal | `sdd-workflow`, `project-memory`, `conventional-commits` |
| 0 Constitución | `project-constitution` |
| 1 Exploración | `codebase-exploration` |
| 2 Especificación | `ears-requirements`, `change-management` |
| 3 y 5 QA | `spec-quality-review` |
| 4 Diseño | `technical-design` |
| 5 Tareas | `task-breakdown` |
| 6 TDD | `tdd-cycle`, `systematic-debugging` |
| 7 Revisión | `code-review` |
| 8 Verificación | `strict-verification` |
| 9 Cierre | `sdd-closure` |

Las skills `technical-design` y `code-review` incluyen listas específicas por stack en `references/` (Angular 20 y .NET 10): dónde vive el estado, capas Controller → Handler → Repository, contrato `ResponseData<T>`, reglas de EF Core e impacto en consumidores.

### Instrucciones por patrón

| Archivo | `applyTo` |
|---|---|
| `sdd-artifacts` | `specs/**` |
| `testing` | Archivos y carpetas de test |
| `security` | `**` |
| `angular` (perfil de stack) | `**/*.ts, **/*.html, **/*.scss, **/*.css` |
| `dotnet` (perfil de stack) | `**/*.cs, **/*.csproj` |
| `memory-file` | `MEMORY.md` |
| `agent-customization` | Archivos del kit en `.github/` |
| `commit-messages` | (Sin patrón; se usa en la generación de commits) |

## 6. Del curso (OpenCode) a GitHub Copilot

| Concepto del curso | OpenCode | GitHub Copilot (este kit) |
|---|---|---|
| Contexto del proyecto | `AGENTS.md` | `AGENTS.md` + `.github/copilot-instructions.md` |
| Memoria | `MEMORY.md` | `MEMORY.md` + instrucción `memory-file` + skill `project-memory` |
| Comandos personalizados | `.opencode/commands/*.md` | `.github/prompts/*.prompt.md` (`/sdd-*`) |
| Skills | `.agents/skills/<n>/SKILL.md` | `.github/skills/<n>/SKILL.md` |
| Agente principal | `mode: primary` | `.agent.md` visible (`sdd-orchestrator`) |
| Subagente | `mode: subagent` | `.agent.md` con `user-invocable: false` + lista `agents:` del orquestador |
| Permisos por agente | `permissions:` (`edit`, `shell`, rutas) | `tools:` del agente + hook `preToolUse` con política por ruta |
| MCP | `opencode.json` | `.vscode/mcp.json` |
| Modo Plan | Agente `plan` | Etapas 1-5 sin edición de código y gates |
| coordinator → planner → implementer → reviewer | 4 agentes | 11 agentes: el planner se divide en explorer, spec-writer, spec-reviewer, architect y task-planner; el implementer, en test-author (RED) e implementer (GREEN); el reviewer, en code-reviewer y verifier; y se añade archivist |

## 7. Decisiones de diseño

| Decisión | Alternativa descartada | Motivo |
|---|---|---|
| El orquestador no tiene `edit` ni `execute` | Orquestador que también implementa | Separación de funciones; su contexto se mantiene limpio para coordinar varias etapas. |
| RED y GREEN en agentes distintos | Un único implementador «tests primero» | El implementador no puede ajustar los tests a su código: TDD real, aplicado por herramienta y por hook. |
| Revisión y verificación separadas | Un único revisor | La revisión juzga la calidad del diff; la verificación demuestra el cumplimiento de la spec con evidencia ejecutada. |
| Revisores sin `edit` | Revisores que corrigen | Quien comprueba no modifica; los informes los persiste `sdd-archivist`. |
| Comandos `/sdd-*` que siempre pasan por el orquestador | Comandos que invocan directamente a cada subagente | Un único punto de entrada que aplica gates, contexto y validación también en el modo paso a paso. |
| Skills propias, sin OpenSpec ni paquetes externos | OpenSpec, spec-kit o skills de terceros | Requisito del equipo: todo el sistema es propio, versionado y auditable. |
| Hook fail-open | Hook fail-closed | Un hook roto no debe paralizar al equipo; las demás capas siguen activas. |
