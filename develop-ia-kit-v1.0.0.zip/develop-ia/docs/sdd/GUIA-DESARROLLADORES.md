# Guía para desarrolladores · SDD + TDD con GitHub Copilot

> Tú diriges, la IA ejecuta. El responsable del código sigues siendo tú.

## 1. En cinco líneas

1. Toda funcionalidad empieza por una **spec** (el QUÉ y el POR QUÉ) con requisitos verificables en EARS.
2. De la spec sale un **plan** (el CÓMO) y una lista de **tareas** pequeñas.
3. Cada tarea se implementa con **TDD**: un agente escribe los tests (que fallan) y otro escribe el código (hasta que pasan).
4. Un agente **revisa** el código y otro **verifica** la spec requisito por requisito, con evidencia ejecutada.
5. Tú **apruebas** en tres puntos: la spec, el plan con las tareas y el resultado final.

## 2. Primeros pasos (una vez por repositorio)

| Paso | Comando | Resultado |
|---|---|---|
| 1 | Instala el kit | Ver [INSTALACION.md](./INSTALACION.md) |
| 2 | `/sdd-init` | `AGENTS.md` y `MEMORY.md` completados con el stack y los comandos reales |
| 3 | `/sdd-constitution` | Propuesta de principios innegociables → la apruebas → `Vigente` |

## 3. Uso diario

### Opción A · Flujo completo guiado (recomendada)

Selecciona el agente **`sdd-orchestrator`** en el selector del chat, o usa el comando:

```text
/sdd-feature Quiero que el gestor pueda programar el envío de una notificación para una fecha y hora futuras
```

El orquestador recorre todas las etapas, te hace preguntas cuando hay ambigüedad y se detiene en cada gate.

### Opción B · Paso a paso

| Comando | Etapa | Ejemplo |
|---|---|---|
| `/sdd-explore` | 1 · Exploración | `/sdd-explore 007-programar-envio programar notificaciones` |
| `/sdd-spec` | 2-3 · Spec + clarificación → Gate 1 | `/sdd-spec 007-programar-envio programar notificaciones con fecha futura` |
| `/sdd-clarify` | 3 · QA de la spec (o `consistencia`) | `/sdd-clarify 007-programar-envio` |
| `/sdd-plan` | 4 · Diseño técnico | `/sdd-plan 007-programar-envio` |
| `/sdd-tasks` | 5 · Tareas + consistencia → Gate 2 | `/sdd-tasks 007-programar-envio` |
| `/sdd-implement` | 6 · TDD (una tarea o todas) | `/sdd-implement 007-programar-envio T03` |
| `/sdd-review` | 7 · Revisión de código | `/sdd-review 007-programar-envio dev` |
| `/sdd-verify` | 8 · Verificación RF por RF | `/sdd-verify 007-programar-envio` |
| `/sdd-close` | 9 · Cierre → Gate 3 | `/sdd-close 007-programar-envio` |
| `/sdd-change` | Cambio de requisitos | `/sdd-change 007-programar-envio permitir hasta 180 días` |
| `/sdd-bugfix` | Bug con test de regresión | `/sdd-bugfix al programar a las 00:30 se guarda el día anterior` |
| `/sdd-status` | Estado y siguiente paso | `/sdd-status 007-programar-envio` |

Todos los comandos pasan por el orquestador, así que los gates y las validaciones se aplican también en el modo paso a paso.

## 4. Tus puntos de decisión

| Momento | Qué revisar antes de aprobar |
|---|---|
| Preguntas de la entrevista | Elige una opción; la recomendada suele ser razonable, pero tú conoces el negocio. |
| **Gate 1 · Spec** | ¿Los RF describen lo que quiere el negocio? ¿Están los errores y los casos límite? ¿Está claro qué queda fuera? |
| **Gate 2 · Plan y tareas** | ¿Reutiliza los patrones del proyecto? ¿Dependencias nuevas? ¿La estrategia de tests cubre cada RF? ¿Las tareas son pequeñas? |
| Commits propuestos | Ejecútalos tú (o autoriza a `sdd-archivist`). |
| `BLOQUEADO` | Lee el motivo: normalmente falta una decisión tuya o el plan tiene un hueco. |
| **Gate 3 · Aceptación** | Veredictos, pendientes manuales y la descripción del PR. |

Responde con claridad: «apruebo», «apruebo con este cambio: ...» o «no: ...». El orquestador no interpreta silencios como aprobaciones.

## 5. Ramas y commits

- **Una spec = una rama = un PR.** La rama `feature/NNN-nombre` (o `fix/NNN-descripcion`) sale de `dev` y se crea **antes** del primer artefacto:
  ```bash
  git checkout dev && git pull
  git checkout -b feature/NNN-nombre
  ```
- Commits en cuatro momentos, todos con el pie `Refs: NNN-nombre`, sin mezclar planificación y código:
  1. Planificación aprobada → `docs(sdd): planifica NNN-nombre`
  2. Cada tarea en verde → `feat(...)`, `fix(...)`, ...
  3. Correcciones de revisión o verificación → `fix(...)` o `refactor(...)`
  4. Cierre → `docs(sdd): cierra NNN-nombre`
- El push y el PR (hacia `dev`) los haces tú. El **título del PR** va en formato Conventional Commits (con *squash merge* es el commit que llega a `dev`). La descripción te la entrega el cierre.
- Integración: `feature/NNN-nombre` → PR a `dev` → validación → QA → `main`.

## 6. Elección de modelo por agente (recomendación)

Potencia, velocidad y coste: elige según la tarea. Puedes fijarlo con `model:` en el frontmatter de cada agente (lista en orden de preferencia).

| Agentes | Perfil de modelo | Motivo |
|---|---|---|
| `sdd-spec-writer`, `sdd-spec-reviewer`, `sdd-architect` | El más potente (razonamiento) | Los errores aquí se multiplican después. |
| `sdd-orchestrator`, `tdd-test-author`, `tdd-implementer` | Potente o medio, bueno en código | Volumen de trabajo con criterio. |
| `code-reviewer`, `sdd-verifier` | Potente y **de una familia distinta** a la del implementador | Un segundo par de ojos con sesgos distintos. |
| `sdd-explorer`, `sdd-task-planner`, `sdd-archivist` | Rápido o medio | Tareas más mecánicas. |

## 7. Buenas prácticas

- **Specs pequeñas**: si salen más de 10 tareas, divide. Una HU de negocio suele ser varias specs.
- **Habla de negocio en la spec y de técnica en el plan.** Si te descubres pidiendo un componente concreto en la spec, guárdalo para el Gate 2.
- **No saltes la clarificación**: es donde se evitan la mayoría de los retrabajos.
- **Lee los tests RED** de las tareas críticas: son la especificación ejecutable.
- **Cambios de requisitos, siempre con `/sdd-change`**, nunca pidiendo «arréglalo en el código».
- **Contexto limpio**: empieza un chat nuevo por spec. La memoria está en `MEMORY.md` y en `specs/`, no en el chat.

## 8. Solución de problemas

| Síntoma | Causa probable | Solución |
|---|---|---|
| `sdd-orchestrator` no aparece en el selector | Archivo fuera de `.github/agents` o frontmatter inválido | Comprueba la ruta y el YAML; abre **Chat: Open Customizations** para ver los errores. |
| Los comandos `/sdd-*` no aparecen | Los prompt files solo funcionan en el harness Local (vista de chat de VS Code) | En otros harnesses, habla directamente con `sdd-orchestrator`. |
| Una skill no se carga | `name` distinto del nombre de la carpeta o con caracteres no válidos | El `name` debe coincidir exactamente con la carpeta (minúsculas, números y guiones). |
| El orquestador no delega | Falta la herramienta `agent` o el subagente no está en `agents:` | Revisa el frontmatter del orquestador y los nombres (distinguen mayúsculas). |
| Una acción se bloquea con «[Guardarraíl SDD] ...» | El hook aplicó la política | Es intencionado: lee el motivo. Para cambiarlo, edita `.github/hooks/sdd-policy.json`. |
| El hook no hace nada | Hooks desactivados o Node no instalado | Activa `chat.useHooks` (harness Local) e instala Node 18+. Diagnóstico: `SDD_HOOK_DEBUG=1`. |
| Los tests se quedan colgados | Comando en modo watch | Usa el comando sin watch de `AGENTS.md` (por ejemplo, `--watch=false`). |
