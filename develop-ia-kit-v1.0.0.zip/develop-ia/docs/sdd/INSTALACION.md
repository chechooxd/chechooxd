# Instalación del kit SDD + TDD en un repositorio

## Requisitos

| Requisito | Para qué |
|---|---|
| VS Code actualizado con GitHub Copilot | Agentes personalizados, subagentes, skills, prompt files, instrucciones y hooks |
| Node.js 18 o superior | Hook de guardarraíles (opcional pero recomendado; sin Node, el hook no bloquea nada) |
| Git | Ramas y commits del flujo |
| Chrome (opcional) | MCP de Chrome DevTools para verificar la interfaz |

## 1. Copiar el kit

Copia en la raíz del repositorio de destino:

```text
.github/agents/            .github/skills/          .github/instructions/
.github/prompts/           .github/hooks/           .github/copilot-instructions.md
AGENTS.md                  MEMORY.md                docs/constitution.md
docs/adr/README.md         docs/sdd/                specs/README.md
.vscode/settings.json      .vscode/mcp.json  (opcional)
```

En macOS, desde la carpeta del kit:

```bash
rsync -av --exclude '/README.md' --exclude '/CHANGELOG.md' --exclude '.git/' ./ /ruta/al/repositorio/
```

> Si el repositorio ya tiene `.github/copilot-instructions.md`, `AGENTS.md` o `.vscode/settings.json`, **fusiónalos** en lugar de sobrescribirlos.
> Las carpetas que empiezan por punto están ocultas en Finder: `Cmd + Shift + .` para verlas.

## 2. Adaptar al repositorio

1. **Perfiles de stack**: deja solo el que aplique en `.github/instructions/` (`angular.instructions.md` para el frontend, `dotnet.instructions.md` para el backend) y revisa versiones y librerías.
2. **AGENTS.md**: si el repositorio tiene un perfil en `docs/sdd/perfiles/` (`AGENTS.frontend-angular.md` o `AGENTS.backend-dotnet.md`), cópialo como `AGENTS.md` en la raíz: ya trae el stack, el contrato y las convenciones confirmados.
3. Abre el chat de Copilot y ejecuta **`/sdd-init`**: completa o verifica `AGENTS.md`, `MEMORY.md` y `testGlobs` de `.github/hooks/sdd-policy.json` con datos reales. Resuelve todo lo marcado como `<CONFIRMAR: ...>`.
4. Ejecuta **`/sdd-constitution`** y aprueba (o ajusta) los principios.
5. Haz commit: `chore(sdd): instala el kit SDD + TDD`.

## 3. Comprobar la instalación

- [ ] El selector de agentes muestra **`sdd-orchestrator`** (y no muestra los subagentes).
- [ ] Al escribir `/` en el chat aparecen los comandos **`/sdd-*`**.
- [ ] **Chat: Open Customizations** lista 11 agentes, 15 skills, las instrucciones y el hook, sin errores.
- [ ] El hook responde (desde la raíz del repositorio):
  ```bash
  echo '{"toolName":"edit","toolArgs":{"path":".env"}}' | node .github/hooks/scripts/sdd-guardrails.mjs
  # → {"permissionDecision":"deny", ...}
  ```
- [ ] `/sdd-status` responde sin errores.

## 4. Compatibilidad por entorno

| Elemento | VS Code (harness Local) | Copilot CLI / harness Copilot | Copilot coding agent (GitHub.com) |
|---|---|---|---|
| `AGENTS.md`, `copilot-instructions.md`, `*.instructions.md` | ✅ | ✅ | ✅ |
| Agentes y subagentes (`.github/agents`) | ✅ | ✅ (delegación con su herramienta nativa) | ✅ (sin handoffs ni `argument-hint`) |
| Skills (`.github/skills`) | ✅ | ✅ | ✅ |
| Comandos `/sdd-*` (prompt files) | ✅ | ❌ (habla directamente con `sdd-orchestrator`) | ❌ |
| Hook de guardarraíles | ✅ con `chat.useHooks` | ✅ | Según la configuración de la organización |
| MCP (`.vscode/mcp.json`) | ✅ | Configuración propia del CLI | Configuración del repositorio en GitHub |

## 5. Actualizar el kit

- El kit vive en su propio repositorio (`develop-ia`). Para actualizar un proyecto, copia de nuevo `.github/agents`, `.github/skills`, `.github/prompts`, `.github/hooks/scripts` y `docs/sdd`.
- **No sobrescribas** los archivos adaptados al proyecto: `AGENTS.md`, `MEMORY.md`, `docs/constitution.md`, `.github/hooks/sdd-policy.json` (`testGlobs`), los perfiles de stack y `specs/`.
- Registra los cambios del kit con su propio versionado (por ejemplo, `CHANGELOG.md` del repositorio `develop-ia`).
