# AGENTS.md — API Backoffice Notificaciones (backend)
API .NET 10 que da servicio al Backoffice de Notificaciones (frontend Angular en otro repositorio).

## Stack y estructura
- .NET 10 · EF Core 10 · Tests: xUnit + Moq `<CONFIRMAR>`.
- Capas: `Controller → Handler (IHandler) → Repository (IRepository)`; DTOs en `Models/DTO`; middleware de errores en `ApiBackofficeNotificaciones.Api.Middlewares`.
- `<CONFIRMAR: carpetas de proyectos de la solución y del proyecto de tests>`

## Comandos
- Restaurar: `dotnet restore` · Build: `dotnet build`
- Tests (suite completa): `dotnet test`
- Tests por RF: `dotnet test --filter "DisplayName~RF-03"`
- Formato (solo comprobar): `<CONFIRMAR: dotnet format --verify-no-changes>`

## Contrato con el frontend
- Toda respuesta va envuelta en `ResponseData<T>` (propiedad `Data`), con `ResponseMeta` en los endpoints paginados (`PaginaActual`, `TotalPaginas`, `TotalRegistros`).
- Los errores se propagan y el middleware los convierte en `ResponseError`: Handlers y Repositories no capturan excepciones para formatearlas.
- Cambiar la forma de un endpoint existente (campos de `Data`, `ResponseMeta`, `ResponseError`, ruta, verbo, parámetros) es un **cambio de contrato**: se declara en el plan y se comunica al frontend antes del cierre.

## Convenciones
- Código, nombres, comentarios y logs **en español**.
- Nomenclatura por entidad: `ClienteController`, `IClienteHandler`/`ClienteHandler`, `IClienteRepository`/`ClienteRepository`; registro con `AddScoped` en `Program.cs`.
- Constructores primarios para DI; `async`/`await` con `CancellationToken` en todas las firmas.
- EF Core: `AsNoTracking()` en lecturas; **prohibido `Include`/`ThenInclude`**, proyección `.Select()` al DTO; ninguna consulta devuelve entidades.

## Ramas y PR
- Rama de integración `dev`. Una spec = `feature/NNN-nombre` desde `dev` (antes del primer artefacto) = un PR a `dev` → QA → `main`.
- Commits con la skill `conventional-commits` y el pie `Refs: NNN-nombre`.

## Forma de trabajar (SDD + TDD)
- Funcionalidades, cambios y bugs: agente `sdd-orchestrator` o comandos `/sdd-*`.
- TDD: tests de Handler con el `IRepository` sustituido por un doble; tests de Repository con el mecanismo de EF Core ya establecido en el proyecto.

## Memoria
- Al empezar, lee `MEMORY.md`; al cerrar una spec o un bugfix, actualízalo (máximo unas 50 líneas).

## Límites
- ✅ Siempre: respetar capas y contrato; ejecutar `dotnet test` completo antes de dar algo por terminado.
- ⚠️ Pregunta antes: dependencias nuevas, migraciones, cualquier cambio de contrato.
- 🚫 Nunca: exponer entidades; usar `Include`; capturar excepciones para formatear errores; secretos en `appsettings*.json`; `git push`, `--force` ni `--no-verify`.

## Verificación
- `dotnet build` sin errores y `dotnet test` completo en verde, con los casos de error de la spec cubiertos.
