# Architecture Decision Records (ADR)

Decisiones técnicas que afectan a más de una spec o que son difíciles de revertir. Las genera `sdd-architect` durante el diseño técnico.

- Nombre: `NNNN-titulo-en-kebab.md` (numeración propia, de cuatro dígitos).
- Plantilla: `.github/skills/technical-design/assets/adr-template.md`.
- Un ADR aceptado no se edita: si la decisión cambia, se crea otro que lo reemplaza y se marca el anterior como `Reemplazado por ADR NNNN`.

| ADR | Título | Estado | Spec origen |
|---|---|---|---|
| — | — | — | — |
