# MEMORY.md — <Nombre del proyecto>
Memoria del proyecto entre sesiones. Máximo unas 50 líneas: resume o elimina lo que ya no aporte. Nunca guardes secretos ni datos personales.

## Estado actual
- Kit SDD + TDD instalado. Constitución pendiente de proponer (`/sdd-constitution`).

## Decisiones (y por qué)
- Desarrollo con SDD *spec-anchored* + TDD estricto mediante un orquestador y subagentes por etapa: separa responsabilidades y deja evidencia verificable.

## Aprendizajes y errores a evitar
- (vacío por ahora)

## Próximos pasos
- Completar `AGENTS.md` con `/sdd-init`.
- Proponer y ratificar la constitución con `/sdd-constitution`.
