# Changelog del kit

Formato basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.1.0/) y versionado semántico.

## [1.0.0] - 2026-10-23

### Añadido
- Orquestador `sdd-orchestrator` y 10 subagentes especializados por etapa (exploración, especificación, QA de specs, diseño, tareas, TDD RED, TDD GREEN + REFACTOR, revisión, verificación y cierre).
- 15 skills propias con plantillas: flujo SDD, constitución, exploración, EARS, QA de specs, diseño técnico y contratos, troceado de tareas, ciclo TDD, depuración sistemática, revisión de código, verificación estricta, cierre, gestión de cambios, Conventional Commits y memoria del proyecto.
- Instrucciones por patrón: artefactos SDD, tests, seguridad, perfiles Angular 20 y .NET 10, memoria, mensajes de commit y mantenimiento del kit.
- Comandos `/sdd-*`: flujo completo, etapas individuales, cambio, bugfix, estado e instalación.
- Hook de guardarraíles `preToolUse` con política por agente (fail-open).
- Plantillas de `AGENTS.md`, `MEMORY.md` y constitución; guía, arquitectura e instalación.
- Perfiles de `AGENTS.md` para el frontend Angular y el backend .NET, y listas de diseño y revisión por stack, a partir de las reglas ya confirmadas en la versión anterior con OpenSpec (contrato `ResponseData<T>`, capas, EF Core sin `Include`, patrones de estado, protocolo de preguntas al backend y ramas `feature/*` desde `dev`).
