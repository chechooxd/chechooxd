#!/usr/bin/env node
/**
 * Guardarraíles SDD + TDD para GitHub Copilot (hook preToolUse / PreToolUse).
 *
 * Qué hace:
 *  - Bloquea escrituras en secretos y comandos destructivos para cualquier agente.
 *  - Cuando la llamada viene de un subagente SDD identificado, aplica su política de rutas
 *    (p. ej. tdd-implementer no puede tocar tests; sdd-spec-writer solo puede escribir spec.md).
 *
 * Diseño:
 *  - Sin dependencias. Node 18+.
 *  - FAIL-OPEN: ante cualquier error interno responde "{}" (sin decisión) para no bloquear el trabajo.
 *  - Acepta el formato nativo de Copilot (toolName/toolArgs, camelCase) y el compatible con
 *    VS Code / Claude (tool_name/tool_input, snake_case).
 *  - Responde con los dos formatos de decisión (raíz y hookSpecificOutput).
 *
 * Depuración: SDD_HOOK_DEBUG=1 escribe el diagnóstico en stderr.
 */
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const DEBUG = process.env.SDD_HOOK_DEBUG === '1';
const debug = (...args) => { if (DEBUG) process.stderr.write(`[sdd-guardrails] ${args.join(' ')}\n`); };

const PATH_KEYS = new Set([
  'path', 'paths', 'file', 'files', 'filepath', 'file_path', 'filepaths', 'file_paths',
  'uri', 'target_file', 'targetfile', 'notebook_path', 'notebookpath', 'dirpath', 'dir_path',
  'old_path', 'new_path', 'oldpath', 'newpath', 'destination', 'source',
]);
const COMMAND_KEYS = new Set(['command', 'cmd', 'commandline', 'command_line', 'script']);
const SHELL_TOOL = /(bash|shell|powershell|pwsh|terminal|execute|run_?in_?terminal)/i;
const WRITE_TOOL = /(edit|write|create|replace|insert|patch|apply|delete|rename|move|str_replace)/i;

function respond(obj) {
  process.stdout.write(JSON.stringify(obj));
}

function deny(reason) {
  const message = `[Guardarraíl SDD] ${reason}`;
  respond({
    permissionDecision: 'deny',
    permissionDecisionReason: message,
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason: message,
    },
  });
}

function escapeRe(s) {
  return s.replace(/[.+^${}()|[\]\\]/g, '\\$&');
}

/** Glob → RegExp. Soporta **, *, ? y {a,b}. Coincidencia sin distinguir mayúsculas. */
export function globToRegExp(glob) {
  let re = '';
  for (let i = 0; i < glob.length;) {
    const c = glob[i];
    if (c === '*') {
      if (glob[i + 1] === '*') {
        const atStart = i === 0 || glob[i - 1] === '/';
        if (atStart && glob[i + 2] === '/') { re += '(?:.*/)?'; i += 3; continue; }
        re += '.*'; i += 2; continue;
      }
      re += '[^/]*'; i += 1; continue;
    }
    if (c === '?') { re += '[^/]'; i += 1; continue; }
    if (c === '{') {
      const end = glob.indexOf('}', i);
      if (end > i) {
        re += `(?:${glob.slice(i + 1, end).split(',').map(escapeRe).join('|')})`;
        i = end + 1; continue;
      }
    }
    re += escapeRe(c); i += 1;
  }
  return new RegExp(`^${re}$`, 'i');
}

function matchesAny(relPath, globs) {
  return globs.some((g) => globToRegExp(g).test(relPath));
}

function expandGlobs(globs = [], policy) {
  return globs.flatMap((g) => (g === '$TESTS' ? policy.testGlobs || [] : [g]));
}

function parseMaybeJson(value) {
  if (typeof value !== 'string') return value ?? {};
  try { return JSON.parse(value); } catch { return { input: value }; }
}

/** Recorre los argumentos de la herramienta y extrae rutas y comandos. */
function extractTargets(args) {
  const paths = [];
  const commands = [];
  const visit = (node, key = '') => {
    if (node == null) return;
    const k = key.toLowerCase();
    if (typeof node === 'string') {
      if (PATH_KEYS.has(k)) paths.push(node);
      if (COMMAND_KEYS.has(k)) commands.push(node);
      if (k === 'input' || k === 'patch') {
        // Formato apply_patch: "*** Update File: ruta", "*** Add File: ruta", "*** Move to: ruta"
        for (const m of node.matchAll(/^\*\*\* (?:Add|Update|Delete) File: (.+)$|^\*\*\* Move to: (.+)$/gm)) {
          paths.push((m[1] || m[2]).trim());
        }
      }
      return;
    }
    if (Array.isArray(node)) { node.forEach((item) => visit(item, key)); return; }
    if (typeof node === 'object') {
      for (const [childKey, value] of Object.entries(node)) visit(value, childKey);
    }
  };
  visit(args);
  return { paths, commands };
}

function toRepoRelative(p, cwd) {
  let value = String(p).trim();
  if (value.startsWith('file://')) {
    try { value = fileURLToPath(value); } catch { /* se deja tal cual */ }
  }
  const abs = path.isAbsolute(value) ? value : path.resolve(cwd, value);
  let rel = path.relative(cwd, abs);
  if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) rel = abs; // fuera del repositorio
  return rel.split(path.sep).join('/').replace(/^\.\//, '');
}

function identifyAgent(payload, policy) {
  const raw = [
    payload.agentType, payload.agent_type, payload.agentName, payload.agent_name,
    payload.agentId, payload.agent_id, payload.customAgent, payload.custom_agent,
  ].filter((v) => typeof v === 'string' && v.length > 0).join(' ').toLowerCase();
  if (!raw) return null;
  const names = Object.keys(policy.agents || {});
  return names.find((n) => raw === n) || names.find((n) => raw.includes(n)) || null;
}

function checkCommand(command, ruleIds, policy, exempt = []) {
  for (const id of ruleIds) {
    if (exempt.includes(id)) continue;
    const rule = policy.rules?.[id];
    if (rule && new RegExp(rule.pattern, 'i').test(command)) return `${rule.reason} (regla: ${id})`;
  }
  return null;
}

function checkWrite(relPath, agentName, policy, { directoryOnly = false } = {}) {
  const g = policy.global || {};
  if (!matchesAny(relPath, g.allowWrite || []) && matchesAny(relPath, g.denyWrite || [])) {
    return `Escritura bloqueada en un archivo protegido: ${relPath}`;
  }
  // Crear una carpeta vacía es inocuo: solo se aplican las reglas globales.
  if (!agentName || directoryOnly) return null;

  if (matchesAny(relPath, policy.sddAgents?.denyWrite || [])) {
    return `${agentName} no puede modificar los archivos del kit ni AGENTS.md: ${relPath}`;
  }
  const a = policy.agents[agentName] || {};
  if (Array.isArray(a.writeOnly)) {
    const allowed = expandGlobs(a.writeOnly, policy);
    if (!matchesAny(relPath, allowed)) {
      return allowed.length === 0
        ? `${agentName} es de solo lectura y no puede escribir ${relPath}`
        : `${agentName} solo puede escribir en: ${a.writeOnly.map((g) => (g === '$TESTS' ? 'archivos de test' : g)).join(', ')}. Bloqueado: ${relPath}`;
    }
  }
  if (Array.isArray(a.denyWrite)) {
    const denied = expandGlobs(a.denyWrite, policy);
    const allowed = expandGlobs(a.allowWrite || [], policy);
    if (matchesAny(relPath, denied) && !matchesAny(relPath, allowed)) {
      return `${agentName} no puede modificar ${relPath} (separación de funciones TDD/SDD)`;
    }
  }
  return null;
}

export function evaluate(payload, policy) {
  const toolName = String(payload.toolName ?? payload.tool_name ?? '');
  const args = parseMaybeJson(payload.toolArgs ?? payload.tool_input ?? payload.toolInput);
  const cwd = payload.cwd || process.cwd();
  const agentName = identifyAgent(payload, policy);
  const { paths, commands } = extractTargets(args);
  debug('tool=', toolName, 'agent=', agentName ?? '-', 'paths=', JSON.stringify(paths), 'commands=', JSON.stringify(commands));

  // 1) Comandos de shell
  if (commands.length > 0 && (SHELL_TOOL.test(toolName) || !WRITE_TOOL.test(toolName))) {
    const agentPolicy = agentName ? policy.agents[agentName] || {} : {};
    const ruleIds = [
      ...(policy.global?.denyRules || []),
      ...(agentName ? policy.sddAgents?.denyRules || [] : []),
      ...(agentPolicy.extraDenyRules || []),
    ];
    for (const command of commands) {
      const reason = checkCommand(command, ruleIds, policy, agentPolicy.exemptRules || []);
      if (reason) return { decision: 'deny', reason };
    }
  }

  // 2) Escrituras de archivos (las subórdenes de lectura de editores tipo str_replace_editor no cuentan)
  const subcommand = typeof args?.command === 'string' ? args.command.toLowerCase() : '';
  const isReadSubcommand = ['view', 'read', 'list'].includes(subcommand);
  const directoryOnly = /(directory|folder|mkdir)/i.test(toolName);
  if (WRITE_TOOL.test(toolName) && !SHELL_TOOL.test(toolName) && !isReadSubcommand) {
    for (const p of paths) {
      const reason = checkWrite(toRepoRelative(p, cwd), agentName, policy, { directoryOnly });
      if (reason) return { decision: 'deny', reason };
    }
  }
  return { decision: 'none' };
}

function loadPolicy() {
  const here = path.dirname(fileURLToPath(import.meta.url));
  return JSON.parse(readFileSync(path.resolve(here, '..', 'sdd-policy.json'), 'utf8'));
}

function main() {
  try {
    let raw = '';
    try { raw = readFileSync(0, 'utf8'); } catch { raw = ''; }
    if (!raw.trim()) { respond({}); return; }
    const payload = JSON.parse(raw);
    const result = evaluate(payload, loadPolicy());
    if (result.decision === 'deny') { debug('DENY', result.reason); deny(result.reason); return; }
    respond({});
  } catch (error) {
    debug('error interno (fail-open):', error?.message ?? String(error));
    respond({});
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main();
}
