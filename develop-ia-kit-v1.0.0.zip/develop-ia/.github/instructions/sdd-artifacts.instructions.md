---
name: "SDD · Artefactos de specs"
description: "Reglas para crear o editar artefactos SDD en specs/ (research, spec, plan, contracts, tasks, review, verification)."
applyTo: "specs/**"
---

# Artefactos SDD (`specs/`)

- Cada spec vive en `specs/NNN-nombre-en-kebab/`. `NNN` es el siguiente número libre y nunca se reutiliza.
- Cada artefacto tiene un dueño y solo él lo edita: `research.md` (sdd-explorer), `spec.md` (sdd-spec-writer), `plan.md` y `contracts/` (sdd-architect), `tasks.md` (sdd-task-planner; la evidencia la añaden tdd-test-author y tdd-implementer), `review.md` y `verification.md` (sdd-archivist).
- Usa siempre la plantilla de la skill correspondiente y mantén la cabecera de estado actualizada (`Estado`, `Versión`, fecha).
- `spec.md` contiene solo el QUÉ y el POR QUÉ, con los RF en EARS. Nada de tecnologías, archivos ni endpoints.
- Identificadores estables (`HU-nn`, `RF-nn`, `RNF-nn`, `CL-nn`, `D-nn`, `EXT-nn`, `Tnn`): nunca se renumeran ni se reutilizan. Lo eliminado se tacha y se marca como obsoleto con el motivo.
- Toda duda sin resolver se marca `[NECESITA ACLARACIÓN: ...]`. Una spec con marcas pendientes no puede aprobarse.
- Los cambios de estado `Aprobada` o `Vigente` solo se hacen tras la aprobación explícita del usuario.
- Fechas en formato `AAAA-MM-DD`. Idioma: el que fije la constitución.
- Los informes de revisión y verificación se copian literalmente; no se resumen ni se suavizan.
