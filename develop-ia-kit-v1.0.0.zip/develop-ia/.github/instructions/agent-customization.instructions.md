---
name: "Kit SDD · Mantenimiento de agentes, skills y prompts"
description: "Reglas para crear o modificar agentes, skills, prompts, instrucciones y hooks del kit SDD + TDD de Copilot."
applyTo: ".github/agents/**,.github/skills/**,.github/prompts/**,.github/instructions/**,.github/hooks/**"
---

# Mantenimiento del kit SDD + TDD

## Formatos
- **Agentes**: `.github/agents/<nombre>.agent.md`. El `name` del frontmatter coincide con el nombre del archivo (kebab-case), porque los nombres de `agents:` distinguen mayúsculas. Los subagentes llevan `user-invocable: false`.
- **Skills**: `.github/skills/<nombre>/SKILL.md`. `name` en minúsculas, números y guiones, de 64 caracteres como máximo e **igual al nombre de la carpeta** (si no, la skill no carga y no avisa). `description` de 1024 caracteres como máximo, diciendo qué hace y cuándo usarla. Las plantillas van en `assets/` y la documentación larga en `references/`.
- **Prompts**: `.github/prompts/<nombre>.prompt.md`, con `description`, `argument-hint` y `agent`.
- **Instrucciones**: `.github/instructions/<nombre>.instructions.md`, con `description` y `applyTo` (globs separados por comas).
- **YAML**: entrecomilla todo valor que contenga `: `, `#` o empiece por un carácter especial. Un valor sin comillas con `: ` rompe el frontmatter.

## Coherencia
- Si cambias el nombre de un agente, actualiza la lista `agents:` del orquestador, la política de `.github/hooks/sdd-policy.json` y la documentación de `docs/sdd/`.
- Si añades una etapa, actualiza la skill `sdd-workflow`, el orquestador, los prompts y `docs/sdd/ARQUITECTURA.md`.
- Las rutas a otros archivos se escriben como enlaces Markdown relativos al propio archivo.
- Los subagentes no ven la conversación: todo lo que necesiten debe estar en su archivo, en sus skills o en el encargo del orquestador.

## Límites
- El cuerpo de un agente no debe pasar de 30 000 caracteres; lo detallado va a una skill.
- No dupliques reglas entre `AGENTS.md`, `copilot-instructions.md`, instrucciones y skills: cada regla vive en un solo sitio y los demás la referencian.
