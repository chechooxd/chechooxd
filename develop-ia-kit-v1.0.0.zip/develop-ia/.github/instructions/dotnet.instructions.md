---
name: "Stack · .NET 10"
description: "Perfil de stack .NET 10 / C# para API: capas Controller, Handler y Repository, DTOs, contrato ResponseData, errores centralizados, EF Core sin Include, async con CancellationToken, xUnit y Moq. Elimina este archivo si el repositorio no es .NET."
applyTo: "**/*.cs,**/*.csproj"
---

# .NET 10

> Perfil de stack. Ajusta las librerías a lo que digan los `*.csproj` y `Directory.Packages.props`; si algo no coincide con el repositorio, manda el repositorio.
> ⚠️ **Confirmar** el stack de tests: se asume **xUnit + Moq**. Si el proyecto usa NUnit, MSTest u otra librería de dobles, ajusta esta sección y `tdd-cycle/references/test-commands.md`.

## Arquitectura (capas estrictas)
- Flujo **`Controller → Handler (IHandler) → Repository (IRepository)`**. Prohibido saltar capas (un Controller que llama a un Repository) o mezclar responsabilidades (acceso a datos en el Handler, lógica de caso de uso en el Repository, formateo HTTP fuera del Controller).
- Nomenclatura por entidad: `ClienteController`, `IClienteHandler` / `ClienteHandler`, `IClienteRepository` / `ClienteRepository`. Las interfaces nuevas se registran en `Program.cs` con `AddScoped`.
- Métodos con nombre de caso de uso (`ObtenerClientesActivosAsync`), no genéricos (`GetAsync`).
- Inyección de dependencias con **constructores primarios**. Configuración con el patrón Options (`IOptions<T>`).
- **Reloj**: `TimeProvider` inyectado, nunca `DateTime.Now` ni `DateTime.UtcNow` en la lógica.

## Contrato con el frontend
- Ninguna consulta devuelve entidades de dominio: siempre **DTOs** (`Models/DTO`). Exponer una entidad es un defecto crítico.
- Los Handlers devuelven la respuesta envuelta en **`ResponseData<T>`** (con **`ResponseMeta`** en los endpoints paginados). Nunca otro formato: es el contrato que consume el frontend.
- Los errores **no se capturan** en Handlers ni Repositories para formatearlos: se propagan y el middleware los convierte en **`ResponseError`**.
- **Cambio de contrato = posible ruptura del frontend.** Añadir, quitar o renombrar campos de `Data`, cambiar `ResponseMeta`, códigos de error, ruta, verbo o parámetros obligatorios de un endpoint existente solo se hace si el plan lo marca como cambio aprobado. Si no, para y repórtalo.

## EF Core y rendimiento
- `.AsNoTracking()` (o `.AsNoTrackingWithIdentityResolution()`) en **todas** las lecturas.
- **Prohibido `.Include()` y `.ThenInclude()`**: proyecta con `.Select()` directamente al DTO, trayendo solo las columnas necesarias.
- Sin N+1: lo que puede resolverse en una consulta no se hace en varias. Paginación en el servidor.
- `async`/`await` de punta a punta con **`CancellationToken`** en la firma y propagado. Prohibido `.Result`, `.Wait()` y `async void`.
- Cambios de esquema con migración explícita y compatible hacia atrás.

## Lenguaje y estilo
- `Nullable` habilitado (sin `!` para silenciar avisos sin justificación); namespaces de archivo (`namespace X;`); `record` para DTOs inmutables. Nada de `dynamic`.
- Idioma de nombres, comentarios y logs: el que fije la constitución del repositorio.
- *Early returns* y *guard clauses*; sin números ni cadenas mágicas; sin sobreingeniería (capas o patrones que no resuelven un problema real del cambio).
- `ILogger<T>` con plantillas estructuradas (`_logger.LogInformation("Envío {Id} programado", id)`), nunca con interpolación. Sin datos personales ni secretos.
- Valida las entradas en la frontera (comprueba si FluentValidation está instalado antes de usarlo).

## Tests (xUnit + Moq, a confirmar)
- Suite completa: `dotnet test`. Por RF: `dotnet test --filter "DisplayName~RF-03"`.
- `[Fact(DisplayName = "RF-03: ...")]`; nombre del método `Metodo_Escenario_ResultadoEsperado`.
- **Handlers**: tests unitarios con el `IRepository` sustituido por un doble (Moq). Un test de Handler nunca usa la base de datos real ni un repositorio concreto.
- **Repositories**: el mecanismo de test de EF Core que ya use el proyecto (revisa los tests existentes antes de elegir otro).
- Cubre los casos de error de la spec (qué `ResponseError` se espera y cuándo), no solo el camino feliz.
- Tiempo con `FakeTimeProvider` (si `Microsoft.Extensions.TimeProvider.Testing` está instalado) o un `TimeProvider` falso propio.
- Integración de API con `WebApplicationFactory<Program>` si el proyecto la usa.

## Prohibido
- Secretos en `appsettings*.json` versionados.
- SQL concatenado con entradas (usa parámetros o LINQ).
- Capturar `Exception` para formatear respuestas o tragarla sin registrarla.
