---
name: "Stack · Angular 20"
description: "Perfil de stack Angular 20 (standalone, signals, zoneless, PrimeNG, Karma y Jasmine): componentes, estado (legacy con signals o NgRx Signal Store), contrato con el backend, calidad y tests. Elimina este archivo si el repositorio no es Angular."
applyTo: "**/*.ts,**/*.html,**/*.scss,**/*.css"
---

# Angular 20

> Perfil de stack. Ajusta las versiones y librerías a lo que diga `package.json`; si algo de aquí no coincide con el repositorio, manda el repositorio.

## Antes de crear algo nuevo
- Busca si ya existe: componentes compartidos en `shared/components/`, servicios en `core/` y features en `feature/` (los concretos del proyecto están en `AGENTS.md`). Extiende antes de crear.
- Importa a través de los barrel exports del proyecto (por ejemplo, `@app/core` y `@app/shared`).

## Componentes
- Componentes **standalone** (por defecto en v20: no declares `standalone: true`). Nada de `NgModule` nuevos.
- `changeDetection: ChangeDetectionStrategy.OnPush` en todos los componentes.
- Entradas y salidas con funciones: `input()`, `input.required()`, `output()`, `model()`. No uses los decoradores `@Input` ni `@Output` en código nuevo.
- Inyección con `inject()` en código nuevo. Depende de abstracciones (tipos e interfaces), nunca instancies dependencias concretas.
- **Smart vs presentational**: los componentes contenedores son dueños del estado y la orquestación; los de presentación solo reciben `input()` y emiten `output()`.
- Plantillas con control de flujo nativo: `@if`, `@for` (**siempre con `track`**), `@switch` y `@defer` para contenido no crítico del primer render. No uses `*ngIf` ni `*ngFor` en código nuevo.
- Sigue la convención de nombres de archivo que ya usa el repositorio.

## Estado: dos patrones que no son intercambiables
- **Estado local** de un componente: siempre `signal()` del componente; lo derivado, con `computed()`.
- **Legacy** (mayoría del código existente): servicio singleton con `signal<T>()` plano. Si extiendes una feature que ya sigue este patrón, **mantén la consistencia**: no introduzcas NgRx Signal Store a mitad de una feature.
- **Objetivo**, solo para estado nuevo y realmente compartido entre features: NgRx Signal Store (`withState`, `withComputed`, `withMethods`, `rxMethod` para lo asíncrono, `withFeature` para componer). **Comprueba antes que `@ngrx/signals` está en `package.json`**; si no está, dilo: instalarlo es alcance del cambio y requiere aprobación.
- Si ya existe un store dueño del dominio, extiéndelo en lugar de crear otro. Si no es obvio qué patrón aplica, **pregunta** (o márcalo como decisión en el plan).
- `effect()` solo para sincronizar con APIs externas, nunca para derivar estado. RxJS para flujos asíncronos complejos, con `toSignal()` en la frontera con la vista y `takeUntilDestroyed()` para cerrar suscripciones.
- **Zoneless**: no dependas de `zone.js` (nada de `NgZone.run` ni de la detección automática tras `setTimeout`).

## Backend y contrato HTTP
- El backend vive en otro repositorio: **nunca asumas ni infieras** su contrato (payloads, campos, códigos de error, paginación, autenticación). Lo que no esté documentado en `specs/NNN/contracts/` o en `AGENTS.md` es una pregunta `EXT-nn` del plan.
- Respeta el envoltorio de respuesta confirmado del proyecto (ver `AGENTS.md`). Si encuentras código o documentación con un envoltorio distinto del confirmado, está desactualizado: señálalo, no lo repliques.
- HTTP mediante el servicio base del proyecto y servicios tipados. Formularios reactivos tipados (`FormGroup<...>`, `nonNullable`). Rutas con carga diferida (`loadComponent`, `loadChildren`).

## Calidad (no negociable)
- **SOLID**: un componente no mezcla orquestación de estado con presentación; un servicio no crece hacia dominios ajenos; extiende por composición (inputs, proyección de contenido, `withFeature`) antes de modificar algo con consumidores.
- **Rendimiento**: nada de lógica pesada en los bindings (muévela a `computed()`); no crees objetos ni arrays nuevos en cada detección de cambios desde la plantilla.
- **Clean Code**: nombres con intención (nada de `data`, `item`, `temp`), funciones pequeñas, *early returns*, sin números ni cadenas mágicas.
- **Patrones solo si resuelven un problema real** (Strategy, Facade, Adapter). La sobreingeniería es un defecto.
- La lógica de negocio va en funciones puras o servicios sin dependencias de la vista. «Hoy» o «ahora» se reciben como parámetro o mediante un servicio de reloj inyectable.
- Si el proyecto usa PrimeNG, usa sus componentes antes de crear otros propios, con el tema existente.
- Accesibilidad: etiquetas en los controles, `aria-*` cuando no haya semántica nativa, foco visible y teclado.

## Tests (Karma + Jasmine)
- Suite completa: `npm run test -- --watch=false` (sin `--watch=false` el proceso no termina).
- Lógica pura: tests sin `TestBed`. Componentes: `TestBed` con `provideZonelessChangeDetection()` y `await fixture.whenStable()`.
- HTTP: `provideHttpClient()` + `provideHttpClientTesting()` y `HttpTestingController` (`httpMock.verify()`), usando como fixture la respuesta de ejemplo del contrato.
- Tiempo: reloj inyectado o `jasmine.clock()`; evita `fakeAsync` en código zoneless.
- Consulta el DOM por rol o texto visible antes que por clases CSS.
- No asumas que existe e2e si el proyecto no lo tiene configurado.

## Prohibido
- `any` (usa `unknown` y estrecha el tipo) y `// @ts-ignore` sin justificar.
- Manipular el DOM directamente (`document.querySelector`) en componentes.
- Lógica de negocio en plantillas o en componentes de presentación.
