---
name: "Seguridad · Reglas globales"
description: "Reglas de seguridad que se aplican a cualquier cambio de código, configuración o documentación."
applyTo: "**"
---

# Seguridad

- **Nunca** escribas secretos, tokens, contraseñas, claves ni cadenas de conexión reales en el código, los tests, la configuración versionada o la documentación. Usa variables de entorno, *user secrets* o el gestor de secretos del proyecto, y valores ficticios evidentes en los ejemplos.
- No edites `.env`, certificados ni archivos de secretos. Si hace falta una variable nueva, añádela a `.env.example` (o equivalente) con un valor ficticio y avisa.
- Valida las entradas en el servidor aunque ya se validen en el cliente. Codifica las salidas; en Angular, nada de `innerHTML` ni `bypassSecurityTrust*` con contenido externo sin sanear.
- Consultas siempre parametrizadas u ORM; nunca concatenes entradas en SQL, comandos o rutas.
- La autorización se comprueba en el servidor en cada operación sensible; ocultar algo en la interfaz no es seguridad.
- No registres en logs datos personales, tokens ni cuerpos completos de peticiones con datos sensibles.
- No añadas dependencias sin aprobación explícita; si se aprueban, comprueba que no tienen vulnerabilidades conocidas.
- Los mensajes de error al usuario no revelan detalles internos (trazas, SQL, rutas del servidor).
- Ningún agente ejecuta comandos destructivos (`rm -rf`, `git push --force`, `git reset --hard`, borrado de bases de datos) ni `--no-verify`.
