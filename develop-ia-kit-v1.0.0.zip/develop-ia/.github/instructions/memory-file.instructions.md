---
name: "Memoria · MEMORY.md"
description: "Reglas para leer y actualizar MEMORY.md, la memoria del proyecto entre sesiones."
applyTo: "MEMORY.md"
---

# MEMORY.md

- Máximo unas 50 líneas: al añadir, resume o elimina lo que ya no aporte.
- Secciones fijas: «Estado actual», «Decisiones (y por qué)», «Aprendizajes y errores a evitar», «Próximos pasos».
- Una línea por entrada, con hechos y no narrativa. Las decisiones, siempre con su porqué.
- Nunca guardes secretos, tokens, contraseñas, datos personales ni datos de clientes.
- Si un aprendizaje debe cumplirse siempre, propón moverlo a `AGENTS.md` o a la constitución en lugar de dejarlo aquí.
- El comportamiento acordado vive en `specs/`, no en la memoria.
