---
name: "Git · Mensajes de commit"
description: "Formato de los mensajes de commit (Conventional Commits con referencia a la spec). Úsalo al generar o proponer mensajes de commit."
---

# Mensajes de commit

- Formato Conventional Commits: `<tipo>(<ámbito>): <asunto>`. Tipos: `feat`, `fix`, `test`, `refactor`, `perf`, `docs`, `style`, `build`, `ci`, `chore`, `revert`.
- Asunto en imperativo, sin punto final, 72 caracteres como máximo, en el idioma del proyecto.
- Cuerpo opcional, separado por una línea en blanco: explica el porqué, no el cómo.
- Si el cambio pertenece a una spec, añade el pie `Refs: NNN-nombre` (lo indica la rama `feature/NNN-nombre` o `fix/NNN-descripcion`).
- Cambio incompatible: `!` tras el tipo y el pie `BREAKING CHANGE: <descripción y migración>`.
- Un commit = un cambio lógico. Los artefactos de planificación usan `docs(sdd): ...`.
