---
description: "SDD · Etapa 4. Genera el diseño técnico (plan.md, contratos y ADR) de una spec aprobada."
argument-hint: "NNN-nombre"
agent: sdd-orchestrator
---

Ejecuta **solo la Etapa 4 · Diseño técnico** de `specs/NNN-nombre/` (identificador en el texto que acompaña a este comando).

1. Comprueba que `spec.md` está `Aprobada` y sin `[NECESITA ACLARACIÓN]`. Si no, para y avísame.
2. Delega en `sdd-architect` (modo `disenar`).
3. Muéstrame: resumen del diseño, decisiones clave con su alternativa descartada, dependencias nuevas (requieren mi aprobación), preguntas `EXT` abiertas y cobertura de RF.

No generes las tareas ni escribas código.
