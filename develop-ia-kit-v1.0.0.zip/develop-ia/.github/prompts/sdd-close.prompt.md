---
description: "SDD · Etapa 9. Cierra la spec: informes, estados, MEMORY.md, CHANGELOG y descripción del PR. Pide la aceptación final."
argument-hint: "NNN-nombre"
agent: sdd-orchestrator
---

Ejecuta **la Etapa 9 · Cierre** de `specs/NNN-nombre/` (identificador en el texto que acompaña a este comando).

1. Comprueba que hay revisión `APROBADO` y verificación `CUMPLE` (o `CUMPLE CON PENDIENTES MANUALES`) en esta sesión. Si no las hay, ejecuta antes las etapas 7 y 8.
2. Delega en `sdd-archivist` (modo `cerrar`) pasándole literalmente los informes finales de revisión y verificación.
3. **Gate 3**: muéstrame el resumen final, los pendientes manuales, la descripción del PR y el commit de cierre propuesto, y pide mi aceptación.
