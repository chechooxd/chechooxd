---
description: "SDD · Instalación. Analiza el repositorio y completa AGENTS.md, MEMORY.md y la política de tests del hook con datos reales (stack, comandos, estructura)."
argument-hint: "Notas sobre el proyecto (opcional)"
agent: agent
tools: ['read', 'search', 'edit', 'execute']
---

Vas a **adaptar el kit SDD + TDD a este repositorio**. Lee primero `docs/sdd/INSTALACION.md`.

1. Analiza el repositorio (solo lectura): manifiestos (`package.json`, `*.csproj`, `Directory.Packages.props`...), estructura de carpetas, scripts de test, lint y build, framework de tests, convenciones visibles y archivos de referencia.
2. Completa `AGENTS.md` sustituyendo **todos** los `<...>` y `<CONFIRMAR: ...>` con datos comprobados (si se copió un perfil de `docs/sdd/perfiles/`, verifica cada afirmación contra el código y corrige lo que no coincida). Comandos exactos y copiables. Máximo unas 45 líneas. Lo que no puedas comprobar, déjalo como `<CONFIRMAR: ...>` y dímelo.
3. Completa `MEMORY.md` («Estado actual») con lo que has encontrado, sin inventar.
4. Revisa `.github/hooks/sdd-policy.json`: ajusta `testGlobs` a los patrones de archivos de test reales del repositorio.
5. Indica qué perfiles de stack de `.github/instructions/` (`angular`, `dotnet`) **no aplican** a este repositorio para que yo los elimine. No los borres tú.
6. No toques `docs/constitution.md`: la constitución se propone con `/sdd-constitution`.

Notas del usuario: el texto que acompaña a este comando.

Al terminar, resume qué completaste, qué queda por confirmar y el siguiente paso (`/sdd-constitution`).
