---
description: "SDD · Etapa 3. Revisa una spec (o la consistencia spec, plan y tareas) como un QA senior. Solo detecta."
argument-hint: "NNN-nombre [consistencia]"
agent: sdd-orchestrator
---

Ejecuta **solo una revisión QA** de `specs/NNN-nombre/` (el identificador está en el texto que acompaña a este comando).

- Si el texto incluye `consistencia` (o ya existen `plan.md` y `tasks.md`), usa `sdd-spec-reviewer` en modo `consistencia`; si no, en modo `spec`.
- Muéstrame los hallazgos numerados con su severidad y la decisión que necesito tomar en cada uno.

No corrijas nada todavía: espera a que yo decida.
