---
description: "SDD · Etapa 1. Explora el código afectado por una idea y genera research.md (sin tocar código)."
argument-hint: "NNN-nombre idea inicial (o solo la idea; se asigna el siguiente número)"
agent: sdd-orchestrator
---

Ejecuta **solo la Etapa 1 · Exploración**.

- Identificador y descripción: el texto que acompaña a este comando. Si no trae un `NNN-nombre`, asigna el siguiente número libre en `specs/` y propón el nombre.
- Delega en `sdd-explorer` (modo `explorar`) con el contrato de delegación completo.
- Muéstrame: rama actual, áreas afectadas, patrones de referencia, riesgos y preguntas abiertas (máximo 10 líneas).
- Si estoy en una rama compartida (`dev`, `main`...), recuérdame crear `feature/NNN-nombre` desde `dev` antes de seguir.

No avances a la especificación.
