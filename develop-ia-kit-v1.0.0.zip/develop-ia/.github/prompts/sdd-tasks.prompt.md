---
description: "SDD · Etapa 5. Divide el plan en tareas TDD, analiza la consistencia y pide el Gate 2."
argument-hint: "NNN-nombre"
agent: sdd-orchestrator
---

Ejecuta **solo la Etapa 5 · Tareas y consistencia** de `specs/NNN-nombre/` (identificador en el texto que acompaña a este comando).

1. Comprueba que existe `plan.md`. Si no, para y avísame.
2. `sdd-task-planner` (modo `planificar`): tareas de 20 a 30 minutos, en orden de dependencia, con RF, tests a escribir y «Hecho cuando». Si salen más de 10, propón dividir la spec.
3. `sdd-spec-reviewer` (modo `consistencia`); corrige los bloqueantes con el subagente dueño del artefacto.
4. **Gate 2**: resúmeme el plan y la secuencia de tareas y espera mi aprobación. Después, propón el commit de planificación.
