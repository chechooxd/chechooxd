---
description: "SDD · Etapa 6. Implementa con TDD (RED, GREEN y REFACTOR) una tarea concreta o todas las pendientes, en orden."
argument-hint: "NNN-nombre [Tnn | todas]"
agent: sdd-orchestrator
---

Ejecuta **la Etapa 6 · Implementación TDD** de `specs/NNN-nombre/` (identificador y tarea en el texto que acompaña a este comando).

1. Comprueba que el plan y las tareas están aprobados (Gate 2). Si no, para y avísame.
2. Si se indica una tarea `Tnn`, implementa **solo esa**. Si se indica `todas` o nada, implementa las pendientes **de una en una y en orden**.
3. Por cada tarea:
   - Tipo `TDD`: `tdd-test-author` (RED, con evidencia válida) → `tdd-implementer` (GREEN + REFACTOR, con la suite completa en verde).
   - Tipo `sin-test`: solo `tdd-implementer`, con la verificación alternativa.
   - Informa en una línea y propón el commit de la tarea.
4. Si un subagente devuelve `BLOQUEADO`, para y explícame el problema. No improvises.

No ejecutes la revisión ni la verificación salvo que te lo pida.
