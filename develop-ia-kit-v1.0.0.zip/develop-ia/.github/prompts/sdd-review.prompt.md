---
description: "SDD · Etapa 7. Revisión de código del diff completo de la rama frente a spec, plan, constitución y convenciones."
argument-hint: "NNN-nombre [rama base, por defecto la de integración: dev]"
agent: sdd-orchestrator
---

Ejecuta **la Etapa 7 · Revisión de código** de `specs/NNN-nombre/` (identificador y, opcionalmente, la rama base en el texto que acompaña a este comando; por defecto, la rama de integración definida en `AGENTS.md`, normalmente `dev`).

1. Delega en `code-reviewer` (modo `revisar`) sobre el diff completo de la rama.
2. Muéstrame el veredicto y los hallazgos.
3. Si el veredicto es `CAMBIOS NECESARIOS`, pregúntame si aplico las correcciones: los hallazgos de tests van a `tdd-test-author` y los de código a `tdd-implementer`, y después se hace una nueva revisión (máximo 2 vueltas).
