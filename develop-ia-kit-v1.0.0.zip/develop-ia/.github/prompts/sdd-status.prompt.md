---
description: "SDD · Estado de una spec (o de todas): etapa actual, artefactos, tareas hechas y siguiente paso exacto. Solo lectura."
argument-hint: "NNN-nombre (vacío = todas las specs)"
agent: sdd-orchestrator
---

Ejecuta el **flujo de estado** (solo lectura, sin invocar subagentes).

- Si el texto que acompaña a este comando indica una spec, lee `specs/NNN-nombre/` (los artefactos que existan) y `MEMORY.md`, y dime en pocas líneas:
  1. En qué etapa del flujo está y el estado de cada artefacto.
  2. Tareas hechas y pendientes (x de y), con su evidencia.
  3. El siguiente paso exacto y el comando `/sdd-*` que debo ejecutar.
- Si no indica ninguna, muéstrame una tabla con todas las specs: identificador, estado de la spec, progreso de las tareas y siguiente paso.

No modifiques ningún archivo.
