---
description: "SDD · Mantenimiento. Cambio de requisitos sobre una spec existente: primero la spec, luego el plan y las tareas, y por último el código."
argument-hint: "NNN-nombre descripción del cambio"
agent: sdd-orchestrator
---

Ejecuta el **flujo de cambio** sobre `specs/NNN-nombre/`. El identificador y la descripción del cambio están en el texto que acompaña a este comando.

1. Comprueba si es realmente un cambio (y no un bug o una spec nueva) con la skill `change-management`. Si no lo es, dímelo y propón el flujo correcto.
2. `sdd-spec-writer` en modo `cambio`: análisis de impacto y spec actualizada (RF nuevos, modificados u obsoletos; nunca renumerar). Muéstrame el diff de la spec y **espera mi aprobación**.
3. `sdd-spec-reviewer` en modo `spec`, solo sobre lo cambiado.
4. `sdd-architect` y `sdd-task-planner` en modo `ajustar`. **Espera mi aprobación.**
5. Continúa con la Etapa 6 solo para las tareas nuevas o afectadas, y después las etapas 7, 8 y 9.
