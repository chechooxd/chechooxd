---
description: "SDD · Flujo completo para una funcionalidad nueva: exploración, spec, clarificación, diseño, tareas, TDD, revisión, verificación y cierre."
argument-hint: "Describe la funcionalidad (qué y para qué)"
agent: sdd-orchestrator
---

Ejecuta el **flujo SDD completo** para la funcionalidad que describe el texto que acompaña a este comando.

1. Lee `AGENTS.md`, `docs/constitution.md` y `MEMORY.md`. Si la constitución no está vigente, empieza por la Etapa 0.
2. Asigna el siguiente identificador libre `NNN-nombre` en `specs/` y crea la lista de tareas con las etapas.
3. Recorre las etapas 1 a 9 delegando cada una en su subagente, con el contrato de delegación completo.
4. Detente en cada gate (spec, plan y tareas, aceptación final) hasta tener mi aprobación explícita.
5. Anuncia cada etapa en una sola línea y, al terminar, dame el resumen final.
