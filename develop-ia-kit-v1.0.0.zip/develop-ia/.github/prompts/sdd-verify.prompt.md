---
description: "SDD · Etapa 8. Verifica la spec RF por RF con evidencia real (tests, build, lint y Chrome DevTools) y emite un veredicto."
argument-hint: "NNN-nombre [RF-nn,...]"
agent: sdd-orchestrator
---

Ejecuta **la Etapa 8 · Verificación** de `specs/NNN-nombre/` (identificador en el texto que acompaña a este comando).

1. Delega en `sdd-verifier`: modo `verificar`, o `verificar-parcial` si el texto indica RF concretos.
2. Muéstrame la matriz RF → evidencia → resultado, la ejecución de la suite, el build y el lint, y los pendientes manuales.
3. Si el veredicto es `NO CUMPLE`, **no arregles nada todavía**: muéstrame los incumplimientos y pregúntame si inicio las correcciones.
