---
description: "SDD · Etapas 2 y 3. Entrevista, redacta la spec en EARS y la somete a clarificación QA hasta el Gate 1."
argument-hint: "NNN-nombre idea inicial"
agent: sdd-orchestrator
---

Ejecuta las **Etapas 2 · Especificación y 3 · Clarificación** para la spec que indica el texto que acompaña a este comando (`NNN-nombre` y la idea inicial).

1. Si no existe `specs/NNN-nombre/research.md`, ejecuta antes la Etapa 1.
2. `sdd-spec-writer` en modo `entrevista`: hazme sus preguntas **de una en una**, con la opción recomendada.
3. Con mis respuestas, `sdd-spec-writer` en modo `redactar` (estado `Borrador`).
4. `sdd-spec-reviewer` en modo `spec`; preséntame los hallazgos bloqueantes y mayores y aplica mis decisiones con `sdd-spec-writer` en modo `corregir` (máximo 3 vueltas).
5. **Gate 1**: resúmeme la spec y espera mi aprobación explícita para marcarla `Aprobada`.

Nada de código, plan ni tareas.
