---
description: "SDD · Etapa 0. Propone (o enmienda) la constitución del proyecto: principios innegociables, cortos y verificables."
argument-hint: "Contexto adicional o enmienda que quieres proponer (opcional)"
agent: sdd-orchestrator
---

Ejecuta **solo la Etapa 0 · Constitución**.

- Si `docs/constitution.md` está en estado `Plantilla` o no existe: pide a `sdd-architect` (modo `constitucion-proponer`) entre 6 y 9 principios innegociables, cortos y verificables, que cubran el stack y las dependencias, la relación spec ↔ código, los límites de arquitectura, la política de tests (TDD), los datos y la seguridad, los contratos entre repositorios y el idioma.
- Si ya está `Vigente`: trata el texto que acompaña al comando como una **enmienda** y aplica las reglas de versionado de la skill `project-constitution`.
- Contexto adicional del usuario: el texto que acompaña a este comando.

Muéstrame la propuesta y **espera mi aprobación** antes de ratificarla. No avances a ninguna otra etapa.
