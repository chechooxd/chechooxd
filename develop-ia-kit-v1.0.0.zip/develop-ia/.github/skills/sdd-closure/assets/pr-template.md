<!-- Título del PR (Conventional Commits; con squash merge es el commit que llega a la rama de integración):
<tipo>(<scope>): <resumen de la spec completa en imperativo> -->

## <tipo>(<scope>): <resumen en lenguaje de usuario> · NNN-nombre

### Qué y por qué
<2 a 4 líneas: problema que resuelve y valor para el usuario. Enlace a la spec.>

- Spec: `specs/NNN-nombre/spec.md` (v<versión>)
- Plan: `specs/NNN-nombre/plan.md`
- Verificación: `specs/NNN-nombre/verification.md` → **<VEREDICTO>**

### Cambios principales
- <área>: <qué cambia>

### Requisitos cubiertos
| RF | Descripción breve | Evidencia |
|---|---|---|
| RF-01 | <...> | ✅ `RF-01: ...` |

### Decisiones técnicas
- D-01 <decisión> (descartada: <alternativa>)

### Cómo probarlo
1. <paso>
2. <resultado esperado>

### Pendientes manuales
- [ ] <comprobación que debe hacer el revisor humano> | ninguno

### Impacto en consumidores
- <cambio de contrato, a quién afecta y cómo migrar> | ninguno

### Riesgos y notas para el revisor
- <riesgo, migración, compatibilidad> | ninguno

### Lista de comprobación
- [ ] Suite, build y lint en verde
- [ ] Sin dependencias nuevas no aprobadas
- [ ] Revisión de código: APROBADO
- [ ] MEMORY.md y CHANGELOG actualizados

Refs: NNN-nombre
