# Revisión .NET 10 (API): comprobaciones específicas

Complementa la lista general de la skill. Severidad entre corchetes.

## Fronteras de capas (lo más importante)
- [BLOQUEANTE] Salto de capa: un Controller que llama directamente a un Repository, o un Repository con lógica de caso de uso.
- [MAYOR] Handler con acceso a datos que corresponde al Repository, o con formateo HTTP que corresponde al Controller.
- [MAYOR] Interfaces nuevas sin registrar en `Program.cs` (`AddScoped`).
- [MAYOR] Nomenclatura por entidad inconsistente (`XController`, `IXHandler`/`XHandler`, `IXRepository`/`XRepository`).

## Contrato y DTOs
- [BLOQUEANTE] Una consulta que devuelve una entidad de dominio en lugar de un DTO de `Models/DTO`.
- [BLOQUEANTE] Respuesta que no va envuelta en `ResponseData<T>`, o endpoint paginado sin `ResponseMeta`.
- [BLOQUEANTE] Cambio en la forma de un endpoint existente (campos de `Data`, `ResponseMeta`, `ResponseError`, ruta, verbo o parámetros obligatorios) **no marcado** en el plan como cambio de contrato aprobado.

## Errores
- [BLOQUEANTE] Handler o Repository que captura excepciones para formatear errores a mano: deben propagarse al middleware que produce `ResponseError`.

## EF Core
- [BLOQUEANTE] Lectura sin `.AsNoTracking()` (o `.AsNoTrackingWithIdentityResolution()`).
- [BLOQUEANTE] Uso de `.Include()` o `.ThenInclude()`: debe ser una proyección `.Select()` al DTO.
- [MAYOR] Métodos sin `CancellationToken` en la firma o sin propagarlo; `.Result`, `.Wait()` o `async void`.
- [MAYOR] Consultas que traen columnas innecesarias o N+1.

## Diseño y estilo
- [MAYOR] Handler que cubre más de un caso de uso o más de una entidad; dependencias concretas instanciadas en lugar de interfaces; DI sin constructores primarios.
- [MAYOR] Sobreingeniería: capas o patrones que no resuelven un problema real del cambio.
- [Opcional] Nombres de método sin intención (`GetAsync`), anidamiento profundo, números o cadenas mágicas.
- [MAYOR] Idioma de nombres, comentarios o logs distinto del que fija la constitución.

## Tests
- [BLOQUEANTE] Tests de Handler que usan la base de datos real o un repositorio concreto en lugar de un doble del `IRepository`.
- [MAYOR] Sin tests de los casos de error de la spec (qué `ResponseError` y cuándo).
- [MAYOR] Tests que pasan trivialmente (el doble devuelve exactamente lo que se afirma, sin lógica de por medio).
