# Lista de comprobación de seguridad

Basada en OWASP Top 10 y ASVS. Aplica los apartados que correspondan al diff.

## Control de acceso
- [ ] Cada endpoint u operación sensible comprueba la autorización en el servidor (no solo ocultando botones en la interfaz).
- [ ] Sin referencias directas inseguras: el usuario no puede acceder a un recurso ajeno cambiando un ID.
- [ ] Las guardas de ruta del frontend no se consideran seguridad: el backend vuelve a comprobar.

## Criptografía y secretos
- [ ] Sin secretos, claves, tokens ni cadenas de conexión en el código, los tests o la configuración versionada.
- [ ] Los secretos se leen de variables de entorno o de un gestor de secretos.
- [ ] No se implementa criptografía propia.

## Inyección
- [ ] SQL parametrizado u ORM; nunca concatenar entradas en consultas.
- [ ] Sin `eval`, `new Function` ni ejecución de comandos con datos externos.
- [ ] Angular: sin `innerHTML` ni `bypassSecurityTrust*` con contenido externo sin sanear.
- [ ] Cabeceras y redirecciones validadas contra una lista permitida.

## Validación de entradas
- [ ] Validación en el servidor (tipo, longitud, rango, formato) aunque exista en el cliente.
- [ ] Límites de tamaño en cargas de archivos y cuerpos de petición.
- [ ] Errores devueltos sin detalles internos (trazas, SQL, rutas).

## Datos sensibles
- [ ] Sin datos personales, tokens ni contraseñas en logs, mensajes de error o analítica.
- [ ] Datos sensibles fuera de `localStorage` (tokens incluidos, salvo decisión explícita documentada).

## Dependencias y configuración
- [ ] Dependencias nuevas aprobadas y sin vulnerabilidades conocidas (`npm audit` o `dotnet list package --vulnerable`).
- [ ] CORS restrictivo; cabeceras de seguridad no relajadas.
- [ ] Sin configuraciones de depuración activas en producción.

## Autenticación y sesión
- [ ] Tokens con caducidad; renovación segura; cierre de sesión que invalida.
- [ ] Protección CSRF donde haya cookies de sesión.
