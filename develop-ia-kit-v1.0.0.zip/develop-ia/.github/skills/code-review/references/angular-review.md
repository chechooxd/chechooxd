# Revisión Angular 20: comprobaciones específicas

Complementa la lista general de la skill. Severidad entre corchetes.

## Contrato con el backend
- [BLOQUEANTE] Código que asume un envoltorio de respuesta, campos, códigos de error o paginación distintos del contrato documentado (`specs/NNN/contracts/` o `AGENTS.md`), o que los infiere sin documentación.
- [BLOQUEANTE] Decisiones implementadas que dependen de una pregunta `EXT` todavía abierta.

## Estado
- [MAYOR] NgRx Signal Store introducido a mitad de una feature que sigue el patrón legacy (servicio con `signal<T>()`), o estado compartido nuevo duplicado en lugar de extender el store existente.
- [BLOQUEANTE] Uso de `@ngrx/signals` (u otra librería) que no está en `package.json` o no fue aprobada.
- [MAYOR] `effect()` usado para derivar estado (debe ser `computed()`); suscripciones sin `takeUntilDestroyed()`; `rxMethod` mezclado con suscripciones imperativas.

## Componentes y rendimiento
- [MAYOR] Componente que mezcla orquestación de estado con presentación (smart y presentational mezclados).
- [MAYOR] `@for` sin `track`; lógica pesada o creación de objetos y arrays dentro de los bindings de la plantilla.
- [MAYOR] Dependencia de Zone.js en un proyecto zoneless (`NgZone.run`, confiar en la detección tras `setTimeout`).
- [MAYOR] Componente sin `OnPush`; decoradores `@Input`/`@Output` o `*ngIf`/`*ngFor` en código nuevo.
- [MAYOR] Componente o servicio nuevo que duplica uno compartido existente.
- [MAYOR] Sobreingeniería: patrones o abstracciones sin un problema real que resolver.

## Seguridad y accesibilidad
- [BLOQUEANTE] `innerHTML` o `bypassSecurityTrust*` con contenido externo sin sanear.
- [MAYOR] Controles sin etiqueta accesible o sin manejo de teclado.

## Tests
- [MAYOR] Tests de componentes que dependen de `fakeAsync` o de Zone.js en un proyecto zoneless.
- [MAYOR] Tests HTTP sin `HttpTestingController` o sin `httpMock.verify()`, o con fixtures que no coinciden con el contrato.
- [MAYOR] Selectores frágiles por clase CSS cuando hay rol o texto visible disponibles.
