---
name: spec-quality-review
description: "Revisión de calidad de specs como un QA senior y análisis de consistencia entre spec, plan, tareas y constitución: listas de comprobación, severidades (BLOQUEANTE, MAYOR, MENOR) y formato del informe. Solo detecta, no corrige. Úsala en la clarificación de una spec o antes de aprobar un plan y sus tareas."
---

# Revisión de calidad de specs

Tu objetivo es encontrar **lo que hará fallar la implementación o la verificación**, no pulir la redacción. Cada hallazgo se plantea como una decisión que el usuario puede tomar.

## Severidades

| Severidad | Criterio | Efecto |
|---|---|---|
| `BLOQUEANTE` | Impide implementar o verificar: contradicción, RF no verificable, conflicto con la constitución, RF sin cobertura en plan o tareas. | Hay que resolverlo antes del gate. |
| `MAYOR` | Probable defecto o retrabajo: caso límite relevante sin cubrir, término ambiguo con impacto, error sin su `SI ... ENTONCES`. | Hay que resolverlo antes del gate. |
| `MENOR` | Mejora la claridad sin cambiar el comportamiento. | Se informa; no bloquea. |

No reportes preferencias de estilo.

## Modo `spec`: lista de comprobación

**Ambigüedad**
- [ ] ¿Algún RF usa adjetivos sin medida («rápido», «fácil», «adecuado», «reciente»)?
- [ ] ¿Algún término admite dos lecturas y no está en «Definiciones»?
- [ ] ¿Algún RF tiene «etc.», «y/o», «entre otros» o «cuando sea posible»?

**Contradicciones**
- [ ] ¿Dos RF dan respuestas distintas al mismo evento o estado?
- [ ] ¿Algún RF contradice «Fuera de alcance», un caso límite o una spec aprobada?

**Completitud**
- [ ] ¿Cada RF de evento tiene sus RF de error (`SI ... ENTONCES`)? Entradas vacías, inválidas, duplicadas, fuera de rango, sin permisos, fallos externos.
- [ ] ¿Están cubiertos los casos límite típicos (vacíos, límites, concurrencia, fechas, datos heredados)?
- [ ] ¿Cada HU tiene al menos un RF? ¿Cada RF pertenece a una HU?
- [ ] ¿Hay criterios de finalización comprobables?

**Testabilidad**
- [ ] ¿Cada RF tiene un resultado observable que un test o una comprobación pueda afirmar?
- [ ] ¿Los RNF tienen número, unidad y condición de medida?

**Forma**
- [ ] ¿La spec contiene el CÓMO (tecnologías, archivos, endpoints)? Eso es un hallazgo `MAYOR`.
- [ ] ¿Quedan `[NECESITA ACLARACIÓN]`? Cada uno es un hallazgo `BLOQUEANTE`.

**Constitución**
- [ ] ¿Algún RF obliga a incumplir un principio? (`BLOQUEANTE`)

## Modo `consistencia`: análisis entre artefactos

- [ ] **Cobertura**: cada RF aparece en al menos una sección del plan y en al menos una tarea, con un test previsto.
- [ ] **Huérfanos**: ninguna tarea ni sección del plan sin RF (alcance no pedido).
- [ ] **Casos límite**: cada `CL-nn` tiene un test previsto en alguna tarea.
- [ ] **Constitución**: la tabla de cumplimiento del plan es correcta y completa.
- [ ] **Terminología**: los mismos conceptos se llaman igual en la spec, el plan, las tareas y los contratos.
- [ ] **Orden**: ninguna tarea depende de otra posterior.
- [ ] **Tipo de tarea**: las tareas `sin-test` están justificadas y no ocultan lógica.
- [ ] **Contratos**: los tipos y campos de `contracts/` coinciden con lo que usan el plan y las tareas.
- [ ] **Preguntas EXT**: no queda ninguna bloqueante abierta.

## Formato del informe

```markdown
ESTADO: COMPLETADO
VEREDICTO: SIN BLOQUEANTES | REQUIERE CORRECCIONES
Modo: spec | consistencia · Hallazgos: B=<n> M=<n> m=<n>

## Hallazgos
1. [MAYOR] [Completitud] RF-02
   - Problema: «EL SISTEMA guarda el borrador» no define qué ocurre si el asunto supera 200 caracteres.
   - Por qué importa: el implementador decidirá un comportamiento no acordado y no habrá test para él.
   - Decisión necesaria: ¿se trunca, se rechaza con mensaje o se permite cualquier longitud?
```

`VEREDICTO: REQUIERE CORRECCIONES` si hay al menos un `BLOQUEANTE` o `MAYOR`. En modo `consistencia`, añade la tabla de cobertura RF → plan → tareas → test previsto.
