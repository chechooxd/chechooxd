---
name: sdd-workflow
description: "Flujo Spec-Driven Development + TDD del proyecto: etapas, gates de aprobación humana, artefactos por spec, estados, identificadores, trazabilidad, límites de bucles y momentos de commit. Úsala siempre que coordines etapas SDD o trabajes con specs/ o docs/constitution.md."
---

# Flujo SDD + TDD

Modelo **spec-anchored**: la spec se mantiene viva y guía la evolución del código. Todo cambio de comportamiento entra primero por la spec.

```text
Constitución (una vez)
      │
      ▼
1 Exploración ─► 2 Especificación ─► 3 Clarificación ─► 🔒 Gate 1 (spec)
                                                            │
      ┌─────────────────────────────────────────────────────┘
      ▼
4 Diseño técnico ─► 5 Tareas + consistencia ─► 🔒 Gate 2 (plan + tareas)
                                                            │
      ┌─────────────────────────────────────────────────────┘
      ▼
6 Implementación TDD, por tarea: RED (test-author) ─► GREEN + REFACTOR (implementer)
      │
      ▼
7 Revisión de código ─► 8 Verificación ─► 9 Cierre ─► 🔒 Gate 3 (aceptación)
      ▲                         │
      └──── correcciones ◄──────┘   (máx. 2 vueltas cada bucle)

Mantenimiento: cambio de requisitos ─► vuelve a 2 (primero la spec)
```

## Reglas del flujo

1. **La spec manda.** Si algo no está en la spec activa, no se implementa. Si falta una decisión, se para y se pregunta.
2. **Gates humanos.** Ninguna etapa posterior a un gate empieza sin la aprobación explícita del usuario. Una aprobación implícita («vale, sigue con lo que veas») solo cuenta si el usuario la da sabiendo qué aprueba.
3. **Los cambios entran por arriba.** Spec → plan → tareas → tests → código. Nunca al revés.
4. **TDD obligatorio** para toda tarea con comportamiento: el test existe y falla antes que el código.
5. **Separación de funciones.** Quien escribe los tests no escribe el código; quien revisa o verifica no modifica nada.
6. **Evidencia, no afirmaciones.** Toda etapa que ejecuta algo devuelve el comando, el código de salida y un resumen de la salida.
7. **Una tarea cada vez.** El implementador nunca encadena tareas.

## Estructura de una spec

```text
specs/
└── NNN-nombre-en-kebab/
    ├── research.md       # 1 · Exploración (sdd-explorer)
    ├── spec.md           # 2-3 · QUÉ y POR QUÉ, en EARS (sdd-spec-writer)
    ├── plan.md           # 4 · CÓMO (sdd-architect)
    ├── contracts/        # 4 · Contratos de API o integración (opcional)
    ├── tasks.md          # 5 · Tareas y evidencia TDD (sdd-task-planner, tdd-*)
    ├── review.md         # 9 · Informe de revisión (sdd-archivist)
    └── verification.md   # 9 · Matriz RF → evidencia (sdd-archivist)
```

- `NNN`: siguiente número libre con tres dígitos (`001`, `002`...). Nunca se reutiliza.
- El nombre en kebab-case describe la capacidad (`exportar-csv`), no la tarea técnica.
- Una petición grande del cliente (una HU de negocio) suele generar **varias specs independientes**. Si salen más de 10 tareas, divide.

## Identificadores

| Prefijo | Significado | Dónde |
|---|---|---|
| `HU-nn` | Historia de usuario | spec |
| `RF-nn` | Requisito funcional (EARS) | spec |
| `RNF-nn` | Requisito no funcional | spec |
| `CL-nn` | Caso límite | spec |
| `D-nn` | Decisión técnica | plan |
| `EXT-nn` | Pregunta a otro equipo o repositorio | plan |
| `Tnn` | Tarea | tasks |

Los identificadores son **estables**: no se renumeran ni se reutilizan. Un requisito eliminado se marca como obsoleto (ver la skill change-management).

**Trazabilidad**: `HU → RF → (plan §) → Tnn → test "RF-nn: ..." → resultado en verification.md`.

## Estados

| Artefacto | Estados |
|---|---|
| `docs/constitution.md` | `Plantilla` → `Propuesta` → `Vigente` |
| `spec.md` | `Borrador` → `Aprobada` → `Implementada` (→ `Obsoleta` o `Reemplazada por NNN`) |
| `plan.md` | `Borrador` → `Aprobado` → `Implementado` |
| Tarea en `tasks.md` | `[ ]` pendiente → `[x]` con evidencia RED y GREEN |

Un cambio de requisitos devuelve la spec a `Borrador` con una versión nueva.

## Límites de bucles

| Bucle | Máximo | Al agotarse |
|---|---|---|
| Clarificación de la spec | 3 vueltas | Parar y listar las decisiones pendientes |
| Intentos de GREEN por tarea | 3 | `BLOQUEADO` con diagnóstico |
| Revisión → corrección | 2 vueltas | Parar y explicar al usuario |
| Verificación → corrección | 2 vueltas | Parar y explicar al usuario |

## Commits

Formato: skill [conventional-commits](../conventional-commits/SKILL.md). Todos llevan el pie `Refs: NNN-nombre`.

| Momento | Tipo | Contenido |
|---|---|---|
| Tras el Gate 2 | `docs(sdd): ...` | `research.md`, `spec.md`, `plan.md`, `contracts/`, `tasks.md` |
| Tras cada tarea en verde | `feat`, `fix`, `refactor`, `test`... | Tests + código de la tarea + evidencia en `tasks.md` |
| Tras las correcciones de revisión o verificación | `fix: ...` o `refactor: ...` | Correcciones |
| Tras el Gate 3 | `docs(sdd): ...` | `review.md`, `verification.md`, estados, `MEMORY.md`, `CHANGELOG.md` |

Los artefactos de planificación y el código van en commits **separados**: nunca se mezclan en el mismo commit.

## Ramas y pull request

- **Una spec = una rama = un PR.** Las specs se completan y cierran de una en una.
- La rama sale de la rama de integración definida en `AGENTS.md` (por defecto `dev`) y se crea **antes** del primer artefacto, porque los artefactos de planificación también se versionan: `feature/NNN-nombre` (o `fix/NNN-descripcion` para bugs).
  ```bash
  git checkout dev && git pull
  git checkout -b feature/NNN-nombre
  ```
- Todo el ciclo vive en esa rama: planificación, tareas, correcciones y cierre. Solo entonces se abre el PR hacia la rama de integración. Así la rama de integración nunca recibe código sin su spec ni specs sin su código.
- **Título del PR** en formato Conventional Commits, resumiendo la spec completa (`feat(notificaciones): permite programar el envío`). Con *squash merge* ese título es el commit que llega a la rama de integración: debe ser correcto por sí solo.
- Flujo de integración típico: `feature/NNN-nombre` → PR a `dev` → validación → QA → `main`.
- Nunca se hace push desde el flujo: lo hace el desarrollador.

## Cuándo NO usar el flujo completo

- Cambios sin comportamiento nuevo: erratas, renombrados, formato o actualización de comentarios.
- Prototipos desechables acordados como tales.

En esos casos, usa el agente por defecto respetando `AGENTS.md`. Ante la duda, usa el flujo.

## Definición de terminado (DoD) de una spec

- [ ] Todos los RF con estado `CUMPLE` (o `PENDIENTE MANUAL` aceptado por el usuario).
- [ ] Todas las tareas `[x]` con evidencia RED y GREEN.
- [ ] Revisión `APROBADO` y verificación `CUMPLE`.
- [ ] Suite completa, build y lint en verde.
- [ ] `spec.md` en estado `Implementada`; `MEMORY.md` actualizado.
- [ ] Aceptación final del usuario (Gate 3).
