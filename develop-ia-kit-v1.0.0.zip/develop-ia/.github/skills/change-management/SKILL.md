---
name: change-management
description: "Gestión de cambios de requisitos sobre specs existentes en un modelo spec-anchored: primero la spec, luego el plan y las tareas, y por último el código. Cubre el análisis de impacto, el versionado de la spec, el marcado de RF nuevos, modificados y obsoletos, y la regla de no renumerar. Úsala cuando cambie un requisito de una spec aprobada o implementada."
---

# Gestión de cambios de requisitos

En SDD *spec-anchored*, la spec vive tanto como el código. **Un cambio de comportamiento entra siempre por la spec**, nunca directamente por el código.

## ¿Cambio, spec nueva o bug?

| Situación | Tratamiento |
|---|---|
| El sistema no hace lo que dice un RF | **Bug** → flujo bugfix. La spec no cambia. |
| Se modifica o amplía el comportamiento de una capacidad existente | **Cambio** sobre esa spec. |
| Capacidad nueva e independiente | **Spec nueva** (`NNN` siguiente). |
| Un cambio que afecta a más de 5 RF o reescribe el objetivo | Spec nueva que **reemplaza** a la anterior (`Reemplazada por NNN`). |

## Proceso

1. **Análisis de impacto** (antes de tocar nada):

   | Artefacto | Afectado | Detalle |
   |---|---|---|
   | RF | RF-03 (modifica), RF-08 (nuevo) | <...> |
   | Plan | §4.2, §6 | <...> |
   | Tareas | T04 (rehacer), T09 (nueva) | <...> |
   | Tests existentes | `RF-03: ...` debe cambiar | <...> |
   | Contratos | sí/no | <...> |

2. **Spec**: aplica el cambio con estas marcas:
   - RF nuevo: el siguiente número libre, con `(nuevo en vX.Y)`.
   - RF modificado: mantiene su número, con `(modificado en vX.Y)`. Si el cambio altera su significado, mejor márcalo obsoleto y crea uno nuevo.
   - RF eliminado: **nunca se borra ni se renumera**: `~~RF-05: ...~~ (obsoleto en vX.Y: <motivo>)`.
   - Actualiza los casos límite, «Fuera de alcance» y el «Historial de cambios».
   - Estado `Borrador` y versión MENOR siguiente (`1.0` → `1.1`); MAYOR (`2.0`) si cambia el objetivo.
3. **Aprobación** de la spec cambiada (se muestra el diff).
4. **Plan y tareas**: solo las secciones y tareas afectadas, con tareas nuevas numeradas a continuación. Las tareas que rehacen comportamiento existente empiezan por **modificar el test** del RF (lo hace `tdd-test-author`: es el RED del cambio).
5. **Implementación, revisión y verificación** como en el flujo normal, limitadas a lo afectado más la suite completa.

## Reglas

- Ningún cambio de código sin la spec actualizada y aprobada.
- Los tests de un RF modificado se cambian **antes** que el código, y deben fallar (RED) contra el comportamiento antiguo.
- Un RF obsoleto conserva su línea en la spec; sus tests se eliminan en la tarea correspondiente, de forma explícita y revisada.
