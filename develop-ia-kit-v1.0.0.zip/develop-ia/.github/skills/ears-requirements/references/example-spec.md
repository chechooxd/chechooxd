# Spec 007 — Programar el envío de una notificación

> **Estado:** Aprobada · **Versión:** 1.0 · **Última actualización:** 2026-10-20 · **Rama:** feat/007-programar-envio

## Contexto y objetivo
Hoy las notificaciones se envían en el momento de publicarlas. El equipo de comunicación necesita prepararlas con antelación y que salgan a una hora concreta (por ejemplo, el lunes a las 09:00), sin estar conectado. Éxito: el 80 % de las campañas semanales se programan en lugar de enviarse a mano.

## Usuarios y actores
- Gestor de comunicación: crea y programa notificaciones.
- Sistema de envío: ejecuta los envíos programados.

## Historias de usuario
- **HU-01**: Como gestor, quiero programar una notificación para una fecha y hora futuras, para no depender de estar conectado.
- **HU-02**: Como gestor, quiero cancelar un envío programado, para corregir errores antes de que salga.

## Definiciones
- **Hora local**: la de la zona horaria configurada en el perfil del gestor (no la del servidor).
- **Envío programado**: notificación en estado «Programada» con fecha y hora de envío futuras.

## Requisitos funcionales

### HU-01 — Programar
- **RF-01**: CUANDO el gestor elige «Programar» e indica una fecha y hora futuras, EL SISTEMA guarda la notificación en estado «Programada» y muestra «Se enviará el <fecha> a las <hora> (hora local)».
- **RF-02**: SI la fecha y hora indicadas son anteriores o iguales al momento actual, ENTONCES EL SISTEMA no programa y muestra «La fecha de envío debe ser futura».
- **RF-03**: SI la fecha indicada supera en más de 90 días al momento actual, ENTONCES EL SISTEMA no programa y muestra «Solo se puede programar con hasta 90 días de antelación».
- **RF-04**: CUANDO llega la fecha y hora programadas, EL SISTEMA envía la notificación y cambia su estado a «Enviada».
- **RF-05**: MIENTRAS una notificación está «Programada», EL SISTEMA muestra en el listado su fecha y hora de envío en hora local.

### HU-02 — Cancelar
- **RF-06**: CUANDO el gestor cancela una notificación «Programada», EL SISTEMA cambia su estado a «Borrador» y elimina la fecha de envío.
- **RF-07**: SI el gestor intenta cancelar una notificación que ya está «Enviada», ENTONCES EL SISTEMA no la modifica y muestra «Esta notificación ya se envió».

## Requisitos no funcionales
- **RNF-01**: EL SISTEMA envía cada notificación programada con un retraso máximo de 60 segundos respecto a la hora programada.
- **RNF-02**: Los textos de la interfaz están en español.

## Casos límite
| ID | Situación | Comportamiento esperado | RF |
|---|---|---|---|
| CL-01 | Hora programada dentro del cambio de hora (02:30 del último domingo de marzo, que no existe) | Rechazo con «Esa hora no existe en tu zona horaria por el cambio de hora» | RF-02 |
| CL-02 | Programada exactamente a 90 días | Se acepta | RF-03 |
| CL-03 | Dos gestores cancelan la misma notificación a la vez | Solo una cancelación tiene efecto; la otra ve el estado actualizado | RF-06 |
| CL-04 | El sistema de envío estaba caído a la hora programada | Se envía en cuanto vuelve, y la notificación indica el retraso | RF-04 |

## Fuera de alcance
- Envíos recurrentes (cada semana).
- Programar en la zona horaria del destinatario.

## Supuestos y dependencias
- El perfil del gestor tiene una zona horaria configurada (dato existente).

## Criterios de finalización
- [ ] RF-01 a RF-07 con tests en verde.
- [ ] Demo: programar para dentro de 2 minutos y ver el cambio a «Enviada».

## Clarificaciones
### Sesión 2026-10-19
- P: ¿Máximo de antelación? → R: 90 días (afecta a RF-03).
- P: ¿Cancelar devuelve a «Borrador» o elimina? → R: vuelve a «Borrador» (afecta a RF-06).

## Dudas abiertas
- (ninguna)

## Historial de cambios
| Versión | Fecha | Cambio | RF afectados |
|---|---|---|---|
| 0.1 | 2026-10-18 | Borrador inicial | — |
| 1.0 | 2026-10-20 | Aprobada tras la clarificación | RF-03, RF-06 |
