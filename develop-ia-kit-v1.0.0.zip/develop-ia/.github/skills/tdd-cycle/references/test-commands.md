# Comandos de test por stack

> Los comandos oficiales del proyecto están en `AGENTS.md` y mandan sobre esta tabla. Esto es una referencia para los casos habituales.

## Angular (Karma + Jasmine)

| Objetivo | Comando |
|---|---|
| Suite completa, una vez | `npm run test -- --watch=false` |
| Navegador sin interfaz (CI) | `npm run test -- --watch=false --browsers=ChromeHeadless` |
| Solo un archivo (RED) | `npm run test -- --watch=false --include='src/app/ruta/archivo.spec.ts'` |
| Con cobertura | `npm run test -- --watch=false --code-coverage` |
| Lint / build | `npm run lint` · `npm run build` |

Notas: nunca ejecutes en modo watch desde un agente (el proceso no termina). Los nombres de los tests están en `it('RF-nn: ...')`.

## Angular (Vitest, si el proyecto lo usa)

| Objetivo | Comando |
|---|---|
| Suite completa | `npx vitest run` |
| Solo un archivo | `npx vitest run src/app/ruta/archivo.spec.ts` |
| Por nombre | `npx vitest run -t "RF-03"` |

## .NET (xUnit)

| Objetivo | Comando |
|---|---|
| Suite completa | `dotnet test` |
| Sin recompilar | `dotnet test --no-build` |
| Por nombre | `dotnet test --filter "DisplayName~RF-03"` |
| Por clase | `dotnet test --filter "FullyQualifiedName~Namespace.ClaseTests"` |
| Con cobertura | `dotnet test --collect:"XPlat Code Coverage"` |
| Build / formato (solo comprobar) | `dotnet build -warnaserror` · `dotnet format --verify-no-changes` |

Notas: nombra los tests con `[Fact(DisplayName = "RF-03: ...")]` o `[Theory(DisplayName = "...")]` para filtrar por RF.

## Node.js (runner nativo)

| Objetivo | Comando |
|---|---|
| Suite completa | `node --test` |
| Por nombre | `node --test --test-name-pattern="RF-03"` |

## Interpretación del código de salida

- `0`: todos los tests ejecutados pasan.
- Distinto de `0`: hay fallos **o** un error de ejecución. Lee la salida para distinguirlo: un error de compilación o de configuración no es un RED válido salvo que el símbolo que falta sea la API nueva de la tarea.
