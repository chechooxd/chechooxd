# Exploración NNN — <Nombre>

> **Fecha:** AAAA-MM-DD · **Rama:** <rama> (base: <rama base>) · **Autor:** sdd-explorer

## Petición
<Petición original del usuario, literal>

## Áreas afectadas
| Área | Archivos | Impacto |
|---|---|---|
| <módulo> | `ruta/archivo.ext:línea` | <qué podría cambiar> |

## Flujo actual
<Cómo funciona hoy, de la entrada a los datos, en 3 a 8 pasos con rutas>

## Patrones de referencia (a imitar)
- Componente: `ruta` — <por qué es el modelo>
- Servicio, store o repositorio: `ruta`
- Test: `ruta`

## Dependencias instaladas relevantes
| Paquete | Versión | Manifiesto |
|---|---|---|

## Tests existentes
- Framework: <...> · Ubicación: <...> · Comando: `<...>`
- Cobertura del área: <alta | media | baja | nula> — <evidencia>

## Specs relacionadas
- `specs/NNN-...` (<estado>) — <relación o posible conflicto>

## Riesgos
- <riesgo> — <evidencia>

## Preguntas abiertas
1. <pregunta> — Opción recomendada: <...>

## (Solo bug) Reproducción y causa probable
- Pasos: <...>
- Esperado / obtenido: <...>
- Hipótesis: <...> (`ruta:línea`)
- RF afectado: <RF-nn de specs/NNN> | ninguno
