---
name: codebase-exploration
description: "Método para explorar un código existente antes de especificar o diseñar: mapa del área afectada, patrones y archivos de referencia, dependencias realmente instaladas, tests y comandos, specs relacionadas y riesgos. Incluye la plantilla de research.md. Úsala en la etapa de exploración o al investigar la causa de un bug."
---

# Exploración del código

Objetivo: que la spec y el plan se apoyen en **hechos comprobados**. Cada afirmación lleva su `ruta:línea`. Lo que no puedas comprobar se marca como hipótesis o pregunta abierta.

## Método (de fuera hacia dentro)

1. **Contexto del proyecto**: `AGENTS.md`, `docs/constitution.md`, `MEMORY.md`, README.
2. **Contexto git** (solo lectura):
   ```bash
   git status --short
   git branch --show-current
   git log --oneline -15 -- <ruta del área>
   ```
3. **Punto de entrada**: busca el término de negocio de la petición (por ejemplo, «notificación» o «plantilla») en rutas, componentes, controladores y modelos. Sigue el flujo desde la interfaz o el endpoint hasta los datos.
4. **Usos y dependencias**: usa la búsqueda de referencias para saber quién llama a qué. Anota el impacto de cambiar cada pieza.
5. **Patrones de referencia**: para cada tipo de artefacto que el plan probablemente necesite (componente, servicio, store, endpoint, repositorio, test), elige **un archivo existente bien hecho** como modelo.
6. **Dependencias reales**: lee el manifiesto (`package.json`, `*.csproj`, `Directory.Packages.props`, `requirements.txt`...). Lo que no está ahí no existe, aunque «sea lo habitual».
7. **Tests**: framework, ubicación, convención de nombres, utilidades compartidas, cobertura aproximada del área y comando exacto.
8. **Specs relacionadas**: busca en `specs/` RF que toquen la misma área o el mismo concepto. Anota posibles conflictos.
9. **Riesgos**: código frágil, sin tests, con deuda conocida (ver `MEMORY.md`), con concurrencia, fechas, zonas horarias, dinero o datos personales.

## Modo bug

Añade:

- **Reproducción**: pasos mínimos, datos de entrada, resultado esperado frente al obtenido.
- **Hipótesis de causa**: ordenadas por probabilidad, cada una con su evidencia (`ruta:línea`).
- **RF afectado**: el requisito de la spec que se incumple. Si no hay ninguno, no es un bug sino un requisito no especificado.

## Reglas

- Lee antes de concluir: abre los archivos y no te quedes con el nombre.
- No propongas la solución: describe el terreno. El diseño es del arquitecto.
- Sé breve: `research.md` no debería pasar de unas 80 líneas.

## Plantilla

Usa [research-template.md](./assets/research-template.md).
