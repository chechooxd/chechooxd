---
name: conventional-commits
description: "Redacta mensajes de commit con Conventional Commits 1.0.0 adaptados a las convenciones que ya use el repositorio: detección de commitlint y del historial, atomicidad, elección del tipo, scope, descripción, cuerpo, pies y cambios incompatibles. Úsala siempre que propongas, dividas o crees un commit."
---

# Conventional Commits

Redactas mensajes de commit siguiendo Conventional Commits 1.0.0, **adaptados a lo que el repositorio ya definió**. No impones un estilo por encima del del proyecto.

## Paso 0 · Detecta las convenciones del repositorio

En orden de prioridad (lo que encuentres manda sobre lo que dice esta skill):

1. **Linter de commits**: la autoridad final si existe.
   ```bash
   ls commitlint.config.* .commitlintrc* 2>/dev/null
   ```
   Revisa también la clave `commitlint` de `package.json` y `.husky/commit-msg`. Respeta los tipos, scopes y longitudes que defina.
2. **Plantilla de commit**: `git config commit.template`.
3. **Historial real**: `git log --oneline -30`. De aquí sale el **idioma** de las descripciones (los *tipos* siguen siendo las palabras clave en inglés), los **scopes** en uso y los pies habituales (`Refs:`, `Closes #123`, IDs de Jira).

Si no hay nada configurado, usa lo que sigue y menciónalo brevemente.

## Paso 1 · Revisa qué se va a commitear

```bash
git status
git diff --staged    # si no hay nada en staging: git diff
```

- **Atomicidad**: un commit = un cambio lógico. Si el diff mezcla cosas no relacionadas (un fix, un refactor y una actualización de dependencias), propón dividirlo con `git add <archivos>` o `git add -p`.
- Nunca `git add .` a ciegas: añade solo los archivos del cambio.

## Paso 2 · Estructura

```text
<tipo>[(scope)][!]: <descripción>

[cuerpo: qué y por qué]

[pies]
```

### Tipos

| Tipo | Uso | SemVer |
|---|---|---|
| `feat` | Funcionalidad nueva perceptible por quien usa el software | MINOR |
| `fix` | Corrección de un bug | PATCH |
| `docs` | Solo documentación del repositorio | — |
| `style` | Formato sin cambio de lógica | — |
| `refactor` | Reestructura sin corregir bugs ni añadir funcionalidad | — |
| `perf` | Mejora de rendimiento | PATCH |
| `test` | Añadir o corregir tests | — |
| `build` | Sistema de build o dependencias | — |
| `ci` | Integración continua | — |
| `chore` | Mantenimiento que no toca código de producción ni tests | — |
| `revert` | Revierte un commit anterior | — |

**Cómo elegir bien** (donde más se falla):

| Situación | Tipo correcto | Error frecuente |
|---|---|---|
| Reordenas código con el mismo comportamiento | `refactor` | `fix` «porque quedó mejor» |
| Corriges un bug y además refactorizas | Dos commits: `fix` + `refactor` | Uno solo mezclado |
| Añades tests a código existente | `test` | `feat` |
| Actualizas una dependencia | `build` | `chore` |
| Cambias un texto visible al usuario | `feat` o `fix` según el caso | `docs` |
| Optimizas una consulta lenta | `perf` | `refactor` |

Ante la duda, elige el tipo que refleje el **impacto para quien consume el software**, no el esfuerzo técnico.

### Scope
Opcional, en minúsculas, un sustantivo del área afectada (`feat(notificaciones):`). Usa los scopes que ya aparecen en el historial en lugar de inventar variantes (`usuarios` y `users` en el mismo repositorio es ruido). Si el cambio cruza varios scopes, probablemente son varios commits.

### Descripción
- Imperativo («agrega», «corrige», «elimina»), minúscula inicial, **sin punto final**.
- Idealmente 50 caracteres o menos; el encabezado completo nunca supera 72.
- Describe **qué cambia**, no qué archivos tocaste. ❌ `fix: cambios en user.service.ts` ✅ `fix: corrige la validación de email con subdominios`.

### Cuerpo
Recomendado en cambios no triviales. Separado por una línea en blanco y ajustado a 72 columnas. Explica **por qué** se hizo y qué alternativa se descartó: responde a la pregunta que se hará quien lo lea dentro de seis meses.

### Pies
Formato de *git trailer* (`Token: valor`): `Refs: <id>`, `Closes #456`, `Co-authored-by: Nombre <email>`, `BREAKING CHANGE: ...`.

## Paso 3 · Cambios incompatibles

Márcalos con `!` antes de los dos puntos **y** con el pie `BREAKING CHANGE: <qué se rompe y cómo migrar>`. El `!` sin explicación no sirve: quien consume no sabe qué hacer. Un cambio incompatible fuerza MAJOR.

## Paso 4 · Presenta antes de ejecutar

Muestra el mensaje y espera confirmación antes de `git commit`, salvo autorización explícita. Para mensajes de varias líneas, usa varios `-m` (cada uno es un párrafo):

```bash
git commit -m "feat(auth): agrega la renovación automática del token" \
  -m "El token caducaba a los 15 minutos y obligaba a iniciar sesión de nuevo." \
  -m "Refs: 012-renovar-token"
```

## Antipatrones

- `chore: cambios varios`, `fix: arreglos`, `feat: WIP`.
- Un `feat` gigante que además corrige bugs y refactoriza.
- Descripciones que nombran archivos en lugar de comportamiento.
- Tipos inventados (`update:`, `mejora:`): rompen el changelog y el cálculo de SemVer.
- `feat` para algo que quien usa el software no puede percibir.
- `--no-verify` para saltarse los hooks.

## Reescritura de historia

Reescribir commits ya publicados (`--amend`, `rebase -i` sobre algo pusheado) afecta a todo el que tenga la rama: adviértelo y confirma antes. Los agentes automáticos no reescriben historia; si hace falta, lo hace una persona.
