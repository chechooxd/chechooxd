# ADR NNNN — <Título de la decisión>

> **Estado:** Propuesto | Aceptado | Reemplazado por ADR NNNN · **Fecha:** AAAA-MM-DD · **Spec origen:** specs/NNN-nombre

## Contexto
<Fuerzas en juego: requisitos, restricciones, estado actual. Hechos, no opiniones.>

## Decisión
<Qué se decide, en una o dos frases en voz activa: «Usaremos...».>

## Alternativas consideradas
| Alternativa | A favor | En contra |
|---|---|---|
| <A (elegida)> | <...> | <...> |
| <B> | <...> | <...> |

## Consecuencias
- Positivas: <...>
- Negativas o costes: <...>
- Qué habría que hacer para revertirla: <...>
