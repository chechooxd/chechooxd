# Contratos entre repositorios

Cuando una spec atraviesa varios repositorios (por ejemplo, un frontend Angular y un backend .NET), el mayor riesgo es que cada lado **interprete** el contrato a su manera. Ejemplo típico: el frontend documenta un envoltorio de respuesta `{ code, data, message }` mientras el backend devuelve `{ data, meta }` con errores centralizados en un middleware.

## Reglas

1. **Una única fuente de verdad** por contrato, en `specs/NNN/contracts/`, del repositorio **proveedor** (quien expone la API). El consumidor la referencia con la ruta o el enlace y la versión; no la copia ni la reescribe.
2. **Formato**: OpenAPI 3 (`*.openapi.yaml`) para HTTP; JSON Schema para mensajes y eventos. Si el equipo no usa OpenAPI, un Markdown con la tabla de campos, tipos, obligatoriedad y ejemplos reales.
3. **Ejemplos reales**: cada respuesta incluye un ejemplo de éxito y uno de cada error relevante (400, 401, 403, 404, 409, 422, 500 según corresponda), con el **envoltorio real** (paginación, metadatos, formato de error).
4. **Comprobación contra el código**: antes de dar el contrato por bueno, verifica el envoltorio y los nombres de campo en el código del proveedor (DTOs, middleware de errores, serializador y su política de mayúsculas o minúsculas). Lo que no se pueda comprobar es una pregunta `EXT-nn`.
5. **Versionado**: un cambio incompatible (eliminar o renombrar un campo, cambiar un tipo) exige versión nueva del endpoint o un periodo de convivencia. Los cambios compatibles (campos opcionales nuevos) se anotan en el historial del contrato.
6. **Tests de contrato**: el plan de cada lado incluye tests que fijan el contrato.
   - Proveedor: test de integración que serializa la respuesta real y la compara con el ejemplo del contrato.
   - Consumidor: test del servicio cliente con la respuesta de ejemplo del contrato como fixture.

## Plantilla mínima (Markdown)

```markdown
# Contrato — <Recurso> v1

**Proveedor:** <repo> · **Consumidores:** <repos> · **Estado:** Borrador | Acordado

## GET /api/<recurso>?page=1&size=20
Respuesta 200:
| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| data | array<RecursoDto> | sí | ... |
| meta.total | int | sí | ... |

Ejemplo:
{ "data": [ { "id": 1, "name": "..." } ], "meta": { "page": 1, "size": 20, "total": 1 } }

Errores: 400 { "error": { "code": "VALIDATION", "message": "...", "details": [...] } }

## Historial
| Versión | Fecha | Cambio | Compatible |
```
