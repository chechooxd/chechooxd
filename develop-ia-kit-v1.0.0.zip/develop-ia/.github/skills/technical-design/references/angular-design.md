# Diseño en Angular 20: qué evaluar

Lista para el arquitecto cuando la spec afecta a un frontend Angular. El resultado se incorpora a `plan.md`.

## Inspección previa (con hechos, no con lo que «debería» usar un proyecto genérico)
- Componentes, servicios y stores existentes del dominio afectado. Comprueba si los componentes compartidos del proyecto (tablas de mantenedor, diálogos, paginador, confirmaciones, buscador) y el servicio HTTP base ya cubren parte de la necesidad antes de proponer algo nuevo.
- Convenciones reales: standalone o `NgModule`, signals o RxJS, control de flujo nuevo o antiguo, zoneless o no. Reporta lo detectado.

## Estado: ¿dónde vive cada pieza?
| Pregunta | Decisión típica |
|---|---|
| ¿Es estado local de un componente? | `signal()` del componente |
| ¿Extiende una feature que ya usa el patrón legacy (servicio con `signal<T>()`)? | Mantener el patrón legacy por consistencia |
| ¿Es estado nuevo y compartido entre features no relacionadas? | NgRx Signal Store, previa comprobación de `@ngrx/signals` en `package.json` |
| ¿Ya existe un store dueño del dominio? | Extenderlo (`withState`, `withComputed`, `withMethods`) o componer con `withFeature` |
| ¿Hay operaciones asíncronas en el store? | `rxMethod`, sin suscripciones imperativas mezcladas |
| ¿Cuál es el ciclo de vida real del estado? | `providedIn: 'root'` frente a proveedor de ruta o de componente |

Si el patrón aplicable no es obvio, **no lo decidas**: regístralo como decisión pendiente para el usuario.

## Otras fronteras
- Smart/container frente a presentational: estado y orquestación en la capa correcta.
- Ámbito de inyección de servicios y stores nuevos.
- Carga diferida (`loadComponent`, `loadChildren`) e impacto en el tamaño del bundle.
- Compatibilidad con OnPush y zoneless: señala cualquier dependencia de Zone.js.
- Testabilidad: unidades aislables con `TestBed`; signals, effects y métodos de store testeables sin trucos de Zone.js; dependencias inyectadas.

## Backend
- **Nunca** infieras forma de payloads, campos, códigos de error, paginación, autenticación ni rendimiento de un endpoint. Si el diseño depende de ello y no está documentado, crea una pregunta `EXT-nn` (categoría `contrato`, `errores`, `auth`, `paginación`, `rendimiento` u `otra`).
- Una recomendación que depende de una `EXT` abierta se marca como **provisional** citando su ID.

## La solución más pequeña
- Extender antes que crear; YAGNI; `signal()` local antes que una entrada de store; componer un store existente antes que duplicar lógica.
