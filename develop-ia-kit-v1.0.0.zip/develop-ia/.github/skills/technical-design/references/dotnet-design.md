# Diseño en .NET 10 (API): qué evaluar

Lista para el arquitecto cuando la spec afecta a un backend .NET. El resultado se incorpora a `plan.md`.

## Capas
- Flujo `Controller → Handler (IHandler) → Repository (IRepository)`: indica qué clase de cada capa se crea o se modifica y por qué.
- Reutilización: ¿hay Handlers, Repositories o DTOs existentes que ya cubran parte del caso de uso? Cita las clases concretas.
- Registro en `Program.cs` (`AddScoped`) de las interfaces nuevas.
- Un Handler por caso de uso; nombres de método con intención (`ObtenerClientesActivosAsync`).

## DTOs y contrato
- DTOs de entrada y salida en `Models/DTO`; ninguna entidad de dominio sale del Repository.
- Envoltorio `ResponseData<T>`, con `ResponseMeta` si pagina. Errores vía middleware → `ResponseError`: define qué excepción de dominio corresponde a cada RF de tipo `SI ... ENTONCES` y qué código y mensaje produce.
- **Impacto en consumidores**: ¿cambia la forma de algún endpoint existente (campos de `Data`, `ResponseMeta`, `ResponseError`, ruta, verbo, parámetros obligatorios)? Si sí, es un **cambio de contrato**: documéntalo en `contracts/` con su versión y compatibilidad, y márcalo para comunicarlo al frontend antes de cerrar.

## Estrategia de consulta (EF Core)
- Lecturas con `AsNoTracking()` y proyección `.Select()` directa al DTO (sin `Include` ni `ThenInclude`).
- Solo las columnas necesarias; una consulta en lugar de varias cuando sea posible; paginación en la base de datos.
- Índices necesarios y migraciones compatibles hacia atrás si cambia el esquema.

## Testabilidad
- Handlers testeables con el `IRepository` sustituido por un doble.
- Repositories con el mecanismo de test de EF Core que ya use el proyecto.
- Reloj mediante `TimeProvider` y cancelación con `CancellationToken` en todas las firmas.

## Preguntas a otros equipos
- Lo que dependa del frontend u otros servicios y no esté documentado: pregunta `EXT-nn`. Una recomendación que dependa de una `EXT` abierta es **provisional**.
