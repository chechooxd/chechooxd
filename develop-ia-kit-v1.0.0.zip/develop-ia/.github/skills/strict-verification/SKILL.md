---
name: strict-verification
description: "Verificación estricta y basada en evidencia de una spec implementada: ejecución propia de la suite, el build y el lint, matriz RF → test → resultado, casos límite, RNF, criterios de finalización y constitución, verificación de interfaz con Chrome DevTools y reglas de veredicto. Prohíbe la verificación heurística. Úsala en la etapa de verificación."
---

# Verificación estricta

**Solo cuenta la evidencia que produces tú en esta ejecución.** Buscar palabras clave en el código, leer el diff y «ver que parece correcto» o fiarse de lo que dijo otro agente **no es evidencia**.

## Qué es evidencia válida

| Tipo | Válida si |
|---|---|
| Test automático | Existe, su nombre lleva el RF (`RF-nn:`), se ha ejecutado en esta verificación y su resultado aparece en la salida. |
| Ejecución de comando | Se incluyen el comando, el código de salida y los totales. |
| Comprobación de interfaz | Hecha con Chrome DevTools (MCP) en esta verificación, describiendo lo observado (y la vista móvil de 375 px si hay interfaz). |
| Comprobación manual | Solo la puede dar el humano: se marca `PENDIENTE MANUAL` con los pasos exactos. |

## Proceso

0. **Precondición**: la revisión de código de esta spec debe constar como `APROBADO`. Si no consta, indícalo en el informe (la verificación demuestra que la spec se cumple; la calidad del código es responsabilidad de la revisión).
1. **Ejecuta** la suite completa, el build y el lint con los comandos de `AGENTS.md`. Anota los códigos de salida y los totales (pasando, fallando, omitidos).
   - Cualquier test omitido (`skip`) en el código de la spec es un incumplimiento.
   - Si un comando **no puede ejecutarse** (por ejemplo, falta un navegador headless para Karma), dilo explícitamente: el veredicto es `NO CUMPLE` por falta de evidencia, nunca se asume que la suite pasaría.
   - No reportes la ausencia de e2e como incumplimiento si el proyecto no lo tiene configurado y la spec no lo exige.
2. **Mapea RF → tests**: busca el prefijo `RF-nn:` en los archivos de test. Cruza cada test con su resultado en la salida.
3. **Clasifica cada RF**:
   - ✅ `CUMPLE`: al menos un test del RF ejecutado y en verde que realmente afirma la respuesta del RF.
   - ❌ `NO CUMPLE`: algún test del RF falla, o el test no afirma lo que dice el RF.
   - ❌ `NO CUBIERTO`: sin test ni verificación definida.
   - 🟡 `PENDIENTE MANUAL`: el plan define una verificación manual que no puedes hacer tú.
4. **Casos límite**: cada `CL-nn` tiene al menos un test en verde.
5. **RNF**: verifica los medibles que se puedan medir (rendimiento con el test o benchmark del plan, idioma de los textos, accesibilidad básica con DevTools). Lo no medible aquí, `PENDIENTE MANUAL`.
6. **Criterios de finalización** de la spec, uno a uno.
7. **Constitución**: los principios aplicables al cambio.
8. **Trazabilidad**: todas las tareas `[x]` con evidencia RED (las de tipo TDD) y GREEN.
9. **Preguntas externas**: ninguna `EXT-nn` del plan puede seguir `abierta`. Una sola abierta es incumplimiento, digan lo que digan los demás chequeos.
10. **Impacto en consumidores**: si el plan declara cambios de contrato, comprueba que el contrato en `contracts/` refleja lo implementado (tests de contrato en verde).

## Reglas de veredicto

| Veredicto | Condición |
|---|---|
| `CUMPLE` | Todos los RF y CL ✅, suite, build y lint en verde, criterios de finalización cumplidos, constitución respetada. |
| `CUMPLE CON PENDIENTES MANUALES` | Como `CUMPLE`, salvo RF o RNF en 🟡 con pasos exactos para el humano. |
| `NO CUMPLE` | Cualquier ❌, test fallando u omitido, build o lint rotos, comando que no se pudo ejecutar, criterio de finalización incumplido o pregunta `EXT` abierta. |

## Persistencia

El verificador no escribe archivos. Su informe literal lo guarda `sdd-archivist` en `specs/NNN/verification.md` con la plantilla [verification-template.md](./assets/verification-template.md).
