---
name: task-breakdown
description: "Divide un plan técnico aprobado en tasks.md: tareas pequeñas de 20 a 30 minutos en orden de dependencia, cada una con RF y casos límite, tipo (TDD o sin-test), archivos, tests a escribir, criterio Hecho cuando verificable y campos de evidencia RED y GREEN. Úsala al generar o ajustar las tareas de una spec."
---

# Troceado en tareas

Las tareas son la unidad de trabajo del ciclo TDD. Una buena tarea se puede implementar sin tomar decisiones de diseño y se verifica con un comando.

## Reglas

1. **Una tarea = un comportamiento observable**, con sus tests. Nunca separes «escribir tests» y «escribir código» en tareas distintas: el ciclo RED → GREEN → REFACTOR ocurre **dentro** de cada tarea.
2. **Tamaño**: de 20 a 30 minutos de trabajo humano equivalente. Si es mayor, divídela. Si salen más de 10 tareas, propón dividir la spec.
3. **Orden de dependencia**:
   1. Contratos, tipos y modelos.
   2. Lógica pura (reglas, cálculos, validaciones).
   3. Integración y E/S (servicios, repositorios, HTTP).
   4. Interfaz (componentes, vistas, estados).
   5. Cableado final (rutas, registro de dependencias, menús).
4. **Paralelismo**: marca con `[P]` las tareas que no comparten archivos ni dependen entre sí.
5. **Tipo**:
   - `TDD` (por defecto): tiene tests que deben fallar antes del código.
   - `sin-test`: solo configuración, andamiaje o estilos sin lógica. Justifícala en una línea e indica la verificación alternativa (build, lint o comprobación manual concreta). Si dudas, es `TDD`.
6. **Tests a escribir**: nombres completos que empiezan por el identificador (`RF-02: ...`, `CL-01: ...`). Todos los casos límite de la spec tienen un test en alguna tarea.
7. **Hecho cuando**: una comprobación objetiva, normalmente un comando con un resultado esperado. ❌ «Funciona bien». ✅ «`npm run test -- --watch=false` en verde con los tests RF-02 y CL-01 incluidos».
8. **Ajustes**: nunca renumeres. Las tareas nuevas toman el siguiente número; las anuladas se tachan con `~~...~~` y el motivo.

## Evidencia

Los campos de evidencia los rellenan los agentes TDD, nunca el planificador:

- `Evidencia RED` → `tdd-test-author`
- `Evidencia GREEN` → `tdd-implementer`, que además marca la casilla `[x]`

Formato en la skill [tdd-cycle](../tdd-cycle/SKILL.md).

## Plantilla

Usa [tasks-template.md](./assets/tasks-template.md).
