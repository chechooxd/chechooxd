# Tareas NNN — <Nombre>

> **Plan:** [plan.md](./plan.md) · **Fecha:** AAAA-MM-DD · **Progreso:** 0/<n>

## Secuencia
T01 → T02 → [P] T03, T04 → T05

## Cobertura
| RF / CL | Tareas |
|---|---|
| RF-01 | T01 |
| CL-01 | T01 |

---

- [ ] **T01 · <Título del comportamiento>** — RF-01, CL-01
  - Tipo: TDD
  - Archivos: `ruta/nuevo.ext` (crear) · `ruta/existente.ext` (modificar)
  - Tests a escribir:
    - `RF-01: <comportamiento esperado>`
    - `CL-01: <caso límite>`
  - Depende de: —
  - Hecho cuando: `<comando de test>` en verde con los tests RF-01 y CL-01 incluidos, y la suite completa en verde.
  - Evidencia RED: _pendiente_
  - Evidencia GREEN: _pendiente_

- [ ] **T02 · <Título>** — RF-02
  - Tipo: TDD
  - Archivos: <...>
  - Tests a escribir:
    - `RF-02: <...>`
  - Depende de: T01
  - Hecho cuando: <...>
  - Evidencia RED: _pendiente_
  - Evidencia GREEN: _pendiente_

- [ ] **T03 · <Título>** [P] — RF-05
  - Tipo: sin-test — <justificación en una línea>
  - Archivos: <...>
  - Verificación alternativa: <build, lint o comprobación manual exacta>
  - Depende de: T01
  - Hecho cuando: <...>
  - Evidencia GREEN: _pendiente_
