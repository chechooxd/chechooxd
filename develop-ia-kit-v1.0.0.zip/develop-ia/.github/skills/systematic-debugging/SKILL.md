---
name: systematic-debugging
description: "Depuración con método cuando un test falla de forma inesperada, la verificación detecta un fallo o hay un bug: reproducir, aislar, formular una hipótesis cada vez, comprobarla y corregir la causa raíz, nunca el síntoma. Úsala antes de cambiar código para arreglar un fallo que no entiendes."
---

# Depuración sistemática

Regla de oro: **no cambies código hasta entender por qué falla.** Los cambios a ciegas («a ver si así...») introducen bugs nuevos y ocultan la causa real.

## Proceso

### 1. Reproducir
- Ejecuta el test o los pasos exactos y captura la salida completa: mensaje, valores esperados y obtenidos, traza.
- Si no se reproduce de forma consistente, busca no determinismo: reloj, zona horaria, orden de los tests, estado compartido, concurrencia o red.

### 2. Aislar
- Reduce el caso: el test mínimo, el dato mínimo, la función más interna que todavía falla.
- Compara con un caso que funciona: ¿qué cambia entre los dos?
- Si el fallo apareció tras un cambio, revisa el diff (`git diff`) del último paso en verde.

### 3. Formular una hipótesis
- Escríbela en una frase falsable: «Falla porque `parseDate` interpreta `AAAA-MM-DD` en UTC y en la zona del test el día cambia».
- **Una hipótesis cada vez**, empezando por la más probable y la más barata de comprobar.

### 4. Comprobar
- Diseña la comprobación mínima que confirma o descarta la hipótesis: un log temporal, una aserción intermedia, un test aislado.
- Si se descarta, vuelve al paso 3 con lo aprendido. Elimina los logs temporales.

### 5. Corregir la causa raíz
- Corrige el origen, no el síntoma. Si el mismo error puede repetirse en otros sitios, anótalo.
- Ejecuta el test que fallaba y después la suite completa.

## Límites

- Como máximo **3 hipótesis descartadas** por fallo. Después, para y devuelve `BLOQUEADO` con el diagnóstico.
- **Nunca** «arregles» un fallo modificando el test, ampliando timeouts sin entender el motivo o capturando la excepción.

## Diagnóstico (formato)

```markdown
## Diagnóstico
- Síntoma: <qué falla y cómo se ve>
- Reproducción: `<comando>` → <resultado>
- Hipótesis probadas:
  1. <hipótesis> → descartada | confirmada: <evidencia>
- Causa raíz: <explicación en 1 a 2 frases> (`ruta:línea`)
- Corrección: <qué se cambió> | pendiente (BLOQUEADO)
- Riesgo de que se repita en: <otros sitios> | ninguno
```
