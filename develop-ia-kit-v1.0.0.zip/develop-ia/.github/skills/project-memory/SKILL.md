---
name: project-memory
description: "Gestión de MEMORY.md, la memoria del proyecto entre sesiones: qué registrar (estado actual, decisiones con su porqué, aprendizajes y errores a evitar, próximos pasos), límite de unas 50 líneas, qué no guardar nunca y cuándo convertir una lección en regla permanente. Úsala al empezar una tarea grande y al cerrar una spec o un bugfix."
---

# Memoria del proyecto (MEMORY.md)

La ventana de contexto de un agente es limitada y cada sesión empieza de cero. `MEMORY.md` es la memoria a largo plazo del proyecto: **corta, actual y útil**.

## Al empezar

Lee `MEMORY.md` para conocer el estado, las decisiones tomadas y los errores que no hay que repetir.

## Al terminar (cierre de una spec o un bugfix)

Actualiza solo lo que **aporte a futuras sesiones**:

| Sección | Qué va | Ejemplo |
|---|---|---|
| Estado actual | Qué funciona hoy, en 3 a 6 líneas. Specs implementadas recientes. | «007 programar envío: implementada (v1.0).» |
| Decisiones (y por qué) | Decisiones que condicionan el futuro, con su motivo en una línea. | «Fechas siempre en la zona del perfil del usuario: el servidor está en UTC.» |
| Aprendizajes y errores a evitar | Trampas encontradas y cómo evitarlas. | «`new Date('AAAA-MM-DD')` se interpreta en UTC: usa `parseLocalDate`.» |
| Próximos pasos | Lo que queda pendiente y está acordado. | «Pendiente manual de 007: comprobar en Safari.» |

## Reglas

1. **Máximo unas 50 líneas.** Al añadir, resume o elimina lo que ya no aporte (por ejemplo, el detalle de specs antiguas: basta con la lista).
2. **Hechos, no narrativa.** Una línea por entrada.
3. **Nunca** guardes secretos, tokens, contraseñas, datos personales ni datos de clientes.
4. **De memoria a regla**: si un aprendizaje debe cumplirse siempre, **propón** moverlo a `AGENTS.md` (convención) o a la constitución (principio) en lugar de dejarlo en la memoria. No lo muevas sin aprobación.
5. La memoria no sustituye a la spec: el comportamiento acordado vive en `specs/`.
