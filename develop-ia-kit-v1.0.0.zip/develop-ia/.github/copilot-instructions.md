# Instrucciones de GitHub Copilot

Este repositorio se desarrolla con **Spec-Driven Development (SDD) + Test-Driven Development (TDD)** mediante un sistema multiagente propio. El contexto del proyecto (stack, comandos, convenciones y límites) está en [AGENTS.md](../AGENTS.md); los principios innegociables, en [docs/constitution.md](../docs/constitution.md).

## Cómo se trabaja
- **Funcionalidades nuevas, cambios de requisitos y bugs** pasan por el agente `sdd-orchestrator` (o por los comandos `/sdd-*`). El orquestador delega cada etapa en su subagente especialista y se detiene en los gates de aprobación humana.
- **Cambios triviales sin comportamiento nuevo** (erratas, renombrados, formato) pueden hacerse con el agente por defecto, respetando `AGENTS.md`.
- Guía de uso: [docs/sdd/GUIA-DESARROLLADORES.md](../docs/sdd/GUIA-DESARROLLADORES.md).

## Reglas globales
1. **La spec manda.** No implementes comportamiento que no esté en una spec aprobada de `specs/`. Si falta una decisión, para y pregunta.
2. **TDD.** El test existe y falla antes que el código. Nunca modifiques, omitas ni debilites un test para que pase.
3. **Evidencia.** No digas que algo funciona sin haber ejecutado los tests: indica el comando, el código de salida y el resultado.
4. **Dependencias.** Comprueba los manifiestos antes de usar una librería. No añadas dependencias sin aprobación explícita.
5. **Memoria.** Lee `MEMORY.md` al empezar una tarea no trivial; actualízalo al cerrar una spec o un bugfix.
6. **Seguridad.** Nunca escribas secretos ni ejecutes comandos destructivos, `push` o `--no-verify`.
