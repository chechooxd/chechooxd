# Constitución — <Nombre del proyecto>

> **Estado:** Plantilla · **Versión:** 0.0.0 · **Fecha:** —

<!--
Este archivo está en estado «Plantilla»: el orquestador no iniciará ninguna spec hasta que se proponga y ratifique.
Ejecuta /sdd-constitution para que sdd-architect proponga los principios a partir del código, AGENTS.md y MEMORY.md.
Guía y ejemplos: .github/skills/project-constitution/SKILL.md
-->

Principios innegociables. Toda spec, plan, tarea y cambio de código debe cumplirlos. Un incumplimiento es un hallazgo bloqueante.

1. **<Stack y simplicidad>**: <regla verificable>.
2. **La spec manda**: nada se implementa si no está en una spec aprobada. Si falta una decisión, se para y se pregunta.
3. **<Arquitectura>**: <límite que no se cruza>.
4. **Tests como puerta**: TDD obligatorio para todo comportamiento; prohibido avanzar con tests en rojo, omitidos o debilitados.
5. **Seguridad**: los controles base de seguridad del kit (`.github/instructions/security.instructions.md`) se aplican por defecto; omitir uno es una decisión del desarrollador registrada como `DS-nn`, nunca un bloqueo. <Qué más es sagrado en los datos>.
6. **<Contratos>**: <fuente de verdad de las integraciones>.
7. **Idioma**: <idioma del código>; <idioma de la interfaz, specs y documentación>.

## Historial

| Versión | Fecha | Cambio | Motivo |
|---|---|---|---|
| 0.0.0 | — | Plantilla del kit | — |
