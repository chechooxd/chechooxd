# AGENTS.md — Backoffice Notificaciones (frontend)
Backoffice web para gestionar notificaciones. Solo frontend: el backend (.NET 10) vive en otro repositorio.

## Stack y estructura
- Angular 20.3 standalone + detección de cambios zoneless · PrimeNG 20.4 (tema Aura) · Jasmine + Karma.
- `src/app/core/` servicios singleton, modelos e interfaces · `shared/` componentes reutilizables · `feature/` páginas. Barrels: `@app/core`, `@app/shared`.
- Reutiliza antes de crear: `TablaMantenedorComponent`, `DialogMantenedorComponent`, `PaginadorCustomComponent`, `ConfirmDialogComponent`, `SearchInputComponent` (en `shared/components/`); `ApiService` (HTTP base) y `AlertBannerService` (avisos con signals).

## Comandos
- Instalar: `npm ci`
- Tests (suite completa, sin watch): `npm run test -- --watch=false`
- Tests de un archivo: `npm run test -- --watch=false --include='<ruta>.spec.ts'`
- Lint: `<CONFIRMAR: npm run lint>` · Build: `<CONFIRMAR: npm run build>`

## Contrato con el backend (confirmado)
- Envoltorio `ResponseData<T>` con la propiedad `Data`; `ResponseMeta` en endpoints paginados (`PaginaActual`, `TotalPaginas`, `TotalRegistros`); errores centralizados en `ResponseError` por el middleware del backend.
- `ApiResponse<T>` o `{ code, data, message }` están **desactualizados**: si aparecen, se señalan y no se replican.
- Nada más del backend se asume: lo no documentado es una pregunta `EXT-nn` del plan.

## Convenciones
- Estado: local con `signal()`; legacy con servicio singleton y `signal<T>()` (por ejemplo, `RolesService`); NgRx Signal Store solo para estado nuevo compartido entre features y tras comprobar `@ngrx/signals` en `package.json`. Si no es obvio, se pregunta.
- Componentes smart frente a presentational; OnPush; `input()`/`output()`; `@for` con `track`.
- Idioma: <CONFIRMAR: código en inglés o español>; interfaz, specs y documentación en español.

## Seguridad
- Exposición: `<CONFIRMAR: Internet | Interna>`. Orienta las recomendaciones de seguridad; las decide el desarrollador (skill `secure-development`).

## Ramas y PR
- Rama de integración `dev`. Una spec = `feature/NNN-nombre` desde `dev` (antes del primer artefacto) = un PR a `dev` → QA → `main`.
- Sin commitlint ni husky: la skill `conventional-commits` es la única garantía del historial. Pie `Refs: NNN-nombre`.

## Forma de trabajar (SDD + TDD)
- Funcionalidades, cambios y bugs: agente `sdd-orchestrator` o comandos `/sdd-*`.
- Lee `docs/constitution.md` y la spec activa antes de tocar código. TDD: test en rojo antes que el código.

## Memoria
- Al empezar, lee `MEMORY.md`; al cerrar una spec o un bugfix, actualízalo (máximo unas 50 líneas).

## Límites
- ✅ Siempre: respetar el contrato confirmado; ejecutar la suite completa antes de dar algo por terminado.
- ⚠️ Pregunta antes: dependencias nuevas (incluida `@ngrx/signals`), cualquier supuesto sobre el backend, cambios de patrón de estado.
- 🚫 Nunca: inferir el contrato del backend; modificar o desactivar tests para que pasen; `git push`, `--force` ni `--no-verify`.

## Verificación
- Suite completa en verde y, si hay interfaz, comprobación con Chrome DevTools (incluida la vista móvil). No hay e2e configurado.
