# AGENTS.md — <Nombre del proyecto>
<Una o dos frases: qué es, para quién y cuál es su objetivo.>

## Stack y estructura
- <Tecnologías y versiones clave, ej. Angular 20.3 (zoneless) + PrimeNG 20 · .NET 10>
- `<carpeta>/` — <qué contiene (solo lo que no es obvio)>

## Comandos
- Instalar: `<comando>`
- Tests (suite completa, sin watch): `<comando>`
- Tests de un archivo o por RF: `<comando>`
- Lint: `<comando>` · Build: `<comando>`

## Convenciones
- Código en <idioma>; interfaz, specs y documentación en <idioma>.
- <Estilo de nombres y patrones a seguir, con su archivo de referencia>

## Reglas de dominio y trampas conocidas
- <Lo que es fácil hacer mal y no se deduce leyendo el código>

## Seguridad
- Exposición: <Internet | Interna (solo red corporativa o VPN)>. Orienta las recomendaciones de seguridad; las decide el desarrollador (skill `secure-development`).

## Ramas y PR
- Rama de integración: `dev`. Una spec = una rama `feature/NNN-nombre` (creada desde `dev` antes del primer artefacto) = un PR a `dev` → QA → `main`.
- Título del PR en Conventional Commits; commits con el pie `Refs: NNN-nombre`.

## Forma de trabajar (SDD + TDD)
- Funcionalidades, cambios y bugs: agente `sdd-orchestrator` o comandos `/sdd-*` (guía: `docs/sdd/GUIA-DESARROLLADORES.md`).
- Lee `docs/constitution.md` y la spec activa (`specs/NNN-*/`) antes de tocar código.
- TDD: test en rojo antes que el código; nunca avances con tests en rojo u omitidos.
- Cambios pequeños y enfocados; al terminar, resume qué cambió y qué decisiones debo revisar.

## Memoria
- Al empezar, lee `MEMORY.md`. Al cerrar una spec o un bugfix, actualízalo (máximo unas 50 líneas, sin datos sensibles).

## Límites
- ✅ Siempre: respetar la constitución y la spec; ejecutar la suite completa antes de dar algo por terminado; actualizar `MEMORY.md` al cerrar.
- ⚠️ Pregunta antes: dependencias nuevas, cambios en contratos o formatos de datos, migraciones, archivos fuera del plan.
- 🚫 Nunca: secretos en el repositorio; modificar o desactivar tests para que pasen; `git push`, `--force` ni `--no-verify`.

## Verificación
- Un cambio está terminado cuando la suite completa, el lint y el build están en verde y, si hay interfaz, se ha comprobado en el navegador (Chrome DevTools, incluida la vista móvil).
