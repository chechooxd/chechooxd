# develop-ia · Kit de desarrollo agéntico SDD + TDD para GitHub Copilot

Estrategia de desarrollo con IA agéntica para GitHub Copilot basada en **Spec-Driven Development** (modelo *spec-anchored*) y **Test-Driven Development** estricto. Un **orquestador** dirige el flujo y delega cada etapa en un **subagente especialista** con sus propias skills, herramientas mínimas y guardarraíles. Todo es propio: sin OpenSpec, spec-kit ni skills de terceros.

## Flujo

```text
0 Constitución ─► 1 Exploración ─► 2 Spec (EARS) ─► 3 Clarificación ─► 🔒 Gate 1
─► 4 Diseño (± duelo de diseño) ─► 5 Tareas + consistencia ─► 🔒 Gate 2
─► 6 TDD por tarea (RED: test-author → GREEN + REFACTOR: implementer)
─► 7 Revisión de código (o juicio dual) ─► 8 Verificación RF por RF ─► 9 Cierre ─► 🔒 Gate 3
```

**Seguridad que informa, sin bloquear.** Once controles base, tomados de estándares abiertos (OWASP Top 10:2025, OWASP ASVS 5.0, OWASP Proactive Controls 2024, OWASP API Security Top 10 2023, CWE Top 25 2025 y NIST SSDF), se aplican por defecto, y la seguridad aparece en cada etapa: permisos y casos de abuso en la spec, modelo de amenazas en el plan, tests negativos, revisión y verificación de dependencias y secretos. Ningún control detiene el flujo: según la exposición del proyecto (Internet o interna), el agente recomienda y el desarrollador decide, y su decisión queda registrada (`DS-nn`). Skill `secure-development`.

## Contenido

| Carpeta | Contenido |
|---|---|
| [`.github/agents/`](.github/agents) | `sdd-orchestrator` + 12 subagentes: uno por etapa y los dos jueces del juicio dual |
| [`.github/skills/`](.github/skills) | 17 skills con plantillas (`assets/`) y referencias |
| [`.github/instructions/`](.github/instructions) | Reglas por patrón: specs, tests, controles base de seguridad, diseño simple, Angular 20, .NET 10, memoria, commits y mantenimiento del kit |
| [`.github/prompts/`](.github/prompts) | Comandos `/sdd-*` (flujo completo, paso a paso, cambio, bugfix, estado e instalación) |
| [`.github/hooks/`](.github/hooks) | Guardarraíles `preToolUse`: permisos por ruta y comandos prohibidos por agente |
| [`.github/copilot-instructions.md`](.github/copilot-instructions.md) | Reglas globales de Copilot |
| [`AGENTS.md`](AGENTS.md) · [`MEMORY.md`](MEMORY.md) | Contexto y memoria del proyecto (plantillas) |
| [`docs/constitution.md`](docs/constitution.md) | Constitución (plantilla, se propone con `/sdd-constitution`) |
| [`docs/sdd/`](docs/sdd) | [Guía](docs/sdd/GUIA-DESARROLLADORES.md) · [Arquitectura](docs/sdd/ARQUITECTURA.md) · [Instalación](docs/sdd/INSTALACION.md) · [Perfiles de AGENTS.md](docs/sdd/perfiles) (frontend Angular y backend .NET) |
| [`specs/`](specs) | Aquí nacen las specs (`NNN-nombre/`) |
| [`.vscode/`](.vscode) | Ajustes recomendados y MCP opcionales (Chrome DevTools, Context7) |

## Inicio rápido

1. Copia el kit en tu repositorio ([INSTALACION.md](docs/sdd/INSTALACION.md)).
2. `/sdd-init` → completa `AGENTS.md` y `MEMORY.md` con el stack real.
3. `/sdd-constitution` → aprueba los principios del proyecto.
4. `/sdd-feature <tu funcionalidad>` → el orquestador hace el resto y te pide aprobación en cada gate.

## Agentes

| Etapa | Agente | Escribe |
|---|---|---|
| Coordinación | `sdd-orchestrator` | — (no edita) |
| 1 Exploración | `sdd-explorer` | `research.md` |
| 2 Especificación | `sdd-spec-writer` | `spec.md` |
| 3 y 5 QA de specs | `sdd-spec-reviewer` | — (solo lectura) |
| 0 y 4 Constitución y diseño | `sdd-architect` | `plan.md`, `contracts/`, ADR, constitución |
| 5 Tareas | `sdd-task-planner` | `tasks.md` |
| 6a TDD · RED | `tdd-test-author` | Tests |
| 6b TDD · GREEN + REFACTOR | `tdd-implementer` | Código (nunca tests) |
| 7 Revisión | `code-reviewer` | — (solo lectura) |
| 4 y 7 Duelo de diseño y juicio dual | `sdd-judge-a`, `sdd-judge-b` (modelos de familias distintas) | — (solo lectura) |
| 8 Verificación | `sdd-verifier` | — (solo lectura) |
| 9 Cierre | `sdd-archivist` | Informes, `MEMORY.md`, CHANGELOG, commits autorizados |

Basado en los apuntes del *Curso de Desarrollo con IA* (BIG school) y adaptado a los formatos vigentes de GitHub Copilot (`.agent.md`, `SKILL.md`, `.prompt.md`, `.instructions.md` y hooks).
