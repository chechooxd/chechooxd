# Changelog del kit

Formato basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.1.0/) y versionado semántico.

## [1.3.0] - 2026-10-26

### Añadido
- Instrucción `simplicity.instructions.md` (diseño simple, sin sobreingeniería): prueba rápida para cada pieza nueva («¿qué RF, RNF o convención la exige hoy?») y once reglas comprobables (solo lo que pide la spec, abstraer a partir de dos usos reales, las convenciones del proyecto no son sobreingeniería, reutilizar antes de crear, patrones solo con un problema delante, sin optimización prematura, sin defensa imaginaria, sin dependencias por comodidad, menos indirección, tests a la medida y refactor que simplifica).
- «Piezas nuevas» en el §3 de la plantilla de plan: cada interfaz, clase base, genérico, patrón, capa, opción de configuración o dependencia, con lo que la exige, visible en el Gate 2.
- Señales concretas de sobreingeniería en las listas de revisión de .NET y Angular.

### Cambiado
- Diseño técnico, arquitecto, QA de consistencia, ciclo TDD (el refactor simplifica, no generaliza), implementador, autor de tests, revisión de código, flujo SDD, Gate 2, guía y arquitectura, alineados con la regla de diseño simple.

## [1.2.0] - 2026-10-26

### Añadido
- Skill `secure-development`: la seguridad aparece en cada etapa del flujo, con una base normativa abierta e independiente de proveedor (OWASP Top 10:2025, OWASP ASVS 5.0, OWASP Top 10 Proactive Controls 2024, OWASP API Security Top 10 2023, CWE Top 25 2025 y NIST SSDF).
- **La seguridad informa, el desarrollador decide**: ningún control de seguridad detiene el flujo. Cada punto llega como decisión pendiente con una recomendación según la exposición del proyecto (Internet o interna), y el desarrollador elige aplicar, aceptar el riesgo o «no aplica». La decisión queda registrada en la spec como `DS-nn` y no se vuelve a preguntar; lo que decide aplicar se verifica como cualquier requisito.
- Exposición del proyecto en `AGENTS.md` y en los perfiles, con una tabla de recomendación por control (recomendado u opcional, según sea Internet o interna).
- Sección «Seguridad» en la plantilla de spec (exposición, sensibilidad, datos, matriz de permisos, casos de abuso propuestos y decisiones `DS-nn`) y §4.5 «Seguridad y modelo de amenazas» en la plantilla de plan (identificador `AM-nn`), que se hace solo si el desarrollador lo decide.
- Patrones EARS de seguridad, catálogo de casos de abuso, modelo de amenazas STRIDE ligero y patrones de tests negativos (.NET con NUnit y Angular).
- Listas de revisión de seguridad para .NET (API) y ampliación de la de Angular, con severidad ALTA, MEDIA o BAJA como orientación.

### Cambiado
- `security.instructions.md` pasa a ser la lista de **once controles base de seguridad**: se aplican por defecto al escribir código y omitir uno es una decisión del desarrollador. Las protecciones del hook frente a la IA (comandos destructivos, edición de `.env`) se mantienen.
- La revisión, el juicio dual, la QA de specs y la verificación informan los puntos de seguridad en su propia sección, sin cambiar el veredicto, salvo que se incumpla un RF de seguridad aprobado en la spec.
- Orquestador (momentos de decisión y pregunta por el modelo de amenazas tras el Gate 1), arquitecto, redactor de specs, autor de tests, verificador, archivista, flujo SDD (regla, identificadores `AM-nn` y `DS-nn`, DoD), constitución, guía, arquitectura e instalación, actualizados.

## [1.1.0] - 2026-10-24

### Añadido
- Juicio dual (*Judgment Day*) en la etapa 7: dos jueces nuevos, `sdd-judge-a` y `sdd-judge-b`, con modelos fijados de familias distintas, revisan a ciegas y en paralelo el diff congelado. El orquestador cruza los hallazgos (confirmado, sospechoso, contradicción), corrige solo lo confirmado con los subagentes TDD y re-juzga el delta: máximo 2 rondas, veredicto `APROBADO` o `ESCALADO`. Se activa por riesgo (contrato, seguridad, migraciones, tamaño, incidente en producción) o a petición.
- Duelo de diseño en la etapa 4: para decisiones con alternativas reales, los dos jueces proponen a ciegas y el usuario elige con la comparación delante; la decisión queda en un ADR.
- Skill `judgment-day` con el protocolo y los formatos, comandos `/sdd-juicio` y `/sdd-duelo`, y política de solo lectura de los jueces en el hook.

### Cambiado
- Tests del backend con **NUnit** (antes se suponía xUnit + Moq, sin confirmar): convenciones del perfil .NET (trazabilidad con `[Category("RF-nn")]` y `[Description]`, modelo de restricciones, ciclo de vida de la instancia de la clase, `async Task`), comandos con `--filter "TestCategory=RF-nn"`, antipatrones de NUnit (`[Ignore]`, `[Explicit]`, `Assert.Ignore()`, `Assert.Inconclusive()`) y verificación por RF con el filtro de categoría. La librería de dobles queda por confirmar en el perfil `AGENTS.backend-dotnet.md`.
- Orquestador, arquitecto, flujo SDD, cierre, verificación, guía, arquitectura e instalación, actualizados para el juicio dual y el duelo de diseño.

## [1.0.0] - 2026-10-23

### Añadido
- Orquestador `sdd-orchestrator` y 10 subagentes especializados por etapa (exploración, especificación, QA de specs, diseño, tareas, TDD RED, TDD GREEN + REFACTOR, revisión, verificación y cierre).
- 15 skills propias con plantillas: flujo SDD, constitución, exploración, EARS, QA de specs, diseño técnico y contratos, troceado de tareas, ciclo TDD, depuración sistemática, revisión de código, verificación estricta, cierre, gestión de cambios, Conventional Commits y memoria del proyecto.
- Instrucciones por patrón: artefactos SDD, tests, seguridad, perfiles Angular 20 y .NET 10, memoria, mensajes de commit y mantenimiento del kit.
- Comandos `/sdd-*`: flujo completo, etapas individuales, cambio, bugfix, estado e instalación.
- Hook de guardarraíles `preToolUse` con política por agente (fail-open).
- Plantillas de `AGENTS.md`, `MEMORY.md` y constitución; guía, arquitectura e instalación.
- Perfiles de `AGENTS.md` para el frontend Angular y el backend .NET, y listas de diseño y revisión por stack, a partir de las reglas ya confirmadas en la versión anterior con OpenSpec (contrato `ResponseData<T>`, capas, EF Core sin `Include`, patrones de estado, protocolo de preguntas al backend y ramas `feature/*` desde `dev`).
