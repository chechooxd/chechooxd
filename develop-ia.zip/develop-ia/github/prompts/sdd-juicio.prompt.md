---
description: "SDD · Etapa 7 como juicio dual (Judgment Day): dos jueces con modelos de familias distintas revisan a ciegas el diff de la rama, se cruzan sus hallazgos y se corrige lo confirmado."
argument-hint: "NNN-nombre [rama base, por defecto la de integración: dev]"
agent: sdd-orchestrator
---

Ejecuta **la Etapa 7 como juicio dual** de `specs/NNN-nombre/` (identificador y, opcionalmente, la rama base en el texto que acompaña a este comando; por defecto, la rama de integración definida en `AGENTS.md`, normalmente `dev`), aunque no se cumpla ningún criterio de riesgo.

1. Sigue el protocolo «Juicio de código» de la skill `judgment-day`: objetivo congelado y `sdd-judge-a` y `sdd-judge-b` en paralelo (modo `juzgar`) con el mismo encargo literal.
2. Muéstrame la tabla de cruce y pregúntame, de uno en uno, por los sospechosos y las contradicciones.
3. Corrige los confirmados y lo que yo decida con `tdd-test-author` y `tdd-implementer` (modo `corregir`), propón el commit de las correcciones y re-juzga el delta. Máximo 2 rondas.
4. Termina con el veredicto (`APROBADO` o `ESCALADO`) y la tabla de cruce final.
