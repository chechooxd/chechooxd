---
description: "SDD · Etapa 4 con duelo de diseño: dos jueces con modelos de familias distintas proponen a ciegas cómo resolver una decisión técnica y eliges con la comparación delante."
argument-hint: "NNN-nombre D-nn (o la pregunta de diseño si aún no tiene identificador)"
agent: sdd-orchestrator
---

Ejecuta un **duelo de diseño** en `specs/NNN-nombre/` para la decisión indicada en el texto que acompaña a este comando.

1. Comprueba que `spec.md` está `Aprobada`. Si la decisión aún no tiene planteamiento, pide a `sdd-architect` (modo `disenar` si no hay plan, `ajustar` si ya existe) que lo redacte: pregunta, contexto, restricciones, RF afectados y criterios de evaluación, sin la decisión.
2. Sigue el protocolo «Duelo de diseño» de la skill `judgment-day`: `sdd-judge-a` y `sdd-judge-b` en paralelo (modo `proponer`) con el mismo planteamiento literal.
3. Muéstrame la comparación (juez A, juez B y la decisión provisional del arquitecto, si existe) con tu recomendación, y espera mi elección.
4. Con mi elección, `sdd-architect` en modo `ajustar` actualiza `plan.md` y genera el ADR con todas las propuestas como alternativas consideradas.

No generes las tareas ni escribas código.
