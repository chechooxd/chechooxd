---
description: "SDD · Bugfix con TDD. Localiza la causa, escribe un test de regresión que falla, corrige, revisa, verifica y registra."
argument-hint: "Descripción del bug (pasos, esperado y obtenido) [NNN-nombre si sabes la spec]"
agent: sdd-orchestrator
---

Ejecuta el **flujo bugfix** para el bug que describe el texto que acompaña a este comando.

1. `sdd-explorer` en modo `bug`: reproducción, causa probable (`ruta:línea`) y RF incumplido.
2. Si el comportamiento esperado **no está en ninguna spec**, para: es un requisito no especificado y debe ir por `/sdd-change` o por una spec nueva. Pregúntame.
3. `tdd-test-author` en modo `regresion`: un test que reproduce el bug y falla (RED con evidencia). El nombre del test lleva el RF afectado.
4. `tdd-implementer`: la corrección mínima, con la suite completa en verde.
5. `code-reviewer` (o juicio dual si el bug ocurrió en producción o se cumple otro criterio de riesgo de la skill `judgment-day`) → `sdd-verifier` (modo `verificar-parcial` con los RF afectados) → `sdd-archivist` (modo `registrar-bugfix`).
6. Propón el commit `fix(...)` con el pie `Refs: NNN-nombre`.
