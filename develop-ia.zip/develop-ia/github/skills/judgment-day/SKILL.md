---
name: judgment-day
description: "Juicio dual a ciegas (Judgment Day): dos jueces con modelos de familias distintas revisan en paralelo, sin conocerse, el mismo objetivo congelado; el orquestador cruza los hallazgos (confirmado, sospechoso, contradicción), corrige solo lo confirmado con los subagentes TDD y re-juzga el delta, con un máximo de 2 rondas y veredicto APROBADO o ESCALADO. Incluye el duelo de diseño: dos propuestas independientes para una decisión técnica con alternativas reales. Úsala en la etapa 7 cuando se cumpla un criterio de riesgo o el usuario pida un juicio, y en la etapa 4 para un duelo de diseño."
---

# Juicio dual (Judgment Day)

Un revisor que comparte modelo con quien escribió el código comparte también sus puntos ciegos. El juicio dual pone a **dos jueces de familias de modelos distintas** (`sdd-judge-a` y `sdd-judge-b`, con el modelo fijado en su frontmatter) a revisar lo mismo **a ciegas**, y usa su coincidencia como señal de confianza:

- Lo que encuentran los dos es casi seguro un defecto: se corrige.
- Lo que encuentra uno solo puede ser un acierto o un falso positivo: decide el humano.
- Lo que uno da por defectuoso y el otro por correcto: decide el humano, con los dos argumentos delante.

No sustituye a los tests ni a la verificación: dos modelos también pueden coincidir en un error. Un `APROBADO` del juicio equivale al `APROBADO` de `code-reviewer` y no concede nada más: la verificación de la etapa 8 y el Gate 3 siguen siendo obligatorios.

## Cuándo se usa

### Etapa 7 · Juicio de código (sustituye a la revisión simple, no se suma)

Se activa si se cumple **al menos uno** de estos criterios (umbrales del equipo: ajústalos aquí):

| Criterio | Cómo lo detecta el orquestador |
|---|---|
| Cambio de contrato | `plan.md` declara impacto en consumidores o la spec tiene `contracts/` |
| Seguridad | El plan o las tareas tocan autenticación, autorización, datos personales, secretos o configuración de seguridad |
| Datos | El plan incluye migraciones de esquema o de datos |
| Tamaño | El plan crea o modifica más de 15 archivos de código de producción |
| Incidente | Bugfix de un fallo ocurrido en producción (lo indica el usuario) |
| Petición | El usuario lo pide (`/sdd-juicio`, «juicio», «doble revisión») |

Fuera de estos casos se usa la revisión simple de `code-reviewer`: el juicio duplica el consumo de la revisión y no compensa en cambios pequeños. El usuario puede pedir la revisión simple aunque se cumpla un criterio; el orquestador lo registra como decisión del usuario.

### Etapa 4 · Duelo de diseño (opcional)

Para una decisión técnica concreta (`D-nn`) que cumple el criterio de ADR (afecta a más de una spec o es difícil de revertir) **y** tiene al menos dos alternativas viables con compromisos reales. `sdd-architect` la marca como candidata a duelo y el usuario decide si se hace. Máximo dos duelos por spec.

## Reglas duras

1. **Mismo encargo, a ciegas.** Los dos jueces reciben el **mismo texto literal**. Nunca se pasa el informe de un juez al otro, ni se les dice qué opina el otro juez o el arquitecto.
2. **En paralelo.** El orquestador invoca a los dos jueces en la misma respuesta. Si la plataforma los ejecuta en serie, solo tarda más: la ceguera la garantiza la regla 1.
3. **Objetivo congelado.** Se juzga un commit concreto con el árbol de trabajo limpio. Cada juez lo comprueba (`git status --short` vacío) y devuelve `BLOQUEADO` si no lo está. Los dos informan del mismo `<base>...<sha>`; si difieren, el juicio no es válido y se repite.
4. **Nunca un juicio parcial.** Sin los dos informes válidos no hay juicio. Un juez que falla (sin respuesta, sin cabecera o con el modelo no disponible) se reinvoca **una vez**; si vuelve a fallar, se para y se ofrece al usuario la revisión simple, dejando constancia de que el juicio no pudo hacerse.
5. **Solo el orquestador cruza.** Los jueces no ven la tabla de cruce; en el re-juicio reciben solo los puntos que deben comprobar.
6. **Solo se corrige lo confirmado**, más lo que el usuario decida de sospechosos y contradicciones. Lo `Opcional` es informativo.
7. **Máximo 2 rondas** de corrección y re-juicio. El límite no se reinicia ni se amplía: agotado con confirmados abiertos, el veredicto es `ESCALADO`.
8. **Descorrelación.** Los modelos de los dos jueces, y sus listas de respaldo, son de familias distintas. Si los dos jueces declaran un modelo de la misma familia, el orquestador lo avisa: vale como doble revisión, pero no como juicio dual.

## Protocolo · Juicio de código (etapa 7)

### 1. Preparar el objetivo

- Precondición: todas las tareas en verde y con su commit. Si un juez devuelve `BLOQUEADO` por cambios sin commit, el orquestador pide al usuario los commits pendientes.
- Encargo común (`## Encargo SDD`, modo `juzgar`): spec, rama, rama base, archivos a leer (`spec.md`, `plan.md`, `tasks.md`, `docs/constitution.md`) y los **motivos de riesgo** que activaron el juicio, para que los jueces pongan ahí el foco sin limitarse a ello.

### 2. Juzgar

Los dos jueces, en paralelo y en modo `juzgar`. Cada uno devuelve su informe con el formato de [formatos.md](./references/formatos.md): hallazgos numerados (`A-01`, `B-01`...), cada uno con su evidencia, y las comprobaciones importantes que dio por correctas.

### 3. Cruzar (orquestador)

Dos hallazgos son **el mismo** si señalan el mismo archivo y zona (líneas solapadas o a menos de 5 líneas) **y** el mismo defecto (misma regla incumplida o mismo resultado esperado). Ante la duda, no los unas: trátalos como dos sospechosos.

| Clase | Condición | Qué se hace |
|---|---|---|
| ✅ `CONFIRMADO` | Los dos lo reportan como `BLOQUEANTE` o `MAYOR` | Se corrige. Severidad final: la mayor de las dos |
| 🟠 `SOSPECHOSO-A` / `SOSPECHOSO-B` | Solo un juez lo reporta como `BLOQUEANTE` o `MAYOR` (o el otro lo rebaja a `Opcional`) | El usuario decide: corregir o descartar |
| ⚔️ `CONTRADICCIÓN` | Un juez lo reporta y el otro lo da explícitamente por correcto en sus comprobaciones, o piden correcciones incompatibles | El usuario decide, con los dos argumentos delante |
| ℹ️ `INFO` | `Opcional` de cualquiera de los dos | Se informa; no bloquea |

Los **hallazgos de seguridad** (sección «Decisiones de seguridad pendientes» de cada juez) se cruzan igual, pero **nunca se corrigen automáticamente**, aunque estén confirmados: son decisiones del desarrollador (skill secure-development), y la coincidencia de los dos jueces es un dato más para decidir. Solo si incumplen un RF o CL de seguridad aprobado en la spec se tratan como un hallazgo normal.

El orquestador presenta la **tabla de cruce** ([formatos.md](./references/formatos.md)) y pregunta por cada sospechoso y contradicción **de uno en uno**, con su recomendación, y por las decisiones de seguridad (puede aceptar todas las recomendaciones de una vez).

### 4. Corregir

Una sola lista con los confirmados y lo que el usuario mandó corregir, repartida entre los subagentes dueños:

- Defecto de comportamiento que ningún test detecta: primero `tdd-test-author` (modo `corregir`, con un test que lo reproduce y falla) y después `tdd-implementer` (modo `corregir`). Así la corrección también es TDD.
- Hallazgo sobre tests: `tdd-test-author` (modo `corregir`).
- Resto de hallazgos de código: `tdd-implementer` (modo `corregir`).

Después, el orquestador propone el commit `fix(...)` de las correcciones: el re-juicio necesita un objetivo congelado nuevo.

### 5. Re-juzgar

Los dos jueces, en paralelo y en modo `re-juzgar`, con el mismo encargo literal, que incluye:

- El delta a revisar: `<sha de la ronda anterior>..<sha nuevo>`.
- La lista de puntos corregidos (`J-nn`, archivo:línea, defecto y resultado esperado), **sin** decir qué juez los encontró.

Cada juez dice, punto por punto, `RESUELTO` o `NO RESUELTO`, y reporta los defectos **nuevos que introduce el delta** (no vuelve a revisar todo el diff). El orquestador cruza de nuevo:

- Un punto está resuelto si los dos dicen `RESUELTO`. Si solo uno lo dice, es un sospechoso: decide el usuario.
- Los hallazgos nuevos se clasifican como en el paso 3.

### 6. Veredicto

| Veredicto | Condición |
|---|---|
| `APROBADO` | Ningún confirmado abierto, y todos los sospechosos, contradicciones y decisiones de seguridad decididos por el usuario |
| `ESCALADO` | Confirmados abiertos tras la ronda 2, juicio imposible (regla 4) o el usuario decide parar |

`ESCALADO` detiene el flujo: el orquestador explica qué queda abierto con el historial de rondas, y el usuario decide (corregir a mano y volver a juzgar, replantear el plan o aceptar el riesgo de forma explícita, que se registra como decisión del usuario).

El **informe final de la etapa 7** es la tabla de cruce final con el veredicto. El orquestador la pasa literal a `sdd-archivist`, que la guarda en `review.md`.

## Protocolo · Duelo de diseño (etapa 4)

1. `sdd-architect` (modo `disenar`) entrega el plan con una decisión provisional para cada `D-nn` y lista las **candidatas a duelo** con su planteamiento: pregunta de diseño, contexto, restricciones, RF afectados y criterios de evaluación. El planteamiento **no** incluye la decisión provisional.
2. El orquestador pregunta al usuario si quiere un duelo para alguna candidata, o lo hace directamente si el usuario lo pidió con `/sdd-duelo`.
3. Los dos jueces, en paralelo y en modo `proponer`, reciben el mismo planteamiento literal y los archivos a leer (`spec.md`, `research.md`, `docs/constitution.md`, `AGENTS.md`, `docs/adr/`). Ninguno ve el plan provisional ni la propuesta del otro.
4. El orquestador presenta la comparación: propuesta del juez A, propuesta del juez B y decisión provisional del arquitecto, con los compromisos de cada una y si convergen (si las tres coinciden, es una señal fuerte). Recomienda una, pero **decide el usuario**, que puede elegir una combinación.
5. `sdd-architect` (modo `ajustar`) registra la decisión elegida en el plan y genera el ADR con todas las propuestas en «Alternativas consideradas» y la nota `Decidido por duelo de diseño (AAAA-MM-DD)`.
6. El flujo sigue en la etapa 5. Las propuestas no se implementan: solo informan la decisión.

## Coste y modelos

- Un juicio consume aproximadamente el doble que una revisión simple, más el re-juicio del delta (que es pequeño). Un duelo, dos propuestas por decisión.
- Los modelos de los jueces se fijan con `model:` en `sdd-judge-a.agent.md` y `sdd-judge-b.agent.md`, como lista en orden de preferencia. Elige modelos del mismo nivel de coste que el que el equipo usa con el orquestador: VS Code no ejecuta un subagente cuyo modelo configurado supera el nivel de coste del modelo principal de la conversación. Si un juez no se ejecuta, aplica la regla 4.
