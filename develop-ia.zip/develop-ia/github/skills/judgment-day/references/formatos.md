# Formatos del juicio dual

Los jueces responden con el formato de su modo. El orquestador cruza los informes con la tabla del final. Los IDs de hallazgo de cada juez (`A-nn`, `B-nn`) son locales a su informe; los del cruce (`J-nn`) son estables entre rondas.

## Juez · modo `juzgar`

````markdown
ESTADO: COMPLETADO | BLOQUEADO
VEREDICTO: SIN HALLAZGOS | HALLAZGOS
Juez: A | B · Modelo (autodeclarado): <nombre o «desconocido»>
Objetivo: <base>...<sha corto> · <n> archivos · +<n>/-<n> · Árbol limpio: sí

## Hallazgos
1. A-01 [BLOQUEANTE | MAYOR | Opcional] <archivo>:<línea> — <defecto>
   - Incumple: <Tnn | RF-xx | principio n | convención>
   - Evidencia: <cita literal del código, comando con su salida, o el test concreto que lo demostraría>
   - Se espera: <resultado esperado, no la implementación>
   - Destino: tests | código

## Decisiones de seguridad pendientes (no bloquean)
1. A-05 [ALTA | MEDIA | BAJA] <control o hallazgo> — <archivo>:<línea>
   - Referencia: <CWE-nnn | A0n:2025 | APIn>
   - Evidencia: <cita literal o comando con su salida>
   - Recomendación (<Internet | Interna>): aplicar | opcional — <motivo>

## Comprobaciones sin hallazgo (máx. 10)
- <archivo o aspecto> — <qué comprobaste y por qué es correcto>

## Resumen
- Capas revisadas: conformidad · constitución · corrección · seguridad · tests · mantenibilidad · contratos · stack
- Lint: OK | <n> avisos | no aplica
````

`VEREDICTO: HALLAZGOS` si hay al menos un `BLOQUEANTE` o un `MAYOR`.

## Juez · modo `re-juzgar`

````markdown
ESTADO: COMPLETADO | BLOQUEADO
VEREDICTO: SIN HALLAZGOS | HALLAZGOS
Juez: A | B · Modelo (autodeclarado): <nombre o «desconocido»>
Delta: <sha anterior>..<sha nuevo> · <n> archivos · +<n>/-<n> · Árbol limpio: sí

## Puntos corregidos
| ID | Estado | Evidencia |
|---|---|---|
| J-01 | RESUELTO o NO RESUELTO | <cita del código o comando con su salida> |

## Hallazgos nuevos del delta
1. A-01 [BLOQUEANTE | MAYOR | Opcional] <archivo>:<línea> — <defecto>
   - Incumple: <...>
   - Evidencia: <...>
   - Se espera: <...>
   - Destino: tests | código
````

`VEREDICTO: HALLAZGOS` si algún punto está `NO RESUELTO` o hay algún hallazgo nuevo `BLOQUEANTE` o `MAYOR`.

## Juez · modo `proponer`

````markdown
ESTADO: COMPLETADO | BLOQUEADO
Juez: A | B · Modelo (autodeclarado): <nombre o «desconocido»> · Decisión: D-nn

## Propuesta (máx. 8 líneas)
## Por qué
## Alternativas descartadas
| Alternativa | Motivo |
|---|---|
## Riesgos y coste de revertir
## Impacto en RF, tests y contratos
## Supuestos y preguntas abiertas
````

## Orquestador · tabla de cruce (informe final de la etapa 7)

````markdown
ESTADO: COMPLETADO
VEREDICTO: APROBADO | ESCALADO
Modo: juicio dual · Rondas de corrección: <0-2> · Objetivo final: <base>...<sha>
Motivos del juicio: <criterios de riesgo o «petición del usuario»>
Jueces: A = sdd-judge-a (<modelo autodeclarado>) · B = sdd-judge-b (<modelo autodeclarado>)

## Cruce
| ID | Hallazgo (archivo:línea — defecto) | Juez A | Juez B | Severidad | Clase | Decisión | Estado |
|---|---|---|---|---|---|---|---|
| J-01 | <ruta>:42 — <defecto> | A-01 | B-03 | BLOQUEANTE | CONFIRMADO | Corregir | Resuelto (ronda 1) |
| J-02 | <ruta>:10 — <defecto> | A-02 | — | MAYOR | SOSPECHOSO-A | Descartado por el usuario: «<motivo>» | — |
| J-03 | <ruta>:77 — <defecto> | A-04 | Lo da por correcto | MAYOR | CONTRADICCIÓN | Corregir (decisión del usuario) | Resuelto (ronda 1) |

## Decisiones de seguridad
| ID | Hallazgo (archivo:línea — control) | Juez A | Juez B | Severidad | Decisión del desarrollador |
|---|---|---|---|---|---|
| J-04 | <ruta>:15 — sin límite de página (API4) | A-05 | B-06 | MEDIA | No aplica → DS-02 «solo red interna» |

## Recuento
Confirmados: <n> · Sospechosos: <n> · Contradicciones: <n> · Decisiones de seguridad: <n> · Info: <n>

## Rondas
- Ronda 1: corregidos <J-nn> · re-juicio A: <SIN HALLAZGOS | HALLAZGOS> · B: <SIN HALLAZGOS | HALLAZGOS>
- Ronda 2: <...> | no fue necesaria

## Informativo (no bloquea)
- <opcionales de cualquiera de los dos jueces>
````

## Orquestador · comparación del duelo de diseño

````markdown
## Duelo de diseño · D-nn — <pregunta de diseño>
| Criterio | Juez A | Juez B | Arquitecto (provisional) |
|---|---|---|---|
| Propuesta | <...> | <...> | <...> |
| Ventaja principal | <...> | <...> | <...> |
| Riesgo principal | <...> | <...> | <...> |
| Coste de revertir | <...> | <...> | <...> |
| Impacto en tests y contratos | <...> | <...> | <...> |

Convergencia: <coinciden los tres | coinciden A y B | coinciden A y el arquitecto | ... | no coinciden>
Recomendación: <opción y motivo en 2 líneas>. Decide el usuario.
````
