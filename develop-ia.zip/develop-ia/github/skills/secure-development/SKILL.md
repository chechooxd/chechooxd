---
name: secure-development
description: "Desarrollo seguro en todo el flujo SDD + TDD, basado en estándares abiertos (OWASP Top 10:2025, ASVS 5.0, Proactive Controls 2024, API Security Top 10 2023, CWE Top 25 2025 y NIST SSDF), sin bloquear: recomienda según la exposición (Internet o interna) y el desarrollador decide qué aplicar, con sus decisiones registradas como DS-nn. Incluye sensibilidad, permisos, casos de abuso, modelo de amenazas, tests negativos y verificación de dependencias y secretos. Úsala al especificar, diseñar, probar, revisar o verificar cualquier cambio."
---

# Desarrollo seguro

## Principio: la seguridad informa, el desarrollador decide

Los **controles base** (`security.instructions.md`) se aplican por defecto, pero **ningún control de seguridad detiene el flujo**. Cuando uno no se cumple o añade trabajo, el agente lo señala como **decisión de seguridad pendiente** con su recomendación; el orquestador se la presenta al desarrollador, y este elige:

| Decisión | Qué pasa |
|---|---|
| **Aplicar** | Se convierte en requisito o corrección y se verifica como cualquier otro. |
| **Aceptar el riesgo** | Se registra con su motivo y no se vuelve a preguntar en esta spec. |
| **No aplica** | Se registra con su motivo (por ejemplo, «solo red interna»). |

Lo que el desarrollador decide **aplicar** se cumple: un RF de seguridad aprobado en la spec se verifica como cualquier RF. Lo que decide no aplicar nunca bloquea un gate, una revisión ni una verificación.

### Formato de una decisión pendiente

Los subagentes las devuelven en su respuesta, en una sección `## Decisiones de seguridad pendientes`:

```markdown
- [ALTA | MEDIA | BAJA] <control o hallazgo> — <dónde: RF, archivo:línea o paquete>
  - Referencia: <CWE-nnn | A0n:2025 | APIn>
  - Recomendación (<Internet | Interna>): aplicar | opcional — <motivo en una línea>
  - Si se aplica: <qué hay que hacer y qué agente lo hace>
```

Severidad: **ALTA**, explotable con impacto en datos o accesos; **MEDIA**, defensa en profundidad o exposición limitada; **BAJA**, endurecimiento.

### Registro (`DS-nn`)

En la spec, sección «Seguridad» → «Decisiones de seguridad»:

| ID | Control o hallazgo | Decisión | Motivo | Etapa · fecha |
|---|---|---|---|---|
| DS-01 | Límite de frecuencia del listado (control 3) | No aplica | Solo red interna, unos 20 usuarios | Spec · AAAA-MM-DD |

- Las decisiones de las etapas 2 y 3 las escribe `sdd-spec-writer`. Las del resto, el orquestador las lleva en «Decisiones del usuario» y `sdd-archivist` las registra en la spec al cerrar.
- Una decisión tomada se respeta en todas las etapas: nadie vuelve a proponer ni a añadir ese control en la misma spec.

## Exposición y recomendación

La exposición del proyecto se declara en `AGENTS.md`: **Internet** o **Interna** (solo red corporativa o VPN). Una spec puede indicar otra. La exposición orienta la **recomendación**; no obliga a nada:

| Control base | Internet | Interna |
|---|---|---|
| 1. Sección «Seguridad» de la spec (exposición, sensibilidad, datos, permisos) | Recomendado | Recomendado |
| 1. Casos de abuso y modelo de amenazas (spec Sensible) | Recomendado | Opcional |
| 2. Autorización en el servidor y propiedad del recurso | Recomendado | Recomendado |
| 3. Validación de entradas en el servidor | Recomendado | Recomendado |
| 3. Límites de frecuencia y lista permitida de URLs salientes | Recomendado | Opcional |
| 4. Consultas parametrizadas y salidas codificadas | Recomendado | Recomendado |
| 5. Ningún secreto en el repositorio | Recomendado | Recomendado |
| 6. Criptografía estándar | Recomendado | Recomendado |
| 6. TLS en el tráfico interno | Recomendado | Opcional |
| 7. Identidad con la plataforma | Recomendado | Recomendado |
| 8. Errores sin detalles internos | Recomendado | Recomendado |
| 9. Registro de eventos de seguridad | Recomendado | Opcional |
| 10. CORS restrictivo y cabeceras de seguridad | Recomendado | Opcional |
| 11. Dependencias sin vulnerabilidades altas o críticas | Recomendado | Recomendado |
| Nivel OWASP ASVS 5.0 orientativo | L1 en todo, L2 en lo Sensible | L1 |

- **Recomendado**: el agente propone aplicarlo.
- **Opcional**: el agente lo menciona y propone no aplicarlo, salvo que el desarrollador quiera.
- Los controles sin coste (consultas parametrizadas, sin secretos, errores genéricos, salidas codificadas) se aplican al escribir código sin preguntar, salvo que una `DS-nn` diga lo contrario.

Base normativa y mapa de referencias: [estandares.md](./references/estandares.md).

## Sensibilidad de una spec

Una spec es **Sensible** si cumple al menos uno de estos criterios:

| Criterio | Ejemplos |
|---|---|
| Identidad o permisos | Inicio de sesión, roles, permisos, tokens, delegación |
| Datos personales o confidenciales | Datos de clientes o empleados, contactos, documentos internos |
| Superficie de entrada nueva | Endpoint, formulario, carga de archivos, webhook, importación |
| Destinos externos | Llamadas a terceros, URLs o archivos indicados por el usuario |
| Secretos o criptografía | Claves, certificados, cifrado, firmas |
| Flujo de negocio crítico | Pagos, envíos masivos, cambios irreversibles, acciones que un bot podría automatizar |

Si no cumple ninguno, es **Baja**, con el motivo en una línea. La sensibilidad, junto con la exposición, decide qué se **propone**, no lo que se exige.

## Por etapa

| Etapa | Agente | Qué aporta |
|---|---|---|
| 1 · Exploración | `sdd-explorer` | En «Riesgos»: mecanismo de autenticación y autorización existente, roles, datos sensibles del área y tests de seguridad que ya existen. |
| 2-3 · Spec | `sdd-spec-writer`, `sdd-spec-reviewer` | Sección «Seguridad»: exposición, sensibilidad, datos y permisos. Si es Sensible, propone RF de acceso no autorizado y casos de abuso; el desarrollador elige cuáles entran. Patrones: [requisitos-seguridad.md](./references/requisitos-seguridad.md). |
| Tras el Gate 1 | `sdd-orchestrator` | Si la spec es Sensible, pregunta si el plan incluye modelo de amenazas, con la recomendación según la exposición. |
| 4 · Diseño | `sdd-architect` | Si se decidió, el modelo de amenazas en el §4.5 de `plan.md`: [modelo-amenazas.md](./references/modelo-amenazas.md). Los controles base que el diseño no cubre, como decisiones pendientes. |
| 5 · Tareas | `sdd-task-planner`, `sdd-spec-reviewer` | Cada RF de seguridad, caso de abuso y mitigación aprobados tiene su tarea y su test previsto. |
| 6 · TDD | `tdd-test-author` | Tests negativos de lo aprobado: [tests-seguridad.md](./references/tests-seguridad.md). |
| 7 · Revisión | `code-reviewer` o juicio dual | Hallazgos de seguridad en su propia sección: no cambian el veredicto, son decisiones pendientes. |
| 8 · Verificación | `sdd-verifier` | Dependencias, secretos y mitigaciones, como decisiones pendientes (sección siguiente). |
| 9 · Cierre | `sdd-archivist` | Registra en la spec las `DS-nn` tomadas durante el flujo. |

## Verificación de seguridad (etapa 8)

1. **Dependencias.** Frontend: `npm audit --omit=dev --audit-level=high`. Backend: `dotnet list package --vulnerable --include-transitive` (`dotnet restore` también avisa con `NU1903` y `NU1904` si la auditoría de NuGet está activa).
   - Vulnerabilidad alta o crítica en un paquete **añadido o actualizado por esta spec** (compara el manifiesto y el archivo de bloqueo con la rama base): decisión pendiente, con la recomendación de actualizarlo o sustituirlo.
   - Las preexistentes se informan como **riesgo heredado**, solo a título informativo.
2. **Secretos en el diff.** Con el escáner del proyecto, si lo tiene. Si no, revisa `git diff <base>...HEAD` en busca de claves privadas (`-----BEGIN`), cadenas de conexión con contraseña, tokens y valores literales asignados a nombres como `password`, `secret`, `apikey` o `token`. Si aparece uno: decisión pendiente, con la recomendación de retirarlo y rotarlo, porque lo que entra en git queda en su historial.
3. **Mitigaciones.** Si hay modelo de amenazas, la mitigación de una amenaza `AM-nn` sin evidencia (test en verde o comprobación) es una decisión pendiente.
4. **Lo aprobado.** Los RF de seguridad y los casos de abuso de la spec se verifican como cualquier RF o CL, y estos sí cuentan para el veredicto, porque el desarrollador los aprobó.

Los puntos 1 a 3 no cambian el veredicto: el orquestador los presenta al desarrollador antes del Gate 3.

## Cuándo preguntar

- Un requisito o una decisión de diseño choca con un control base: decisión pendiente con su recomendación. Nunca `BLOQUEADO` por un control de seguridad.
- El mecanismo de autenticación o autorización no está documentado ni se deduce del código: pregunta `EXT-nn` (el desarrollador decide si es bloqueante).
- Una dependencia nueva no supera las comprobaciones del control 11: decisión pendiente al pedir su aprobación.
