# Modelo de amenazas (§4.5 del plan)

Se hace cuando el desarrollador lo decide tras el Gate 1: recomendado si la spec es Sensible y se expone a Internet; opcional si es interna. Es **ligero**: cabe en una pantalla y responde a las cuatro preguntas clásicas del modelado de amenazas: ¿qué estamos construyendo?, ¿qué puede salir mal?, ¿qué vamos a hacer al respecto?, ¿lo hemos hecho bien?

## 1. Qué estamos construyendo

- **Activos**: los datos y las operaciones que valen algo para un atacante.
- **Fronteras de confianza**: los puntos donde los datos pasan de un nivel de confianza a otro (navegador → API, API → base de datos, API → tercero, archivo subido → almacenamiento).

## 2. Qué puede salir mal: STRIDE por frontera

| Letra | Amenaza | Propiedad que rompe | Pregunta |
|---|---|---|---|
| S | Suplantación | Autenticación | ¿Puede alguien hacerse pasar por otro usuario o servicio? |
| T | Manipulación | Integridad | ¿Puede alterar datos en tránsito, en la petición o ya guardados? |
| R | Repudio | Trazabilidad | ¿Puede negar haber hecho algo sin que podamos demostrarlo? |
| I | Divulgación de información | Confidencialidad | ¿Puede ver datos que no le corresponden, también en errores y logs? |
| D | Denegación de servicio | Disponibilidad | ¿Puede agotar recursos con volumen o con peticiones costosas? |
| E | Elevación de privilegios | Autorización | ¿Puede hacer algo reservado a otro rol? |

## 3. Plantilla

````markdown
### 4.5 Seguridad y modelo de amenazas
Sensibilidad: Sensible (<criterio>) · Nivel ASVS objetivo: L2

**Activos:** <...>
**Fronteras de confianza:** <...>

| ID | Frontera | STRIDE | Amenaza (escenario concreto) | Mitigación | Verificación |
|---|---|---|---|---|---|
| AM-01 | Navegador → API | E | Un operador llama directamente a la programación de envíos | Autorización por rol en la operación | RF-08 · test `RF-08: ...` |
| AM-02 | API → BD | I | Un operador lee notificaciones de otro cambiando el ID | Consulta filtrada por propietario | CL-07 (Abuso) |

**Riesgos aceptados:** <AM-nn → DS-nn> | ninguno
````

## 4. Reglas

- Cada amenaza es un **escenario concreto** de esta spec, no una categoría genérica copiada.
- Cada mitigación apunta a un RF, CL o RNF con su test, o a una comprobación manual con pasos exactos. Si una mitigación necesita un requisito que la spec no tiene, es un hallazgo: vuelve a la spec (los cambios entran por arriba).
- Aceptar un riesgo es una decisión del desarrollador (`DS-nn`): la amenaza queda listada, sin mitigación, y no bloquea nada.
- Prefiere los mecanismos de seguridad del framework (políticas de autorización, validación, protección CSRF, codificación de salida) a soluciones propias.
- Si no se hace modelo de amenazas, el §4.5 tiene una sola línea: `Sin modelo de amenazas: <sensibilidad baja: motivo | decisión DS-nn>`.
