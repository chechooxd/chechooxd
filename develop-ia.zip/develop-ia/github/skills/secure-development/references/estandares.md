# Base normativa de seguridad

Estándares abiertos, independientes de cualquier proveedor o empresa, y lo que toma el kit de cada uno. Revisa las versiones una vez al año: cuando salga una edición nueva, actualiza esta tabla y las referencias de las instrucciones.

| Estándar | Versión | Qué es | Qué toma el kit |
|---|---|---|---|
| OWASP Top 10 | 2025 | Los 10 riesgos más críticos de las aplicaciones web | Prioridades de la revisión y del modelo de amenazas |
| OWASP ASVS | 5.0 (mayo de 2025) | Requisitos de seguridad verificables, en tres niveles acumulativos (L1, L2, L3) | Nivel orientativo (L1; L2 en lo Sensible expuesto a Internet) y capítulos de referencia |
| OWASP Top 10 Proactive Controls | 2024 | Los 10 controles que todo desarrollador debe aplicar | Base de los controles de código |
| OWASP API Security Top 10 | 2023 | Riesgos propios de las APIs | Revisión y tests del backend |
| CWE Top 25 (MITRE) | 2025 | Las debilidades de software más peligrosas | Identificador preciso de cada defecto |
| NIST SSDF (SP 800-218) | 1.1 (la 1.2 está en borrador) | Prácticas de desarrollo seguro en todo el ciclo de vida | La seguridad repartida por las etapas del flujo |
| STRIDE | — | Clasificación de amenazas | Modelo de amenazas del plan |

## OWASP Top 10:2025

A01 Broken Access Control · A02 Security Misconfiguration · A03 Software Supply Chain Failures · A04 Cryptographic Failures · A05 Injection · A06 Insecure Design · A07 Authentication Failures · A08 Software or Data Integrity Failures · A09 Security Logging and Alerting Failures · A10 Mishandling of Exceptional Conditions.

## OWASP Top 10 Proactive Controls 2024

C1 Implement Access Control · C2 Use Cryptography to Protect Data · C3 Validate all Input & Handle Exceptions · C4 Address Security from the Start · C5 Secure By Default Configurations · C6 Keep your Components Secure · C7 Secure Digital Identities · C8 Leverage Browser Security Features · C9 Implement Security Logging and Monitoring · C10 Stop Server Side Request Forgery.

## OWASP ASVS 5.0: capítulos

V1 Encoding and Sanitization · V2 Validation and Business Logic · V3 Web Frontend Security · V4 API and Web Service · V5 File Handling · V6 Authentication · V7 Session Management · V8 Authorization · V9 Self-contained Tokens · V10 OAuth and OIDC · V11 Cryptography · V12 Secure Communication · V13 Configuration · V14 Data Protection · V15 Secure Coding and Architecture · V16 Security Logging and Error Handling · V17 WebRTC.

## OWASP API Security Top 10 2023

API1 Broken Object Level Authorization · API2 Broken Authentication · API3 Broken Object Property Level Authorization · API4 Unrestricted Resource Consumption · API5 Broken Function Level Authorization · API6 Unrestricted Access to Sensitive Business Flows · API7 Server Side Request Forgery · API8 Security Misconfiguration · API9 Improper Inventory Management · API10 Unsafe Consumption of APIs.

## Controles base → referencias

La tabla relaciona cada control base con las referencias que lo sustentan; no reproduce los mapeos oficiales entre CWE y Top 10.

| # | Control base | Top 10:2025 | Proactive 2024 | ASVS 5.0 | API Top 10 | CWE Top 25 2025 |
|---|---|---|---|---|---|---|
| 1 | La seguridad empieza en la spec | A06 | C4 | — | — | — |
| 2 | Acceso denegado por defecto y mínimo privilegio | A01 | C1 | V8 | API1, API3, API5 | 862, 863, 284, 639 |
| 3 | Toda entrada externa es hostil | A05, A01 (SSRF) | C3, C10 | V2, V5 | API4, API6, API7, API10 | 20, 434, 770, 918 |
| 4 | Datos y código nunca se mezclan | A05, A08 | C3 | V1 | — | 79, 89, 78, 77, 94, 22, 502 |
| 5 | Ningún secreto en el repositorio | A04, A07 | C2 | V13 | — | (CWE-798, fuera del Top 25) |
| 6 | Criptografía estándar, nunca propia | A04 | C2 | V11, V12 | — | — |
| 7 | Identidad con la plataforma | A07 | C7 | V6, V7, V9, V10 | API2 | 306, 352 |
| 8 | Los errores fallan cerrado y no revelan nada | A10 | C3 | V16 | — | 200 |
| 9 | Eventos de seguridad registrados, sin datos sensibles | A09 | C9 | V14, V16 | — | 200 |
| 10 | Configuración segura por defecto | A02 | C5, C8 | V3, V13 | API8 | — |
| 11 | Dependencias aprobadas, reales y sin vulnerabilidades | A03 | C6 | V15 | — | — |

## Cómo citar

En hallazgos, amenazas y requisitos, cita la referencia más precisa que conozcas: `CWE-639` para el acceso a un recurso ajeno por su ID, `A01:2025` para la categoría o un requisito ASVS con el formato `v5.0.0-<capítulo>.<sección>.<requisito>` si sabes cuál es. No inventes números de requisito.
