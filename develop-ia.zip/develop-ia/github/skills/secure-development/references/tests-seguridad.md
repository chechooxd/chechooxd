# Tests de seguridad (TDD)

Los RF de seguridad y los casos de abuso que el desarrollador aprobó en la spec se prueban como cualquier RF: el test se escribe primero, falla por la razón esperada y lleva su identificador. Un test de seguridad afirma **dos cosas**: que la operación se rechaza y que no ha tenido efecto (no se ha leído, cambiado ni filtrado nada).

## Qué probar

| Categoría | Test mínimo | Nivel habitual |
|---|---|---|
| Sin autenticar | Llamada sin credenciales → rechazada | Integración de API |
| Sin permiso | Usuario con un rol insuficiente → rechazada y sin cambios en los datos | Integración de API |
| Recurso ajeno | El usuario A pide o modifica un recurso de B → «no existe» o rechazado; el recurso de B no cambia | Integración de API o unitario del Handler |
| Propiedades | Petición con campos no permitidos (propietario, estado) → ignorados o rechazados; la respuesta no incluye campos internos | Unitario e integración |
| Entradas | Límites exactos (`n` y `n+1`), formatos inválidos, contenido con `<script>`, `'; --` o `../` → rechazado o tratado como texto | Unitario |
| Volumen | Página mayor que el máximo → limitada o rechazada | Unitario o integración |
| Errores | Excepción interna → respuesta genérica, sin trazas ni SQL | Integración de API |

## .NET (NUnit y WebApplicationFactory)

```csharp
[Test]
[Category("RF-09")]
[Description("RF-09: un operador no puede ver la notificación de otro operador")]
public async Task ObtenerNotificacion_DeOtroOperador_RespondeNoEncontrado()
{
    // CrearClienteComo: utilidad de test del proyecto que autentica como un usuario de prueba.
    using var cliente = _fabrica.CrearClienteComo(UsuariosDePrueba.OperadorA);

    var respuesta = await cliente.GetAsync($"/api/notificaciones/{IdNotificacionDeOperadorB}");

    Assert.That(respuesta.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
}
```

- La identidad del usuario de prueba se simula con el mecanismo que ya use el proyecto (por ejemplo, un esquema de autenticación de test registrado en la `WebApplicationFactory`). Si no existe, crearlo es una tarea del plan, no algo que improvise el test.
- La autorización se prueba **en la API** (integración), porque es ahí donde se configura; el test del Handler no basta.

## Angular (Jasmine)

- Las guardas de ruta y los botones ocultos son experiencia de usuario: se prueban, pero **nunca sustituyen** al test del backend.
- Contenido externo mostrado en una plantilla: el test comprueba que `<script>` o `<img onerror>` aparecen como texto, no como HTML.
- Interceptor de autenticación: el test comprueba que el token solo se envía a la API propia, nunca a otros dominios.
