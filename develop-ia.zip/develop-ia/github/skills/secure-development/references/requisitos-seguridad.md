# Requisitos de seguridad en la spec

La sección «Seguridad» de la spec dice **qué** debe proteger el sistema, sin el cómo: nada de JWT, políticas, filtros ni roles de base de datos (eso va al plan).

## 1. Exposición y sensibilidad

- **Exposición**: `Internet` o `Interna` (solo red corporativa o VPN). Por defecto, la del proyecto en `AGENTS.md`.
- **Sensibilidad**: `Sensible` o `Baja`. Si es Sensible, el criterio que la hace sensible (skill secure-development); si es Baja, el motivo en una línea.

Las dos orientan qué se propone; nada de esta sección se impone al desarrollador.

## 2. Datos

| Dato | Clasificación | Notas |
|---|---|---|
| <dato> | público · interno · confidencial · personal | <quién lo ve, enmascarado, retención> |

## 3. Permisos (denegado por defecto)

Una fila por operación y una columna por actor, **incluido el anónimo**. Lo que no aparece está denegado.

| Operación | Gestor | Operador | Anónimo |
|---|---|---|---|
| Ver notificaciones | ✅ todas | ✅ solo las suyas | ❌ |
| Programar un envío | ✅ | ❌ | ❌ |

Cada restricción de **propiedad** («solo las suyas») se propone como RF y, si la spec es Sensible, como caso de abuso.

## 4. RF de seguridad (patrones EARS)

| Situación | Patrón |
|---|---|
| Sin autenticar | `SI un usuario no autenticado intenta <operación>, ENTONCES EL SISTEMA la rechaza sin devolver datos.` |
| Sin permiso | `SI un usuario sin permiso para <operación> la intenta, ENTONCES EL SISTEMA la rechaza e informa de que no tiene permiso.` |
| Recurso ajeno | `SI un usuario intenta acceder a <recurso> de otro <propietario>, ENTONCES EL SISTEMA responde como si el recurso no existiera.` |
| Campos no permitidos | `SI la petición incluye <campo que el usuario no puede fijar>, ENTONCES EL SISTEMA lo ignora (o la rechaza).` |
| Límite de entrada | `SI <campo> supera <n> caracteres o no cumple <formato>, ENTONCES EL SISTEMA rechaza la petición e indica el campo.` |
| Límite de volumen | `SI un usuario supera <n> <operaciones> en <periodo>, ENTONCES EL SISTEMA rechaza las siguientes hasta <condición>.` |
| Registro | `CUANDO se deniega <operación>, EL SISTEMA registra quién, cuándo y qué operación, sin datos personales del recurso.` |

## 5. Casos de abuso (se proponen si es Sensible)

Propón los de las categorías que aplican; **el desarrollador decide cuáles entran**. Los que entran van en la tabla de casos límite con el prefijo «Abuso:» y se prueban como cualquier `CL`; los descartados se registran como `DS-nn`. Piensa como alguien con una cuenta válida que quiere ir más allá:

| Categoría | Pregunta | Referencia |
|---|---|---|
| Recurso ajeno | ¿Qué pasa si cambio el ID de la URL o del cuerpo? | API1 · CWE-639 |
| Función ajena | ¿Puedo llamar directamente a la operación de otro rol? | API5 · CWE-862 |
| Propiedades | ¿Puedo enviar campos que no debería fijar (propietario, estado, rol)? ¿Recibo campos que no debería ver? | API3 |
| Volumen | ¿Y si lo repito mil veces o pido 100 000 registros de golpe? | API4, API6 · CWE-770 |
| Contenido | ¿Y si el texto lleva HTML, un script, SQL o rutas como `../`? | CWE-79, CWE-89, CWE-22 |
| Archivos | ¿Y si subo un ejecutable con la extensión cambiada o un archivo enorme? | CWE-434 |
| Destinos | ¿Y si la URL que indico apunta a la red interna? | API7 · CWE-918 |

Ejemplo: `| CL-07 | Abuso: un operador pide la notificación de otro operador cambiando su ID | Se responde como si no existiera y el intento queda registrado | RF-09 |`

## 6. Decisiones de seguridad

Lo que el desarrollador decide no aplicar (o aceptar como riesgo) se registra en la misma sección de la spec, con el formato `DS-nn` de la skill secure-development. Ejemplo: `| DS-01 | Casos de abuso de volumen (API4) | No aplica | Herramienta interna con unos 20 usuarios | Spec · AAAA-MM-DD |`.
