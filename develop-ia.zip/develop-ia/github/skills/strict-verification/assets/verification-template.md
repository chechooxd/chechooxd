# Verificación NNN — <Nombre>

> **Fecha:** AAAA-MM-DD · **Rama:** <rama> · **Commit:** <hash corto> · **Spec:** v<versión> · **Verificador:** sdd-verifier

**VEREDICTO: <CUMPLE | CUMPLE CON PENDIENTES MANUALES | NO CUMPLE>**

## Ejecución
- Suite: `<comando>` → salida <n> · <n> pasando · <n> fallando · <n> omitidos
- Build: `<comando>` → <OK | FALLA>
- Lint: `<comando>` → <OK | n errores>

## Matriz de verificación
| RF | Evidencia | Resultado |
|---|---|---|
| RF-01 | `<archivo>` › `RF-01: ...` | ✅ CUMPLE |

## Casos límite
| CL | Test | Resultado |
|---|---|---|

## Requisitos no funcionales
| RNF | Evidencia | Resultado |
|---|---|---|

## Criterios de finalización
- [x] <criterio> — <evidencia>

## Seguridad
- Exposición: <Internet | Interna> · Sensibilidad: <Sensible | Baja>
- Dependencias: `<comando>` → <sin vulnerabilidades altas o críticas introducidas | paquete@versión (severidad, CVE)> · Riesgo heredado: <ninguno | lista>
- Secretos en el diff: <ninguno | archivo:línea>
- Mitigaciones: AM-01 ✅ <test> · AM-02 ✅ <test> | sin modelo de amenazas
- Decisiones de seguridad tomadas: <DS-nn → decisión> | ninguna (no cambian el veredicto)

## Constitución
- Principio n — ✅ <cómo>

## Pendientes manuales
- [ ] <paso exacto> — Responsable: <humano>

## Historial de verificaciones
| Vuelta | Fecha | Veredicto | Incumplimientos |
|---|---|---|---|
| 1 | AAAA-MM-DD | NO CUMPLE | RF-03 |
| 2 | AAAA-MM-DD | CUMPLE | — |
