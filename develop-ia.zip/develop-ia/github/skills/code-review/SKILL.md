---
name: code-review
description: "Revisión de código del diff completo de una spec: conformidad con tareas y plan, constitución, corrección, seguridad, calidad real de los tests, mantenibilidad y rendimiento, con severidades y un informe accionable con archivo y línea. Úsala al revisar cambios antes de verificar o de abrir un PR."
---

# Revisión de código

Revisa como un buen revisor de PR: **señal alta, ruido bajo**. Cada hallazgo bloqueante debe poder corregirse sin preguntar nada más.

## Obtener el cambio

```bash
git diff --stat <base>...HEAD     # alcance
git diff <base>...HEAD            # cambios de la rama
git diff && git status --short    # cambios sin commit
```

## Capas de revisión (en este orden)

### 1. Conformidad con la spec, el plan y las tareas
- [ ] Cada archivo cambiado corresponde a una tarea de `tasks.md`.
- [ ] No falta ninguna tarea marcada como hecha.
- [ ] Nada fuera de alcance: ni funcionalidades extra, ni refactors no pedidos de código ajeno.
- [ ] Las decisiones del plan se respetan (o se justifican en la evidencia).

### 2. Constitución y convenciones
- [ ] Ningún principio de `docs/constitution.md` incumplido.
- [ ] Se siguen las instrucciones del stack (`.github/instructions/`) y los patrones de referencia.
- [ ] Sin dependencias nuevas no aprobadas.

### 3. Corrección
- [ ] Lógica correcta para los RF; casos límite de la spec tratados.
- [ ] Errores manejados según los RF `SI ... ENTONCES` (sin `catch` vacíos ni errores tragados).
- [ ] Nulos e indefinidos, colecciones vacías, límites numéricos.
- [ ] Fechas y zonas horarias; dinero y redondeos; concurrencia y condiciones de carrera.
- [ ] Recursos liberados y suscripciones cerradas (`dispose`, `unsubscribe`, `takeUntilDestroyed`, `using`).

### 4. Seguridad
Los controles base de `security.instructions.md` y la lista completa, ordenada por el OWASP Top 10:2025: [security-checklist.md](./references/security-checklist.md). Los hallazgos de esta capa **no bloquean**: van a «Decisiones de seguridad pendientes» con su recomendación según la exposición, salvo que incumplan un RF o CL de seguridad aprobado en la spec (entonces es `BLOQUEANTE`, como cualquier RF). No repitas lo ya decidido en las `DS-nn` de la spec. Mínimo:
- [ ] Autorización en el servidor en cada operación, incluida la propiedad del recurso (nadie accede a lo ajeno cambiando un ID).
- [ ] Entradas validadas en el servidor y con límites; salidas codificadas; consultas parametrizadas.
- [ ] Ningún secreto en el código, los tests o la configuración versionada; nada sensible en logs ni en errores.
- [ ] Dependencias nuevas aprobadas, reales y sin vulnerabilidades conocidas.
- [ ] Si hay modelo de amenazas: cada mitigación implementada; cada caso de abuso aprobado, con su test.

### 5. Calidad de los tests
- [ ] Ningún test existente se ha modificado para pasar, omitido ni debilitado (revisa el diff de los archivos de test con atención).
- [ ] Los tests nuevos prueban comportamiento, son deterministas y llevan el RF en el nombre.
- [ ] Cada RF y CL de las tareas tiene su test.
- [ ] Sin `.only`, `fdescribe`, `skip`, `[Ignore]`, `[Explicit]`, `Assert.Ignore()` ni tests vacíos.

### 6. Mantenibilidad y rendimiento
- [ ] Nombres claros; funciones pequeñas; sin duplicación significativa.
- [ ] Complejidad razonable (sin anidamientos profundos ni condicionales gigantes).
- [ ] Sin trabajo innecesario: N+1, bucles con E/S, recálculos en cada render o detección de cambios.
- [ ] Código muerto, comentarios obsoletos y `console.log` o `Debug.WriteLine` de depuración eliminados.
- [ ] **Sin sobreingeniería** ([simplicity.instructions.md](../../instructions/simplicity.instructions.md)): cada pieza nueva del diff (archivo, interfaz, clase, capa, parámetro, opción de configuración, dependencia o patrón) responde a un RF, un RNF, una convención del proyecto o una decisión `D-nn` del plan. Si no, `MAYOR`, con «Se espera: eliminarla o integrarla en lo existente». Es tan grave como el código desordenado.

### 7. Contratos e impacto en consumidores
- [ ] Ningún endpoint o contrato existente cambia de forma (campos, códigos de error, paginación, ruta, verbo, parámetros) sin estar marcado en el plan como cambio aprobado. Si cambia, el hallazgo indica **a quién afecta** para comunicarlo antes del cierre.
- [ ] Nada se implementa sobre una pregunta `EXT` abierta.

### Listas por stack
- .NET: [dotnet-review.md](./references/dotnet-review.md)
- Angular: [angular-review.md](./references/angular-review.md)

## Severidades

| Severidad | Criterio |
|---|---|
| `BLOQUEANTE` | Bug probable, incumplimiento de la spec (incluidos sus RF de seguridad aprobados) o de la constitución, test debilitado. |
| `MAYOR` | Problema de mantenibilidad o rendimiento con impacto real, convención importante incumplida, caso límite sin tratar. |
| Opcional | Sugerencia de mejora. No bloquea y va en su propia sección. |
| Seguridad (`ALTA`, `MEDIA`, `BAJA`) | Control base de seguridad sin cumplir (skill secure-development). No bloquea: es una decisión pendiente del desarrollador y va en su propia sección. |

## Informe

Usa el formato definido en el agente `code-reviewer`. Para cada hallazgo: `archivo:línea`, problema, regla incumplida, resultado esperado y destino (`tests` o `código`).
