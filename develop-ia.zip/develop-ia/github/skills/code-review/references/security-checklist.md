# Lista de comprobación de seguridad

Ordenada por el OWASP Top 10:2025, con las referencias del OWASP API Security Top 10 2023 y del CWE Top 25 2025. Aplica los apartados que correspondan al diff. Cada incumplimiento es una **decisión de seguridad pendiente** (`ALTA`, `MEDIA` o `BAJA`, con la recomendación según la exposición del proyecto) y no bloquea; solo es `BLOQUEANTE` si incumple un RF o CL de seguridad aprobado en la spec. No repitas lo que la spec ya decidió en sus `DS-nn`. Cita la referencia más precisa (por ejemplo, `CWE-639`).

## A01 · Control de acceso
- [ ] Cada operación nueva o modificada comprueba la autorización en el servidor, denegando por defecto (CWE-862, CWE-863).
- [ ] El acceso a un recurso por su ID comprueba que pertenece al usuario o a su ámbito (API1 · CWE-639).
- [ ] Las operaciones de un rol no son invocables por otro rol llamándolas directamente (API5).
- [ ] El usuario no puede fijar campos que no le corresponden (propietario, estado, rol) ni recibe campos que no debe ver (API3).
- [ ] Las guardas de ruta y los elementos ocultos del frontend tienen su control equivalente en el backend.
- [ ] Sin peticiones salientes a URLs controladas por el usuario fuera de una lista permitida (SSRF · API7 · CWE-918).
- [ ] Cookies de sesión con protección CSRF (CWE-352).

## A02 · Configuración
- [ ] CORS restrictivo; nunca cualquier origen junto con credenciales.
- [ ] Sin modo depuración, páginas de error detalladas ni cuentas o claves por defecto fuera del entorno local.
- [ ] Cabeceras de seguridad no relajadas (CSP, HSTS, `X-Content-Type-Options`); HTTPS en el tráfico expuesto.

## A03 · Cadena de suministro
- [ ] Dependencias nuevas aprobadas, existentes en el registro oficial con ese nombre exacto, mantenidas y sin vulnerabilidades altas o críticas (`npm audit`, `dotnet list package --vulnerable`).
- [ ] Archivo de bloqueo actualizado y coherente con el manifiesto.

## A04 · Criptografía y secretos
- [ ] Sin secretos, claves, tokens ni cadenas de conexión en código, tests, configuración versionada o documentación (CWE-798).
- [ ] Sin criptografía propia ni algoritmos obsoletos (MD5 o SHA-1 para contraseñas, DES, ECB); contraseñas con hash adaptativo.

## A05 · Inyección
- [ ] SQL parametrizado u ORM; nunca entradas concatenadas o interpoladas en consultas (CWE-89).
- [ ] Sin ejecución de comandos ni `eval` con datos externos (CWE-78, CWE-77, CWE-94).
- [ ] Salidas codificadas según su contexto; sin HTML construido con datos externos (CWE-79).
- [ ] Rutas de archivo que no se construyen con datos del usuario (CWE-22).

## A06 · Diseño
- [ ] Si hay modelo de amenazas, cada mitigación del plan está implementada.
- [ ] Límites de tamaño, de página y de frecuencia en las entradas (API4, API6 · CWE-770).

## A07 · Autenticación
- [ ] Autenticación con el mecanismo de la plataforma; tokens validados (firma, emisor, audiencia y caducidad) (CWE-306).
- [ ] Sin endpoints sensibles anónimos que no estén justificados en el plan.

## A08 · Integridad de software y datos
- [ ] Sin deserialización de tipos arbitrarios ni de datos no confiables sin validar (CWE-502).
- [ ] Archivos subidos validados por contenido, tamaño y nombre (CWE-434).

## A09 · Registro y alertas
- [ ] Accesos denegados, fallos de autenticación y cambios de permisos registrados.
- [ ] Sin datos personales, tokens ni contraseñas en logs, mensajes de error o analítica (CWE-200).

## A10 · Condiciones excepcionales
- [ ] Ante un error, la operación se deniega y no deja cambios a medias (falla cerrado).
- [ ] Errores devueltos sin detalles internos: trazas, SQL, rutas o versiones (CWE-200).

## Tests de seguridad
- [ ] Cada RF de seguridad y cada caso de abuso aprobados en la spec tiene su test, y el test afirma la denegación y la ausencia de efecto.
