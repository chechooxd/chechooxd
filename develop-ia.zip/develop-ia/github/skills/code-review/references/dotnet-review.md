# Revisión .NET 10 (API): comprobaciones específicas

Complementa la lista general de la skill. Severidad entre corchetes.

## Fronteras de capas (lo más importante)
- [BLOQUEANTE] Salto de capa: un Controller que llama directamente a un Repository, o un Repository con lógica de caso de uso.
- [MAYOR] Handler con acceso a datos que corresponde al Repository, o con formateo HTTP que corresponde al Controller.
- [MAYOR] Interfaces nuevas sin registrar en `Program.cs` (`AddScoped`).
- [MAYOR] Nomenclatura por entidad inconsistente (`XController`, `IXHandler`/`XHandler`, `IXRepository`/`XRepository`).

## Contrato y DTOs
- [BLOQUEANTE] Una consulta que devuelve una entidad de dominio en lugar de un DTO de `Models/DTO`.
- [BLOQUEANTE] Respuesta que no va envuelta en `ResponseData<T>`, o endpoint paginado sin `ResponseMeta`.
- [BLOQUEANTE] Cambio en la forma de un endpoint existente (campos de `Data`, `ResponseMeta`, `ResponseError`, ruta, verbo o parámetros obligatorios) **no marcado** en el plan como cambio de contrato aprobado.

## Errores
- [BLOQUEANTE] Handler o Repository que captura excepciones para formatear errores a mano: deben propagarse al middleware que produce `ResponseError`.

## Seguridad (API)
Decisiones de seguridad pendientes (no bloquean); la severidad orienta la recomendación según la exposición.
- [ALTA] Endpoint nuevo sin autorización explícita (política o rol) que no esté justificado como anónimo en el plan (CWE-862).
- [ALTA] Acceso a un recurso por su ID sin comprobar que pertenece al usuario o a su ámbito: la consulta debe filtrar por propietario, no solo por ID (API1 · CWE-639).
- [ALTA] Binding de entrada a una entidad, o DTO de entrada con campos que el usuario no puede fijar (`Id`, propietario, estado, rol) (API3).
- [ALTA] SQL con datos interpolados o concatenados (`FromSqlRaw` o `ExecuteSqlRaw` con `$"..."` o `+`); usa `FromSql` o parámetros (CWE-89).
- [ALTA] Deserialización de tipos arbitrarios (`TypeNameHandling` distinto de `None`, `BinaryFormatter`) (CWE-502).
- [ALTA] Subida de archivos sin validar contenido, tamaño y nombre, o ruta construida con el nombre que envía el usuario (CWE-434, CWE-22).
- [ALTA] Respuesta de error con trazas, SQL o detalles internos (CWE-200).
- [MEDIA] Validación de JWT relajada (`ValidateIssuer`, `ValidateAudience` o `ValidateLifetime` a `false`; `RequireHttpsMetadata = false` fuera de desarrollo) (CWE-306).
- [MEDIA] CORS con `AllowAnyOrigin` junto a credenciales, o abierto sin justificación en el plan.
- [MEDIA] Sin límite de tamaño de página o de petición en endpoints de listado o carga (API4 · CWE-770).
- [MEDIA] `HttpClient` hacia URLs construidas con datos del usuario sin lista permitida (API7 · CWE-918).
- [MEDIA] Denegaciones o cambios de permisos sin registrar, o logs con datos personales o tokens.
- [MEDIA] Criptografía propia o algoritmos obsoletos; contraseñas sin el hash adaptativo de la plataforma.

## EF Core
- [BLOQUEANTE] Lectura sin `.AsNoTracking()` (o `.AsNoTrackingWithIdentityResolution()`).
- [BLOQUEANTE] Uso de `.Include()` o `.ThenInclude()`: debe ser una proyección `.Select()` al DTO.
- [MAYOR] Métodos sin `CancellationToken` en la firma o sin propagarlo; `.Result`, `.Wait()` o `async void`.
- [MAYOR] Consultas que traen columnas innecesarias o N+1.

## Diseño y estilo
- [MAYOR] Handler que cubre más de un caso de uso o más de una entidad; dependencias concretas instanciadas en lugar de interfaces; DI sin constructores primarios.
- [MAYOR] Sobreingeniería (instrucción de diseño simple). Señales en .NET, salvo que las exija una convención del proyecto o una decisión del plan:
  - Interfaces nuevas con una sola implementación fuera de las que pide la convención (`IXHandler`, `IXRepository`).
  - Repositorios o servicios genéricos (`IRepository<T>`, `BaseService<T>`) que el proyecto no usa.
  - Librerías de infraestructura nuevas para algo que la plataforma o el proyecto ya resuelven (mediador, *mappers* automáticos, validación).
  - Envoltorios `Result<T>` o jerarquías de excepciones propias cuando el proyecto usa excepciones y middleware.
  - `IOptions<T>` o parámetros para valores que ningún RF pide configurar.
  - Métodos de extensión, *helpers* o clases base con un solo uso.
- [Opcional] Nombres de método sin intención (`GetAsync`), anidamiento profundo, números o cadenas mágicas.
- [MAYOR] Idioma de nombres, comentarios o logs distinto del que fija la constitución.

## Tests
- [BLOQUEANTE] Tests de Handler que usan la base de datos real o un repositorio concreto en lugar de un doble del `IRepository`.
- [MAYOR] Sin tests de los casos de error de la spec (qué `ResponseError` y cuándo).
- [MAYOR] Tests que pasan trivialmente (el doble devuelve exactamente lo que se afirma, sin lógica de por medio).
- [MAYOR] Test de comportamiento sin `[Category("RF-nn")]`, o con una `Category` que no coincide con el identificador de su `[Description]`.
- [MAYOR] Estado compartido entre tests: SUT o dobles creados en inicializadores de campo o en el constructor (NUnit reutiliza la instancia de la clase) sin `[FixtureLifeCycle(LifeCycle.InstancePerTestCase)]`.
- [MAYOR] Tests `async void`.
- [Opcional] Asserts clásicos (`ClassicAssert`) en tests nuevos en lugar de `Assert.That`.
