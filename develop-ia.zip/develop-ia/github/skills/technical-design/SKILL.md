---
name: technical-design
description: "Diseño técnico (plan.md) de una spec aprobada: archivos y responsabilidades, lógica pura testeable, decisiones justificadas con su alternativa descartada, contratos de API entre repositorios, estrategia de tests por RF, verificación de la constitución, riesgos y trazabilidad. Incluye plantillas de plan y ADR. Úsala en la etapa de diseño o al ajustar un plan."
---

# Diseño técnico

El plan responde al **CÓMO** de una spec aprobada. Debe ser lo bastante concreto para que el planificador de tareas y el implementador no tengan que tomar decisiones de diseño, y lo bastante breve para revisarlo en 10 minutos.

## Principios de diseño

1. **Reutiliza antes de crear.** Parte de los patrones y archivos de referencia de `research.md`. Un patrón nuevo necesita una decisión justificada.
2. **Testeable por diseño.** Separa la lógica pura (cálculos, reglas, transformaciones) de la E/S (HTTP, almacenamiento, DOM, reloj, aleatoriedad). Lo no determinista se inyecta o se pasa como parámetro (`now`, `today`, `idGenerator`).
3. **El cambio mínimo que cubre todos los RF.** Nada de generalizar «por si acaso»: aplica la prueba rápida y las reglas de [simplicity.instructions.md](../../instructions/simplicity.instructions.md). Cada pieza nueva (interfaz, clase base, genérico, patrón, capa, opción de configuración o dependencia) va en «Piezas nuevas» del §3 con el RF, RNF o convención que la exige; si nada la exige, no va.
4. **Decisiones explícitas.** Cada decisión no obvia tiene su alternativa descartada y el motivo. Si afecta a más de una spec o es difícil de revertir, genera un ADR en `docs/adr/NNNN-titulo.md`.
5. **Compatibilidad.** Si cambian datos persistidos o contratos, describe la migración y la compatibilidad hacia atrás.
6. **Sin dependencias nuevas por defecto.** Si son imprescindibles, se justifican, superan las comprobaciones del control de dependencias (existen en el registro oficial con ese nombre, están mantenidas y no tienen vulnerabilidades altas o críticas) y quedan marcadas para la aprobación del usuario.
7. **Seguro por diseño, sin bloquear.** Aplica los controles base de seguridad por defecto y, si el usuario lo decidió tras el Gate 1, el modelo de amenazas del §4.5 con la skill [secure-development](../secure-development/SKILL.md). Respeta las decisiones `DS-nn` de la spec. Lo que el diseño no cubra se devuelve como decisión de seguridad pendiente, nunca como bloqueo. Prefiere los mecanismos de seguridad del framework a soluciones propias.

## Estrategia de tests por RF

Es la sección más importante para el TDD. Para cada RF, indica:

| Nivel | Cuándo |
|---|---|
| Unitario | Lógica pura, reglas, validaciones, transformaciones. Por defecto. |
| Integración | Colaboración con frameworks, almacenamiento, HTTP (con dobles o servidores de prueba), componentes con plantilla. |
| E2E | Solo para el flujo crítico principal, si el proyecto tiene infraestructura e2e. |
| Manual | Lo que no se puede automatizar de forma razonable (visual, dispositivo real). Debe incluir pasos exactos. |

Indica también los **dobles** (stub, fake, mock) y qué se sustituye. Prefiere fakes y stubs a mocks con verificación de llamadas.

## Contratos entre repositorios

Si la spec implica una API o una integración entre repositorios (por ejemplo, frontend y backend), sigue [contracts.md](./references/contracts.md). El contrato es la **fuente de verdad**: el plan de cada repositorio lo referencia; ninguno lo reinterpreta.

## Preguntas a otros equipos (`EXT-nn`)

Lo que no puede decidir este repositorio (contrato real del backend, límites de un servicio, permisos) **nunca se infiere**: se registra en la sección 9 del plan como `EXT-nn` con estos campos:

| Campo | Contenido |
|---|---|
| Estado | `abierta` · `respondida` · `descartada` |
| Categoría | `contrato` · `errores` · `auth` · `paginación` · `rendimiento` · `otra` |
| Pregunta | Precisa y accionable |
| Por qué | Qué decisión del diseño depende de la respuesta |
| Detalle necesario | Qué nivel de respuesta basta para resolverla |
| Bloqueante | sí / no |
| Respuesta | Quién respondió, cuándo y qué (al cerrarla) |

Reglas:
- Antes de crear una pregunta, busca en las specs del repositorio si ya existe: reutiliza su ID si sigue abierta y usa su respuesta si ya se respondió.
- Una decisión que depende de una `EXT` abierta se marca como **provisional** citando su ID.
- **El plan no puede aprobarse con una `EXT` bloqueante abierta**, y la verificación falla si queda alguna abierta al cerrar la spec.

## Listas por stack

- Angular: [angular-design.md](./references/angular-design.md) (dónde vive el estado, fronteras y testabilidad).
- .NET: [dotnet-design.md](./references/dotnet-design.md) (capas, DTOs, impacto de contrato y estrategia de consulta).

## Plantillas

- Plan: [plan-template.md](./assets/plan-template.md)
- ADR: [adr-template.md](./assets/adr-template.md)
