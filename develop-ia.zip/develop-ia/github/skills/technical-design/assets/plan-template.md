# Plan NNN — <Nombre>

> **Estado:** Borrador · **Spec:** [spec.md](./spec.md) v<versión> · **Fecha:** AAAA-MM-DD

## 1. Resumen
<3 a 5 líneas: enfoque general y por qué.>

## 2. Verificación de la constitución
| Principio | Cumplimiento |
|---|---|
| 1. <nombre> | ✅ <cómo lo cumple el plan> |

## 3. Archivos y responsabilidades
| Acción | Ruta | Responsabilidad | RF |
|---|---|---|---|
| Crear | `ruta/archivo.ext` | <qué hace> | RF-01, RF-02 |
| Modificar | `ruta/existente.ext` | <qué cambia> | RF-03 |

Patrones de referencia: `<ruta>` (de research.md).

Piezas nuevas (interfaces, clases base, genéricos, patrones, capas, opciones de configuración, dependencias): ninguna | <pieza> — <RF, RNF o convención que la exige>

## 4. Diseño

### 4.1 Modelo de datos y contratos
<Tipos, entidades, cambios de esquema y compatibilidad. Enlaza a `contracts/` si aplica.>

### 4.2 Lógica (funciones puras)
| Función o método | Entrada → salida | RF |
|---|---|---|
| `nombreFuncion(entrada, now)` | <...> → <...> | RF-01 |

Algoritmo (pseudocódigo, solo si no es trivial):
```text
<pseudocódigo>
```

### 4.3 Integración y E/S
<Servicios, HTTP, almacenamiento, eventos. Cómo se manejan los errores (RF de tipo SI ... ENTONCES).>

### 4.4 Interfaz
<Componentes, estados de la vista (cargando, vacío, error, éxito), accesibilidad. RF cubiertos.>

### 4.5 Seguridad y modelo de amenazas
<Si el usuario decidió hacerlo: modelo de amenazas con la plantilla de la skill secure-development (activos, fronteras de confianza, tabla AM-nn con mitigación y verificación, riesgos aceptados como DS-nn). Si no: «Sin modelo de amenazas: <sensibilidad baja: motivo | decisión DS-nn>». Respeta las decisiones DS-nn de la spec.>

## 5. Decisiones técnicas
| ID | Decisión | Alternativa descartada | Motivo |
|---|---|---|---|
| D-01 | <...> | <...> | <...> |

ADR generados: <`docs/adr/NNNN-...`> | ninguno

## 6. Estrategia de tests
| RF / CL | Nivel | Qué se prueba | Dobles |
|---|---|---|---|
| RF-01 | Unitario | <comportamiento> | `FakeClock` |
| CL-01 | Unitario | <caso límite> | — |
| RF-05 | Manual | <pasos exactos> | — |

Comandos: `<test>` · `<lint>` · `<build>` (de AGENTS.md)

## 7. Riesgos y mitigaciones
- <riesgo> → <mitigación>

## 8. Dependencias nuevas (requieren aprobación)
- (ninguna) | <paquete@versión> — <justificación>

## 9. Preguntas a otros equipos
<!-- Nunca inferir lo que pertenece a otro repositorio o equipo. Una decisión que dependa de una EXT abierta es provisional. -->
### EXT-01
- Estado: abierta
- Categoría: contrato | errores | auth | paginación | rendimiento | otra
- Dirigida a: <equipo o repositorio>
- Pregunta: <precisa y accionable>
- Por qué: <qué decisión de este plan depende de la respuesta>
- Detalle necesario: <qué nivel de respuesta basta para resolverla>
- Bloqueante: sí | no
- Respuesta: <quién, cuándo y qué> | —

## 10. Impacto en consumidores
<Cambios de contrato que afectan a otros repositorios (campos, códigos de error, paginación, rutas): versión, compatibilidad y a quién comunicarlo. «Ninguno» si no aplica.>

## 11. Cobertura
RF-01 §4.2 · RF-02 §4.3 · ... (todos los RF de la spec)
