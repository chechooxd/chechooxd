# Comandos de test por stack

> Los comandos oficiales del proyecto están en `AGENTS.md` y mandan sobre esta tabla. Esto es una referencia para los casos habituales.

## Angular (Karma + Jasmine)

| Objetivo | Comando |
|---|---|
| Suite completa, una vez | `npm run test -- --watch=false` |
| Navegador sin interfaz (CI) | `npm run test -- --watch=false --browsers=ChromeHeadless` |
| Solo un archivo (RED) | `npm run test -- --watch=false --include='src/app/ruta/archivo.spec.ts'` |
| Con cobertura | `npm run test -- --watch=false --code-coverage` |
| Lint / build | `npm run lint` · `npm run build` |

Notas: nunca ejecutes en modo watch desde un agente (el proceso no termina). Los nombres de los tests están en `it('RF-nn: ...')`.

## Angular (Vitest, si el proyecto lo usa)

| Objetivo | Comando |
|---|---|
| Suite completa | `npx vitest run` |
| Solo un archivo | `npx vitest run src/app/ruta/archivo.spec.ts` |
| Por nombre | `npx vitest run -t "RF-03"` |

## .NET (NUnit)

| Objetivo | Comando |
|---|---|
| Suite completa | `dotnet test` |
| Sin recompilar | `dotnet test --no-build` |
| Por RF o CL | `dotnet test --filter "TestCategory=RF-03"` |
| Por clase | `dotnet test --filter "FullyQualifiedName~Namespace.ClaseTests"` |
| Por método | `dotnet test --filter "Name~Metodo_Escenario"` |
| Detalle de cada test (evidencia) | `dotnet test --logger "console;verbosity=normal"` |
| Con cobertura | `dotnet test --collect:"XPlat Code Coverage"` (requiere `coverlet.collector`) |
| Build / formato (solo comprobar) | `dotnet build -warnaserror` · `dotnet format --verify-no-changes` |

Notas:
- La trazabilidad va en `[Category("RF-03")]`, que se filtra con `TestCategory`. Usa `=` (coincidencia exacta): `~` significa «contiene» y haría coincidir `RF-03` con `RF-030`.
- Varios RF a la vez: `dotnet test --filter "TestCategory=RF-03|TestCategory=RF-04"` (siempre entre comillas, por el `|`).
- Un filtro que no ejecuta ningún test no es un verde: comprueba el total ejecutado, no solo el código de salida.
- En el resumen, los tests con `[Ignore]` o `Assert.Ignore()` cuentan como **omitidos**, y los `Inconclusive` tampoco cuentan como pasados: la evidencia GREEN exige `0 omitidos`.
- Si el repositorio usa el **NUnit runner** sobre Microsoft.Testing.Platform (`<EnableNUnitRunner>true</EnableNUnitRunner>`), el filtro mantiene la sintaxis, pero `coverlet.collector` no es compatible (usa `Microsoft.Testing.Extensions.CodeCoverage`) y los argumentos propios de VSTest, como `--logger` o `--collect`, cambian: confirma los comandos en `AGENTS.md`.

## Node.js (runner nativo)

| Objetivo | Comando |
|---|---|
| Suite completa | `node --test` |
| Por nombre | `node --test --test-name-pattern="RF-03"` |

## Interpretación del código de salida

- `0`: todos los tests ejecutados pasan.
- Distinto de `0`: hay fallos **o** un error de ejecución. Lee la salida para distinguirlo: un error de compilación o de configuración no es un RED válido salvo que el símbolo que falta sea la API nueva de la tarea.
