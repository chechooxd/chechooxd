---
name: tdd-cycle
description: "Ciclo TDD estricto RED, GREEN y REFACTOR por tarea: criterios de un RED válido, código mínimo, refactor en verde, diseño de tests deterministas con el RF en el nombre, política de dobles, antipatrones y formato obligatorio de la evidencia en tasks.md. Úsala siempre que escribas tests o implementes una tarea."
---

# Ciclo TDD

```text
RED ──────────────► GREEN ───────────────► REFACTOR
tdd-test-author      tdd-implementer         tdd-implementer
test nuevo falla     código mínimo, pasa     limpia, suite en verde
por la razón         + suite completa
esperada             en verde
```

## RED (tdd-test-author)

1. Escribe los tests de **una** tarea, a partir de sus RF y casos límite.
2. Ejecuta **solo los tests nuevos** y captura la salida.
3. El RED es **válido** si:
   - fallan los tests nuevos, y solo ellos;
   - fallan por **la razón esperada**: una aserción sobre el comportamiento, o un símbolo inexistente que es exactamente la API nueva que define el plan (clase, función o método aún no creados).
4. El RED **no es válido** si falla por un error de configuración, una errata, una importación mal escrita, un entorno roto o si falla un test que ya existía.
5. Si un test nuevo **pasa** sin código nuevo, el comportamiento ya existe o el test no prueba lo que dice: revísalo antes de seguir.

## GREEN (tdd-implementer)

1. Escribe el **código mínimo** que hace pasar los tests RED. No anticipes tareas futuras.
2. Ejecuta los tests de la tarea y después la **suite completa**.
3. **Prohibido** tocar los tests para que pasen. Si un test parece incorrecto, se para y se devuelve a `tdd-test-author` con la explicación.

## REFACTOR (tdd-implementer)

1. Con todo en verde: elimina duplicación, mejora nombres, extrae funciones y simplifica condiciones.
2. Sin cambiar el comportamiento ni la API pública que usan los tests.
3. Vuelve a ejecutar la suite completa. Si algo se rompe, deshaz el último paso del refactor.
4. **Simplifica, no generalices**: nada de interfaces, clases base, parámetros ni utilidades que el plan no incluye (instrucción de diseño simple).

## Diseño de tests

- **Nombre** = identificador + comportamiento: `RF-03: rechaza la programación si la fecha es pasada`. Así el verificador mapea RF → test sin heurísticas. En .NET (NUnit), el identificador va en `[Category("RF-03")]` y la frase en `[Description]` (perfil .NET).
- **Estructura** Arrange / Act / Assert (o Dado / Cuando / Entonces). Una razón para fallar por test.
- **Prueba comportamiento, no implementación**: afirma sobre salidas, estado observable o llamadas a fronteras externas, no sobre detalles internos.
- **Deterministas**: sin reloj real (inyecta `now` o usa un reloj falso), sin red real, sin aleatoriedad sin semilla, sin depender del orden de ejecución ni de la zona horaria de la máquina.
- **Independientes**: cada test prepara sus propios datos y no deja estado compartido.
- **Datos explícitos**: los valores que importan para el caso se ven en el test; el resto, con constructores o *builders* de datos.

### Dobles de prueba

| Doble | Úsalo para |
|---|---|
| Stub | Devolver respuestas fijas (repositorio, HTTP) |
| Fake | Implementación ligera en memoria (repositorio en memoria, reloj falso) |
| Mock con verificación | Solo cuando el comportamiento **es** la llamada (enviar un correo, publicar un evento) |

No hagas mock de lo que es tuyo y puro: pruébalo de verdad.

### Antipatrones prohibidos

- Tests sin aserciones o con aserciones triviales (`expect(true).toBe(true)`).
- `skip`, `xit`, `fdescribe`, `.only`, `[Ignore]`, `[Explicit]`, `Assert.Ignore()` o `Assert.Inconclusive()` en el código entregado.
- Ajustar el valor esperado a lo que devuelve el código («snapshot a ciegas»).
- Capturar excepciones en el test para que no falle.
- Tests que dependen de la fecha de hoy, del orden o de datos de otro test.

## Evidencia (obligatoria en tasks.md)

En la tarea correspondiente, sustituye `_pendiente_` por:

```markdown
  - Evidencia RED: ✔ AAAA-MM-DD · `<comando>` · salida 1 · 3 nuevos fallando (aserción) · 0 existentes afectados
  - Evidencia GREEN: ✔ AAAA-MM-DD · `<comando suite completa>` · salida 0 · 128 pasando, 0 fallando, 0 omitidos · refactor: <qué o «ninguno»>
```

Y en la respuesta al orquestador, incluye un extracto de la salida real (20 líneas como máximo). **Sin evidencia, la fase no está hecha.**

## Comandos por stack

Los comandos oficiales del proyecto están en `AGENTS.md`. Referencia por stack: [test-commands.md](./references/test-commands.md).
