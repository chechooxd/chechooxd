---
name: spec-quality-review
description: "Revisión de calidad de specs como un QA senior y análisis de consistencia entre spec, plan, tareas y constitución: listas de comprobación, severidades (BLOQUEANTE, MAYOR, MENOR) y formato del informe. Solo detecta, no corrige. Úsala en la clarificación de una spec o antes de aprobar un plan y sus tareas."
---

# Revisión de calidad de specs

Tu objetivo es encontrar **lo que hará fallar la implementación o la verificación**, no pulir la redacción. Cada hallazgo se plantea como una decisión que el usuario puede tomar.

## Severidades

| Severidad | Criterio | Efecto |
|---|---|---|
| `BLOQUEANTE` | Impide implementar o verificar: contradicción, RF no verificable, conflicto con la constitución, RF sin cobertura en plan o tareas. | Hay que resolverlo antes del gate. |
| `MAYOR` | Probable defecto o retrabajo: caso límite relevante sin cubrir, término ambiguo con impacto, error sin su `SI ... ENTONCES`. | Hay que resolverlo antes del gate. |
| `MENOR` | Mejora la claridad sin cambiar el comportamiento. | Se informa; no bloquea. |
| `DECISIÓN` | Punto de seguridad: un control base que la spec o el plan no cubren (skill secure-development). | No bloquea: el desarrollador decide aplicar, aceptar el riesgo o que no aplica, y queda registrado como `DS-nn`. |

No reportes preferencias de estilo.

## Modo `spec`: lista de comprobación

**Ambigüedad**
- [ ] ¿Algún RF usa adjetivos sin medida («rápido», «fácil», «adecuado», «reciente»)?
- [ ] ¿Algún término admite dos lecturas y no está en «Definiciones»?
- [ ] ¿Algún RF tiene «etc.», «y/o», «entre otros» o «cuando sea posible»?

**Contradicciones**
- [ ] ¿Dos RF dan respuestas distintas al mismo evento o estado?
- [ ] ¿Algún RF contradice «Fuera de alcance», un caso límite o una spec aprobada?

**Completitud**
- [ ] ¿Cada RF de evento tiene sus RF de error (`SI ... ENTONCES`)? Entradas vacías, inválidas, duplicadas, fuera de rango, sin permisos, fallos externos.
- [ ] ¿Están cubiertos los casos límite típicos (vacíos, límites, concurrencia, fechas, datos heredados)?
- [ ] ¿Cada HU tiene al menos un RF? ¿Cada RF pertenece a una HU?
- [ ] ¿Hay criterios de finalización comprobables?

**Testabilidad**
- [ ] ¿Cada RF tiene un resultado observable que un test o una comprobación pueda afirmar?
- [ ] ¿Los RNF tienen número, unidad y condición de medida?

**Forma**
- [ ] ¿La spec contiene el CÓMO (tecnologías, archivos, endpoints)? Eso es un hallazgo `MAYOR`.
- [ ] ¿Quedan `[NECESITA ACLARACIÓN]`? Cada uno es un hallazgo `BLOQUEANTE`.

**Seguridad** (skill secure-development; cada hallazgo es una `DECISIÓN` con su recomendación según la exposición, y no se repite lo ya decidido en «Decisiones de seguridad»)
- [ ] ¿Existe la sección «Seguridad», con la exposición y una sensibilidad coherente con los criterios (por ejemplo, datos personales → Sensible)?
- [ ] ¿Cada operación de la spec tiene su fila en la matriz de permisos, incluido el anónimo?
- [ ] ¿Cada restricción de propiedad («solo las suyas») tiene su RF?
- [ ] ¿Las entradas tienen límites (longitud, formato, volumen)?
- [ ] Si es Sensible: ¿hay casos de abuso de las categorías que aplican (recurso ajeno, función ajena, propiedades, volumen, contenido, archivos, destinos)?
- [ ] ¿Algún requisito choca con un control base de seguridad?

**Constitución**
- [ ] ¿Algún RF obliga a incumplir un principio? (`BLOQUEANTE`)

## Modo `consistencia`: análisis entre artefactos

- [ ] **Cobertura**: cada RF aparece en al menos una sección del plan y en al menos una tarea, con un test previsto.
- [ ] **Huérfanos**: ninguna tarea ni sección del plan sin RF (alcance no pedido).
- [ ] **Simplicidad**: cada pieza nueva del plan («Piezas nuevas» del §3) tiene el RF, RNF o convención que la exige (`MAYOR` si no); ninguna tarea prepara infraestructura genérica que ningún RF usa.
- [ ] **Casos límite**: cada `CL-nn` tiene un test previsto en alguna tarea.
- [ ] **Constitución**: la tabla de cumplimiento del plan es correcta y completa.
- [ ] **Terminología**: los mismos conceptos se llaman igual en la spec, el plan, las tareas y los contratos.
- [ ] **Orden**: ninguna tarea depende de otra posterior.
- [ ] **Tipo de tarea**: las tareas `sin-test` están justificadas y no ocultan lógica.
- [ ] **Contratos**: los tipos y campos de `contracts/` coinciden con lo que usan el plan y las tareas.
- [ ] **Preguntas EXT**: no queda ninguna bloqueante abierta.
- [ ] **Seguridad** (`DECISIÓN`): si se decidió hacer modelo de amenazas, cada amenaza `AM-nn` tiene mitigación o una `DS-nn` que acepta el riesgo, y cada mitigación tiene RF o CL con tarea y test previsto.

## Formato del informe

```markdown
ESTADO: COMPLETADO
VEREDICTO: SIN BLOQUEANTES | REQUIERE CORRECCIONES
Modo: spec | consistencia · Hallazgos: B=<n> M=<n> m=<n> · Decisiones de seguridad: <n>

## Hallazgos
1. [MAYOR] [Completitud] RF-02
   - Problema: «EL SISTEMA guarda el borrador» no define qué ocurre si el asunto supera 200 caracteres.
   - Por qué importa: el implementador decidirá un comportamiento no acordado y no habrá test para él.
   - Decisión necesaria: ¿se trunca, se rechaza con mensaje o se permite cualquier longitud?
```

`VEREDICTO: REQUIERE CORRECCIONES` si hay al menos un `BLOQUEANTE` o `MAYOR`. Las `DECISIÓN` van en la sección `## Decisiones de seguridad pendientes`, con el formato de la skill secure-development, y no cambian el veredicto. En modo `consistencia`, añade la tabla de cobertura RF → plan → tareas → test previsto.
