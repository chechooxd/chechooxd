---
name: sdd-closure
description: "Cierre de una spec implementada: precondiciones, persistencia de los informes de revisión y verificación, estados finales, actualización de MEMORY.md y CHANGELOG, descripción del pull request y commit de cierre. Úsala en la etapa de cierre o al registrar un bugfix."
---

# Cierre de una spec

El cierre deja la spec **trazable de punta a punta**: alguien que llegue dentro de seis meses debe entender qué se pidió, qué se decidió, qué se hizo y cómo se comprobó, sin leer el chat.

## Precondiciones (si falta alguna, `BLOQUEADO`)

- [ ] Todas las tareas `[x]`, con evidencia RED (las de tipo TDD) y GREEN.
- [ ] Revisión de código (simple o juicio dual) con `VEREDICTO: APROBADO`.
- [ ] Verificación con `VEREDICTO: CUMPLE` o `CUMPLE CON PENDIENTES MANUALES`.

## Pasos

1. **Informes**: crea `specs/NNN/review.md` y `specs/NNN/verification.md`. Cabecera con la fecha, la rama y el commit (`git rev-parse --short HEAD`), y el informe literal debajo. En `verification.md` usa la plantilla de la skill strict-verification.
2. **Estados**: `spec.md` → `Implementada` (actualiza la fecha); `plan.md` → `Implementado`. Añade una línea al «Historial de cambios» de la spec y registra las decisiones de seguridad `DS-nn` del encargo en su sección «Seguridad».
3. **Memoria**: actualiza `MEMORY.md` según la skill [project-memory](../project-memory/SKILL.md).
4. **CHANGELOG**: si existe `CHANGELOG.md`, añade la entrada en `## [Sin publicar]` con el formato *Keep a Changelog* (`Añadido`, `Cambiado`, `Corregido`, `Eliminado`), en lenguaje de usuario y con el enlace a la spec.
5. **PR**: redacta la descripción con [pr-template.md](./assets/pr-template.md).
6. **Commit de cierre**: propón `docs(sdd): cierra NNN-nombre` con el pie `Refs: NNN-nombre`.

## Registro de un bugfix

- En la spec afectada, «Historial de cambios»: `vX.Y+1 | fecha | Corrección: <bug> | RF-nn`. No cambies el estado de la spec.
- En `MEMORY.md`, «Aprendizajes y errores a evitar», si el bug enseña algo reutilizable.

## Commits (modo commit)

Solo con `Autorización del usuario: sí` en el encargo:

```bash
git add <archivos listados en el encargo>   # nunca "git add ." a ciegas
git commit -m "<asunto>" -m "<cuerpo>" -m "Refs: NNN-nombre"
git log -1 --stat                           # evidencia
```

Prohibido: `push`, `--amend`, `rebase`, `reset`, `--no-verify`.
