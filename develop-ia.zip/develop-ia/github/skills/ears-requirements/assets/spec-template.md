# Spec NNN — <Nombre de la funcionalidad>

> **Estado:** Borrador · **Versión:** 0.1 · **Última actualización:** AAAA-MM-DD · **Rama:** <rama>

<!-- Esta spec describe el QUÉ y el POR QUÉ. Nada de stack, arquitectura ni nombres de archivos: eso va en plan.md. -->

## Contexto y objetivo
<Qué problema resuelve y por qué merece la pena. Un párrafo. Incluye la métrica de éxito si la hay.>

## Usuarios y actores
- <Rol>: <qué necesita>

## Historias de usuario
- **HU-01**: Como <rol>, quiero <acción> para <beneficio>.

## Definiciones
<Solo términos que admitan más de una lectura.>
- **<Término>**: <definición precisa>

## Requisitos funcionales

### HU-01 — <título>
- **RF-01**: CUANDO <evento>, EL SISTEMA <respuesta observable>.
- **RF-02**: SI <condición no deseada>, ENTONCES EL SISTEMA <respuesta>.
- **RF-03**: MIENTRAS <estado>, EL SISTEMA <respuesta>.
- **RF-04**: EL SISTEMA <comportamiento permanente>.

## Requisitos no funcionales
<Solo los que apliquen y siempre medibles: rendimiento, seguridad, accesibilidad, compatibilidad, idioma.>
- **RNF-01**: <requisito medible>

## Seguridad
<!-- Qué se protege, sin el CÓMO. Criterios, recomendaciones y patrones: skill secure-development. Nada de esta sección bloquea: lo que no se aplica se registra como decisión. -->
- **Exposición:** Internet | Interna — <la de AGENTS.md, u otra con su motivo>
- **Sensibilidad:** Sensible | Baja — <criterio que la hace sensible, o motivo de que no lo sea>
- **Datos:**

| Dato | Clasificación | Notas |
|---|---|---|
| <dato> | público · interno · confidencial · personal | <quién lo ve, enmascarado, retención> |

- **Permisos** (lo que no aparece está denegado):

| Operación | <Rol A> | <Rol B> | Anónimo |
|---|---|---|---|
| <operación> | ✅ | ✅ solo las suyas | ❌ |

Los RF de seguridad van en «Requisitos funcionales». Los casos de abuso que se decidan incluir (se proponen si la spec es Sensible) van en «Casos límite» con el prefijo «Abuso:».

- **Decisiones de seguridad** (lo que el desarrollador decide no aplicar o acepta como riesgo):

| ID | Control o hallazgo | Decisión | Motivo | Etapa · fecha |
|---|---|---|---|---|
| DS-01 | <control o hallazgo> | No aplica · Aceptar el riesgo | <motivo> | <etapa> · AAAA-MM-DD |

## Casos límite
| ID | Situación | Comportamiento esperado | RF |
|---|---|---|---|
| CL-01 | <vacío, duplicado, límite, concurrencia, datos corruptos...> | <resultado> | RF-nn |

## Fuera de alcance
<Lo que explícitamente NO se hace en esta versión.>
- <...>

## Supuestos y dependencias
- <supuesto o dependencia de otro equipo o sistema>

## Criterios de finalización
- [ ] Todos los RF con tests en verde (o verificación manual aceptada).
- [ ] <demo o comprobación del flujo principal>

## Clarificaciones
<!-- Registro de decisiones tomadas durante la clarificación. -->
### Sesión AAAA-MM-DD
- P: <pregunta> → R: <decisión del usuario> (afecta a RF-nn)

## Dudas abiertas
- [NECESITA ACLARACIÓN] <duda>

## Historial de cambios
| Versión | Fecha | Cambio | RF afectados |
|---|---|---|---|
| 0.1 | AAAA-MM-DD | Borrador inicial | — |
