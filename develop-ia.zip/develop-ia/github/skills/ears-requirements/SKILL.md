---
name: ears-requirements
description: "Redacción de especificaciones (spec.md) con requisitos verificables en notación EARS en español: patrones CUANDO, SI-ENTONCES, MIENTRAS y DONDE, reglas de verificabilidad, antipatrones, técnica de entrevista para eliminar ambigüedades y plantilla de spec. Úsala al escribir, corregir o cambiar una spec."
---

# Requisitos en EARS

EARS (*Easy Approach to Requirements Syntax*) usa plantillas fijas para que cada requisito sea **inequívoco y verificable**. Funciona muy bien con IA porque:

- Cada requisito se convierte casi directamente en un test (`RF-nn: ...`).
- El patrón `SI ... ENTONCES` obliga a pensar en los errores, justo lo que la IA suele olvidar.
- Una frase es un comportamiento: no hay párrafos que interpretar.

## Patrones

| Patrón | Plantilla | Uso |
|---|---|---|
| Ubicuo | `EL SISTEMA <respuesta>.` | Comportamiento permanente |
| Evento | `CUANDO <evento>, EL SISTEMA <respuesta>.` | Respuesta a una acción o suceso |
| No deseado | `SI <condición no deseada>, ENTONCES EL SISTEMA <respuesta>.` | Errores, entradas inválidas, fallos |
| Estado | `MIENTRAS <estado>, EL SISTEMA <respuesta>.` | Comportamiento que dura mientras se da una condición |
| Opcional | `DONDE <característica o configuración>, EL SISTEMA <respuesta>.` | Variantes por configuración, rol o plataforma |
| Compuesto | `MIENTRAS <estado>, CUANDO <evento>, EL SISTEMA <respuesta>.` | Combinaciones (con moderación) |

La `<respuesta>` describe un **resultado observable**: qué ve el usuario, qué devuelve la API, qué queda guardado. En presente: «EL SISTEMA muestra...», «EL SISTEMA rechaza...».

## Reglas de un buen RF

1. **Verificable**: alguien puede escribir un test o una comprobación con un resultado de sí o no.
2. **Medible**: nada de «rápido», «intuitivo», «bonito», «adecuado» o «etc.». Usa números, límites, formatos y mensajes concretos.
3. **Atómico**: un comportamiento por RF. Si hay un «y» que une dos respuestas, divídelo.
4. **Sin el CÓMO**: ni tecnologías, ni componentes, ni endpoints, ni tablas.
5. **Completo en errores**: por cada RF de evento, piensa qué pasa con una entrada vacía, inválida, duplicada, fuera de rango, sin permisos, sin red o con un fallo del servidor.
6. **Términos definidos**: si una palabra admite varias lecturas («activo», «reciente», «día»), defínela en «Definiciones».

### Antipatrones

| ❌ Ambiguo | ✅ Verificable |
|---|---|
| El sistema debe ser rápido al buscar. | `RNF-01`: CUANDO el usuario busca, EL SISTEMA muestra los resultados en menos de 500 ms (p95) con 10 000 registros. |
| El sistema valida el formulario. | `RF-04`: SI el campo «Asunto» está vacío al guardar, ENTONCES EL SISTEMA no guarda y muestra «El asunto es obligatorio» bajo el campo. |
| El usuario puede filtrar y exportar. | `RF-05` (filtrar) y `RF-06` (exportar), por separado. |
| Mostrar las notificaciones recientes. | Definición: «reciente» = creada en los últimos 7 días naturales, en la zona horaria del usuario. |

## Técnica de entrevista

Antes de redactar, elimina ambigüedades preguntando:

1. **Como máximo 5 preguntas por ronda**, ordenadas por impacto: alcance → errores → casos límite → datos → experiencia de uso.
2. **Cerradas y con opciones** (A/B/C), con una **recomendada** y su motivo en una línea. El usuario decide más rápido entre opciones que ante una pregunta abierta.
3. **No preguntes** lo que responden el código, `research.md` o la constitución.
4. Lo que quede sin respuesta se marca `[NECESITA ACLARACIÓN: ...]`. No inventes.

Lista de comprobación de huecos típicos: estados vacíos · límites (mínimo y máximo, longitud) · duplicados · permisos y roles · concurrencia (dos usuarios a la vez) · fechas (zona horaria, cambio de hora, fin de mes) · paginación · datos corruptos o heredados · fallos de red o del servidor · accesibilidad · idioma y formatos (moneda, decimales).

## Seguridad

Toda spec incluye la sección «Seguridad»: exposición, sensibilidad, datos y matriz de permisos (lo que no aparece está denegado). Si es Sensible, se proponen casos de abuso como `CL` con el prefijo «Abuso:», y el desarrollador decide cuáles entran; lo que decide no aplicar queda en «Decisiones de seguridad» (`DS-nn`). Nada de la sección bloquea. Patrones EARS de seguridad y catálogo de casos de abuso: skill [secure-development](../secure-development/SKILL.md).

## Plantilla y ejemplo

- Plantilla: [spec-template.md](./assets/spec-template.md)
- Ejemplo completo: [example-spec.md](./references/example-spec.md)
