# Constitución — <Nombre del proyecto>

> **Estado:** Propuesta · **Versión:** 0.1.0 · **Fecha:** AAAA-MM-DD

Principios innegociables. Toda spec, plan, tarea y cambio de código debe cumplirlos. Un incumplimiento es un hallazgo bloqueante.

1. **<Nombre>**: <regla verificable>. <Porqué, si no es obvio>.
2. **La spec manda**: nada se implementa si no está en una spec aprobada. Si falta una decisión, se para y se pregunta.
3. **<Arquitectura>**: <límite que no se cruza>.
4. **Tests como puerta**: TDD obligatorio para todo comportamiento; prohibido avanzar con tests en rojo, omitidos o debilitados.
5. **Seguridad**: los controles base de seguridad del kit (`.github/instructions/security.instructions.md`) se aplican por defecto; omitir uno es una decisión del desarrollador registrada como `DS-nn`, nunca un bloqueo. <Qué más es sagrado en los datos>.
6. **<Contratos>**: <fuente de verdad de las integraciones>.
7. **Idioma**: <idioma del código>; <idioma de la interfaz, specs y documentación>.

## Historial

| Versión | Fecha | Cambio | Motivo |
|---|---|---|---|
| 0.1.0 | AAAA-MM-DD | Propuesta inicial | — |
