---
name: project-constitution
description: "Redacta, revisa y enmienda docs/constitution.md, los principios innegociables del proyecto que toda spec, plan, tarea y código deben cumplir. Úsala al crear la constitución, al proponer una enmienda o al comprobar si un diseño la respeta."
---

# Constitución del proyecto

La constitución es el conjunto **pequeño** de principios innegociables del proyecto. No es una guía de estilo ni un `AGENTS.md`: es lo que, si se incumple, invalida una spec, un plan o un cambio.

## Cuándo se usa

- **Etapa 0**: una vez por proyecto, antes de la primera spec.
- **Enmienda**: cuando un principio impide algo que el equipo decide aceptar de forma permanente. Nunca para saltarse un principio en una sola spec.
- **Verificación**: el arquitecto, el revisor de specs, el revisor de código y el verificador comprueban el cumplimiento.

## Cómo redactar los principios

1. Entre **6 y 9 principios**, como máximo unas 25 líneas en total.
2. Cada principio tiene: **nombre corto en negrita**, la **regla verificable** y, si no es obvio, el **porqué** en media línea.
3. **Verificable** significa que un revisor puede decir «se cumple» o «no se cumple» mirando un diff o un plan. ❌ «Código de calidad». ✅ «Sin dependencias nuevas sin un ADR aprobado».
4. Antes de proponer nada, lee `AGENTS.md`, `MEMORY.md` y el código: la constitución formaliza lo que el proyecto **ya es** y lo que **no puede dejar de ser**.

## Áreas que debe cubrir

| Área | Pregunta que responde | Ejemplo |
|---|---|---|
| Stack y simplicidad | ¿Qué tecnologías se permiten? ¿Cuándo se añade una dependencia? | «Angular 20 standalone + signals. Ninguna dependencia nueva sin ADR aprobado.» |
| Spec ↔ código | ¿Qué manda? | «Nada se implementa si no está en una spec aprobada.» |
| Arquitectura | ¿Qué límites no se cruzan? | «La lógica de dominio es pura: sin HTTP, almacenamiento, DOM ni reloj del sistema.» |
| Tests | ¿Cuál es la política de pruebas? | «TDD: el test falla antes que el código. Prohibido avanzar con tests en rojo u omitidos.» |
| Datos y seguridad | ¿Qué es sagrado? | «Los controles base de seguridad se aplican por defecto; omitir uno es una decisión registrada (`DS-nn`). Los cambios de esquema son compatibles hacia atrás.» |
| Contratos | ¿Cómo se integra con otros sistemas? | «El contrato de API en `contracts/` es la fuente de verdad entre frontend y backend.» |
| Idioma | ¿En qué idioma va cada cosa? | «Código en inglés; interfaz, specs y documentación en español.» |

## Plantilla

Usa [constitution-template.md](./assets/constitution-template.md).

## Versionado y enmiendas

- Versión semántica: **MAYOR** si se elimina o redefine un principio; **MENOR** si se añade uno; **PARCHE** si se aclara la redacción.
- Cada enmienda se registra en «Historial» con la fecha, la versión, el cambio y el motivo.
- Una enmienda pasa por el mismo gate que la propuesta inicial: aprobación explícita del usuario.
- Tras una enmienda MAYOR, revisa las specs `Aprobada` que no estén implementadas: pueden quedar en conflicto.

## Comprobación de cumplimiento (para planes y revisiones)

Para cada principio, una línea: `Principio n — ✅ cumple: <cómo>` o `❌ incumple: <dónde y por qué>`. Un solo ❌ es un hallazgo `BLOQUEANTE`.
