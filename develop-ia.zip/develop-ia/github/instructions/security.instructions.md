---
name: "Seguridad · Controles base"
description: "Controles base de seguridad para cualquier cambio de código, configuración o documentación, basados en estándares abiertos (OWASP Top 10:2025, OWASP ASVS 5.0, OWASP Top 10 Proactive Controls 2024, OWASP API Security Top 10 2023 y CWE Top 25 2025). Se aplican por defecto y nunca bloquean: omitir uno es una decisión del desarrollador."
applyTo: "**"
---

# Seguridad · Controles base

**Se aplican por defecto** al escribir código, en cualquier stack, y **ninguno bloquea el flujo**. Si un control no se cumple, o aplicarlo añade trabajo que el desarrollador puede no querer (por ejemplo, en un desarrollo interno que no se expone a Internet), se le presenta como **decisión de seguridad** con una recomendación según la exposición del proyecto, y **decide él**. Su decisión queda registrada como `DS-nn` en la spec y se respeta en todas las etapas. Entre paréntesis, la referencia principal; la recomendación por exposición, el proceso por etapa y el mapa completo están en la skill `secure-development`.

1. **La seguridad empieza en la spec** (A06 · C4). Cada cambio declara su exposición, su sensibilidad y sus permisos. Si es sensible, se proponen casos de abuso y modelo de amenazas, y el desarrollador decide cuáles entran.
2. **Acceso denegado por defecto y mínimo privilegio** (A01 · C1 · ASVS V8 · API1, API3, API5). La autorización se comprueba en el servidor en cada operación, incluida la propiedad del recurso: nadie accede a datos ajenos cambiando un ID, ni fija o ve campos que no le corresponden. Ocultar algo en la interfaz no es seguridad. Cada componente, cuenta de servicio y token tiene solo los permisos que necesita.
3. **Toda entrada externa es hostil** (A05 · C3 · C10 · ASVS V2, V5 · API4). Se valida en el servidor con listas permitidas (tipo, longitud, rango, formato), aunque ya se valide en el cliente, con límites de tamaño, de página y de frecuencia. Incluye archivos, cabeceras, datos de terceros y URLs: las peticiones salientes no van a destinos que controle el usuario sin una lista permitida.
4. **Datos y código no se mezclan** (A05 · A08 · ASVS V1). Consultas parametrizadas u ORM; nada de concatenar entradas en SQL, comandos, rutas de archivo ni HTML; salidas codificadas según su contexto; ni `eval` ni deserialización de tipos arbitrarios.
5. **Ningún secreto en el repositorio** (A04 · A07 · ASVS V13). Ni en código, tests, configuración versionada, documentación ni logs. Se leen de variables de entorno, *user secrets* o un gestor de secretos; los ejemplos usan valores ficticios evidentes.
6. **Criptografía estándar, nunca propia** (A04 · C2 · ASVS V11, V12). Algoritmos y librerías reconocidos; contraseñas con el hash adaptativo de la plataforma; TLS en el tráfico fuera de la máquina local.
7. **Identidad con la plataforma** (A07 · C7 · ASVS V6, V7, V9, V10). Autenticación, sesiones y tokens con los mecanismos del framework o del proveedor de identidad: tokens validados (firma, emisor, audiencia y caducidad) y de vida corta, protección CSRF donde haya cookies y cierre de sesión que invalida.
8. **Los errores fallan cerrado y no revelan nada** (A10 · C3 · ASVS V16). Ante una excepción, la operación se deniega y no deja cambios a medias; el usuario no ve trazas, SQL, rutas ni versiones.
9. **Eventos de seguridad registrados, sin datos sensibles** (A09 · C9 · ASVS V14, V16). Se registran los accesos denegados, los fallos de autenticación y los cambios de permisos; nunca contraseñas, tokens, datos personales ni cuerpos completos de peticiones.
10. **Configuración segura por defecto** (A02 · C5 · C8 · ASVS V3, V13). Nada de modo depuración, CORS abierto con credenciales, cabeceras de seguridad relajadas ni cuentas o claves por defecto fuera del entorno local.
11. **Dependencias aprobadas, reales y sin vulnerabilidades conocidas** (A03 · C6 · ASVS V15). Ninguna dependencia nueva sin aprobación. Antes de proponerla, se comprueba que existe en el registro oficial con ese nombre exacto (la IA puede inventar paquetes o confundirlos con imitaciones), que está mantenida y que no tiene vulnerabilidades altas o críticas. Las versiones las fija el archivo de bloqueo.

## Al escribir código

- Los controles que no añaden trabajo (consultas parametrizadas, sin secretos, errores genéricos, salidas codificadas) se aplican sin preguntar.
- Si la spec tiene una decisión `DS-nn` que omite un control, respétala: no lo añadas por tu cuenta.
- Si un control no se puede cumplir o añade alcance que la spec no pide, no te detengas ni lo resuelvas a tu manera: anótalo en tu respuesta como **decisión de seguridad pendiente**, con el formato de la skill `secure-development`.

## Protección frente a la IA (no son controles del desarrollo)

Ningún agente ejecuta comandos destructivos (`rm -rf`, `git push --force`, `git reset --hard`, borrado de bases de datos) ni `--no-verify`, ni edita `.env`, certificados o archivos de secretos (si hace falta una variable nueva, se añade a `.env.example` con un valor ficticio y se avisa). Las hace cumplir el hook del kit y protegen el repositorio del propio agente, no limitan lo que decide el desarrollador.
