---
name: "Tests · Convenciones"
description: "Convenciones obligatorias para escribir o modificar tests automáticos en cualquier stack (TDD, nombres con RF, determinismo, dobles)."
applyTo: "**/*.spec.ts,**/*.test.ts,**/*.spec.js,**/*.test.js,**/*Tests.cs,**/*Test.cs,**/tests/**,**/test/**,**/__tests__/**"
---

# Convenciones de tests

- **TDD**: el test se escribe y se ve fallar (RED) antes que el código. Detalle en la skill `tdd-cycle`.
- **Nombre con trazabilidad**: cada test de comportamiento empieza por el identificador que verifica: `RF-03: rechaza la programación con fecha pasada` o `CL-02: acepta exactamente 90 días`.
  - Jasmine o Vitest: `it('RF-03: ...', ...)`.
  - NUnit: `[Category("RF-03")]` (una por cada RF o CL que verifica) y `[Description("RF-03: ...")]`; detalle en el perfil .NET.
- **Estructura** Arrange / Act / Assert, con una línea en blanco entre bloques. Una razón para fallar por test.
- **Comportamiento, no implementación**: afirma sobre salidas y estado observable, no sobre métodos privados ni detalles internos.
- **Deterministas**: nada de reloj real (inyecta la fecha o usa un reloj falso), red real, aleatoriedad sin semilla ni dependencia del orden o de la zona horaria de la máquina.
- **Dobles**: prefiere stubs y fakes; mocks con verificación solo cuando el comportamiento es la propia llamada. No hagas mock de lógica pura propia.
- **Prohibido** en el código entregado: `.only`, `fdescribe`, `fit`, `xit`, `skip`, `[Ignore]`, `[Explicit]`, `Assert.Ignore()`, `Assert.Inconclusive()`, tests sin aserciones y aserciones triviales.
- **Nunca** modifiques un test existente para que pase una implementación. Si el test está mal, se corrige de forma explícita (tarea o hallazgo) y se explica el motivo.
- Reutiliza las utilidades, *builders* y fixtures de test que ya existen antes de crear otros.
