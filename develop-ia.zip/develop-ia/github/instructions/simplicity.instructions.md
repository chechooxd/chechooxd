---
name: "Diseño simple · Sin sobreingeniería"
description: "Reglas verificables para no sobrediseñar: el plan, el código y los tests resuelven lo que piden los RF de hoy con la solución más simple que siga las convenciones del proyecto. Se aplica a planes, código y tests."
applyTo: "**"
---

# Diseño simple · Sin sobreingeniería

La IA tiende a generalizar, anticipar y abstraer. En este kit, **lo correcto es lo más simple que cumple los RF de la spec y sigue las convenciones del proyecto**. La complejidad se justifica con un requisito de hoy, nunca con un «por si acaso».

## Prueba rápida

Para cada pieza nueva (archivo, interfaz, clase, capa, parámetro, opción de configuración, dependencia o patrón): **¿qué RF, RNF o convención del proyecto la exige hoy?** Si la respuesta es «ninguno» o «más adelante», sobra.

## Reglas

1. **Solo lo que pide la spec.** Nada de opciones de configuración, parámetros, *flags*, puntos de extensión ni casos que ningún RF pide.
2. **Abstraer a partir de dos usos reales.** Una interfaz, clase base, genérico o utilidad compartida nueva necesita al menos dos usos reales hoy (en este cambio o en el código existente) o una convención que la exija. Con un solo uso, código directo.
3. **Las convenciones del proyecto no son sobreingeniería.** Si `AGENTS.md`, la constitución o el perfil del stack piden una estructura (por ejemplo, `Controller → Handler → Repository` con sus interfaces), se sigue. Lo que sí es sobreingeniería: añadir capas, patrones o librerías que el proyecto no usa.
4. **Reutiliza y amplía antes de crear.** Nada de un componente, servicio o helper paralelo a uno que ya existe.
5. **Patrones solo con un problema delante.** Fábrica, estrategia, mediador, decorador, eventos o CQRS, solo si el caso no se resuelve con una función o una clase.
6. **Sin optimización prematura.** Caché, colas, paralelismo o *lazy loading* extra, solo con un RNF medido que lo pida.
7. **Sin defensa imaginaria.** Se valida en la frontera (controles base de seguridad); dentro, se confía en los tipos y en lo ya validado: nada de comprobaciones repetidas, `try/catch` que solo relanzan ni envoltorios sin función.
8. **Sin dependencias por comodidad.** Si la plataforma o el proyecto ya lo resuelven, no se añade una librería.
9. **Menos indirección.** No partas en archivos, capas o funciones lo que se entiende mejor junto: cada salto de indirección debe aportar algo que se pueda nombrar.
10. **Tests a la medida.** Dobles solo en las fronteras; sin jerarquías de clases de test, frameworks de *builders* ni utilidades para un único test.
11. **El refactor simplifica, no generaliza.** Elimina duplicación real dentro del alcance de la tarea; no prepara el código para tareas futuras ni toca código ajeno a la tarea.

## Cuándo sí está justificado

- Lo exige un RF, un RNF o una convención del proyecto.
- Está en el plan como decisión `D-nn`, aprobada en el Gate 2, con la alternativa simple descartada y el motivo.
- Hay al menos dos usos reales hoy.

Si la pieza no está en el plan y no cumple nada de lo anterior, no se añade: se propone en la respuesta como decisión para el usuario.
