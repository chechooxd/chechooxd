---
name: "Stack · .NET 10"
description: "Perfil de stack .NET 10 / C# para API: capas Controller, Handler y Repository, DTOs, contrato ResponseData, errores centralizados, EF Core sin Include, async con CancellationToken y tests con NUnit. Elimina este archivo si el repositorio no es .NET."
applyTo: "**/*.cs,**/*.csproj"
---

# .NET 10

> Perfil de stack. Ajusta las librerías a lo que digan los `*.csproj` y `Directory.Packages.props`; si algo no coincide con el repositorio, manda el repositorio.
> Tests con **NUnit**. La librería de dobles es la que ya referencia el proyecto de tests (revisa su `.csproj`): no introduzcas otra.

## Arquitectura (capas estrictas)
- Flujo **`Controller → Handler (IHandler) → Repository (IRepository)`**. Prohibido saltar capas (un Controller que llama a un Repository) o mezclar responsabilidades (acceso a datos en el Handler, lógica de caso de uso en el Repository, formateo HTTP fuera del Controller).
- Nomenclatura por entidad: `ClienteController`, `IClienteHandler` / `ClienteHandler`, `IClienteRepository` / `ClienteRepository`. Las interfaces nuevas se registran en `Program.cs` con `AddScoped`.
- Métodos con nombre de caso de uso (`ObtenerClientesActivosAsync`), no genéricos (`GetAsync`).
- Inyección de dependencias con **constructores primarios**. Configuración con el patrón Options (`IOptions<T>`).
- **Reloj**: `TimeProvider` inyectado, nunca `DateTime.Now` ni `DateTime.UtcNow` en la lógica.

## Contrato con el frontend
- Ninguna consulta devuelve entidades de dominio: siempre **DTOs** (`Models/DTO`). Exponer una entidad es un defecto crítico.
- Los Handlers devuelven la respuesta envuelta en **`ResponseData<T>`** (con **`ResponseMeta`** en los endpoints paginados). Nunca otro formato: es el contrato que consume el frontend.
- Los errores **no se capturan** en Handlers ni Repositories para formatearlos: se propagan y el middleware los convierte en **`ResponseError`**.
- **Cambio de contrato = posible ruptura del frontend.** Añadir, quitar o renombrar campos de `Data`, cambiar `ResponseMeta`, códigos de error, ruta, verbo o parámetros obligatorios de un endpoint existente solo se hace si el plan lo marca como cambio aprobado. Si no, para y repórtalo.

## EF Core y rendimiento
- `.AsNoTracking()` (o `.AsNoTrackingWithIdentityResolution()`) en **todas** las lecturas.
- **Prohibido `.Include()` y `.ThenInclude()`**: proyecta con `.Select()` directamente al DTO, trayendo solo las columnas necesarias.
- Sin N+1: lo que puede resolverse en una consulta no se hace en varias. Paginación en el servidor.
- `async`/`await` de punta a punta con **`CancellationToken`** en la firma y propagado. Prohibido `.Result`, `.Wait()` y `async void`.
- Cambios de esquema con migración explícita y compatible hacia atrás.

## Lenguaje y estilo
- `Nullable` habilitado (sin `!` para silenciar avisos sin justificación); namespaces de archivo (`namespace X;`); `record` para DTOs inmutables. Nada de `dynamic`.
- Idioma de nombres, comentarios y logs: el que fije la constitución del repositorio.
- *Early returns* y *guard clauses*; sin números ni cadenas mágicas; sin sobreingeniería (capas o patrones que no resuelven un problema real del cambio; reglas en `simplicity.instructions.md`).
- `ILogger<T>` con plantillas estructuradas (`_logger.LogInformation("Envío {Id} programado", id)`), nunca con interpolación. Sin datos personales ni secretos.
- Valida las entradas en la frontera (comprueba si FluentValidation está instalado antes de usarlo).

## Tests (NUnit)
- Proyecto de tests con `NUnit`, `NUnit3TestAdapter` y `Microsoft.NET.Test.Sdk` (y `NUnit.Analyzers`, si está, que detecta usos incorrectos). Mira la versión de NUnit en el `.csproj`: desde NUnit 4, los asserts clásicos (`Assert.AreEqual`...) solo existen como `ClassicAssert`.
- Suite completa: `dotnet test`. Por RF: `dotnet test --filter "TestCategory=RF-03"` (más comandos en la referencia `test-commands.md` de la skill `tdd-cycle`).
- **Trazabilidad**: cada test de comportamiento lleva `[Category("RF-03")]`, una por cada RF o CL que verifica, y `[Description("RF-03: ...")]` con el mismo identificador. El método se llama `Metodo_Escenario_ResultadoEsperado`.
  ```csharp
  [Test]
  [Category("RF-03")]
  [Description("RF-03: rechaza la programación con fecha pasada")]
  public void ProgramarEnvioAsync_FechaPasada_LanzaErrorDeValidacion()
  {
      var solicitud = CrearSolicitud(fecha: _reloj.GetUtcNow().AddMinutes(-1));

      // Usa la excepción que define el proyecto para este error.
      Assert.ThrowsAsync<ValidationException>(
          () => _handler.ProgramarEnvioAsync(solicitud, CancellationToken.None));
  }
  ```
- **Aserciones** con el modelo de restricciones: `Assert.That(real, Is.EqualTo(esperado))`. Agrupa las de un mismo comportamiento con `Assert.Multiple`. En tests nuevos, nada de `ClassicAssert`.
- **Ciclo de vida**: NUnit usa **una misma instancia de la clase para todos sus tests**. Crea el SUT y los dobles en `[SetUp]`, nunca en inicializadores de campo ni en el constructor, o marca la clase con `[FixtureLifeCycle(LifeCycle.InstancePerTestCase)]`. `[OneTimeSetUp]` y `[OneTimeTearDown]`, solo para recursos caros que no cambian entre tests.
- **Asíncronos**: `public async Task`, nunca `async void`. Excepciones con `Assert.ThrowsAsync<T>(...)` o `Assert.That(..., Throws.TypeOf<T>())`.
- **Handlers**: tests unitarios con el `IRepository` sustituido por un doble (con la librería que ya use el proyecto). Un test de Handler nunca usa la base de datos real ni un repositorio concreto. Como los errores se propagan al middleware, el test de Handler afirma la **excepción** que se lanza; el `ResponseError` resultante (código HTTP y cuerpo) se afirma en los tests de integración de la API.
- **Repositories**: el mecanismo de test de EF Core que ya use el proyecto (revisa los tests existentes antes de elegir otro).
- Cubre los casos de error de la spec (qué excepción y qué `ResponseError` se esperan, y cuándo), no solo el camino feliz.
- Tiempo con `FakeTimeProvider` (si `Microsoft.Extensions.TimeProvider.Testing` está instalado) o un `TimeProvider` falso propio.
- Integración de API con `WebApplicationFactory<Program>` si el proyecto la usa: créala en `[OneTimeSetUp]`, libérala en `[OneTimeTearDown]` y usa un `HttpClient` nuevo por test.

## Prohibido
- Secretos en `appsettings*.json` versionados.
- SQL concatenado con entradas (usa parámetros o LINQ).
- Capturar `Exception` para formatear respuestas o tragarla sin registrarla.
